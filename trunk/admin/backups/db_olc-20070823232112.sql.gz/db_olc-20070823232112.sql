# OL-Commerce 
# http://www.ol-commerce.com, http://www.seifenparadies.de
#
# Database Backup For GAMEWARE Computer und Spiele
# Copyright (c) 2007 OL-Commerce
#
# Database: olc
# Database Server: localhost
#
# Backup Date: 23.08.2007 23:21:09

drop table if exists campaigns_ip;
create table campaigns_ip (
  user_ip varchar(255) not null ,
  time datetime default '0000-00-00 00:00:00' not null ,
  campaign varchar(255) not null 
);


drop table if exists chc_access;
create table chc_access (
  timestamp int(14) default '0' not null ,
  typ enum('tag','kw','monat','jahr','tageszeit_wochentag_start','tageszeit','wochentag_1_Mon','wochentag_2_Tue','wochentag_3_Wed','wochentag_4_Thu','wochentag_5_Fri','wochentag_6_Sat','wochentag_7_Sun') default 'tag' not null ,
  erster_eintrag int(1) default '0' not null ,
  besucher_00 int(14) default '0' not null ,
  besucher_01 int(14) default '0' not null ,
  besucher_02 int(14) default '0' not null ,
  besucher_03 int(14) default '0' not null ,
  besucher_04 int(14) default '0' not null ,
  besucher_05 int(14) default '0' not null ,
  besucher_06 int(14) default '0' not null ,
  besucher_07 int(14) default '0' not null ,
  besucher_08 int(14) default '0' not null ,
  besucher_09 int(14) default '0' not null ,
  besucher_10 int(14) default '0' not null ,
  besucher_11 int(14) default '0' not null ,
  besucher_12 int(14) default '0' not null ,
  besucher_13 int(14) default '0' not null ,
  besucher_14 int(14) default '0' not null ,
  besucher_15 int(14) default '0' not null ,
  besucher_16 int(14) default '0' not null ,
  besucher_17 int(14) default '0' not null ,
  besucher_18 int(14) default '0' not null ,
  besucher_19 int(14) default '0' not null ,
  besucher_20 int(14) default '0' not null ,
  besucher_21 int(14) default '0' not null ,
  besucher_22 int(14) default '0' not null ,
  besucher_23 int(14) default '0' not null ,
  seitenaufrufe_00 int(14) default '0' not null ,
  seitenaufrufe_01 int(14) default '0' not null ,
  seitenaufrufe_02 int(14) default '0' not null ,
  seitenaufrufe_03 int(14) default '0' not null ,
  seitenaufrufe_04 int(14) default '0' not null ,
  seitenaufrufe_05 int(14) default '0' not null ,
  seitenaufrufe_06 int(14) default '0' not null ,
  seitenaufrufe_07 int(14) default '0' not null ,
  seitenaufrufe_08 int(14) default '0' not null ,
  seitenaufrufe_09 int(14) default '0' not null ,
  seitenaufrufe_10 int(14) default '0' not null ,
  seitenaufrufe_11 int(14) default '0' not null ,
  seitenaufrufe_12 int(14) default '0' not null ,
  seitenaufrufe_13 int(14) default '0' not null ,
  seitenaufrufe_14 int(14) default '0' not null ,
  seitenaufrufe_15 int(14) default '0' not null ,
  seitenaufrufe_16 int(14) default '0' not null ,
  seitenaufrufe_17 int(14) default '0' not null ,
  seitenaufrufe_18 int(14) default '0' not null ,
  seitenaufrufe_19 int(14) default '0' not null ,
  seitenaufrufe_20 int(14) default '0' not null ,
  seitenaufrufe_21 int(14) default '0' not null ,
  seitenaufrufe_22 int(14) default '0' not null ,
  seitenaufrufe_23 int(14) default '0' not null ,
  KEY typ (typ),
  KEY timestamp (typ, timestamp)
);

insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1177941362', 'tageszeit_wochentag_start', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'tageszeit', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '1', '0', '1', '0', '1', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '2', '6', '2', '0', '0', '2', '4', '2', '5', '7', '40', '0', '2', '3', '4');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_1_Mon', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4', '0', '3', '0', '0', '0', '0', '3', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_2_Tue', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '2', '0', '2', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_3_Wed', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '2', '0', '0', '2', '7', '38', '0', '0', '0', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_4_Thu', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '6', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_5_Fri', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_6_Sat', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('0', 'wochentag_7_Sun', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1177891200', 'tag', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4', '0', '3', '0', '0', '0', '0', '3', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1177891200', 'kw', '1', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '1', '0', '1', '0', '1', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '2', '6', '2', '0', '0', '2', '4', '2', '5', '7', '40', '0', '2', '3', '4');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1175385600', 'monat', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4', '0', '3', '0', '0', '0', '0', '3', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1167609600', 'jahr', '1', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '1', '0', '1', '0', '1', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '2', '6', '2', '0', '0', '2', '4', '2', '5', '7', '40', '0', '2', '3', '4');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1177977600', 'tag', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '2', '0', '2', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1177977600', 'monat', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '2', '6', '0', '0', '0', '0', '1', '0', '2', '6', '2', '0', '0', '2', '0', '2', '2', '7', '40', '0', '2', '0', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1178064000', 'tag', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '2', '0', '0', '2', '7', '38', '0', '0', '0', '2');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1178150400', 'tag', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '6', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1185408000', 'tag', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1183248000', 'monat', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
insert into chc_access (timestamp, typ, erster_eintrag, besucher_00, besucher_01, besucher_02, besucher_03, besucher_04, besucher_05, besucher_06, besucher_07, besucher_08, besucher_09, besucher_10, besucher_11, besucher_12, besucher_13, besucher_14, besucher_15, besucher_16, besucher_17, besucher_18, besucher_19, besucher_20, besucher_21, besucher_22, besucher_23, seitenaufrufe_00, seitenaufrufe_01, seitenaufrufe_02, seitenaufrufe_03, seitenaufrufe_04, seitenaufrufe_05, seitenaufrufe_06, seitenaufrufe_07, seitenaufrufe_08, seitenaufrufe_09, seitenaufrufe_10, seitenaufrufe_11, seitenaufrufe_12, seitenaufrufe_13, seitenaufrufe_14, seitenaufrufe_15, seitenaufrufe_16, seitenaufrufe_17, seitenaufrufe_18, seitenaufrufe_19, seitenaufrufe_20, seitenaufrufe_21, seitenaufrufe_22, seitenaufrufe_23) values ('1185148800', 'kw', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');

drop table if exists chc_config;
create table chc_config (
  setting varchar(255) not null ,
  value text not null ,
  PRIMARY KEY (setting)
);

insert into chc_config (setting, value) values ('statistiken_anzahl_aufloesungen', '10');
insert into chc_config (setting, value) values ('admin_name', 'smichl@paar.de');
insert into chc_config (setting, value) values ('admin_passwort', '806055bd6317f19a5ff783e0ec40f989');
insert into chc_config (setting, value) values ('modus_zaehlsperre', 'intervall');
insert into chc_config (setting, value) values ('blockzeit', '86400');
insert into chc_config (setting, value) values ('user_online_fuer', '300');
insert into chc_config (setting, value) values ('log_eintraege_loeschen_nach:wert_in_sek', '2421972');
insert into chc_config (setting, value) values ('log_eintraege_loeschen_nach:einheit_administration', 'd');
insert into chc_config (setting, value) values ('anordnung_log_eintraege', 'ASC');
insert into chc_config (setting, value) values ('anzahl_pro_logseite', '100');
insert into chc_config (setting, value) values ('statistiken_anzahl_referrer', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_refdomains', '10');
insert into chc_config (setting, value) values ('show_online_users_ip', '2');
insert into chc_config (setting, value) values ('statistiken_anzahl_seiten', '20');
insert into chc_config (setting, value) values ('statistiken_anzahl_user_agents', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_sprachen', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_hosts_tlds', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_laender', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_all_lists', '1000');
insert into chc_config (setting, value) values ('statistiken_anzahl_suchwoerter', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_suchphrasen', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_downloads', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_hyperlinks', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_latest', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_top', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_host_tlds', '20');
insert into chc_config (setting, value) values ('statistiken_anzahl_suchmaschinen', '10');
insert into chc_config (setting, value) values ('statistiken_anzahl_browser', '20');
insert into chc_config (setting, value) values ('statistiken_anzahl_os', '20');
insert into chc_config (setting, value) values ('statistiken_anzahl_robots', '20');
insert into chc_config (setting, value) values ('db_aufraeumen_nach', '86400');
insert into chc_config (setting, value) values ('zeitzone', '1');
insert into chc_config (setting, value) values ('dst', '1');
insert into chc_config (setting, value) values ('lang', 'de');
insert into chc_config (setting, value) values ('lang_administration', 'de');
insert into chc_config (setting, value) values ('seitenstatistik_titel_suche', '0');
insert into chc_config (setting, value) values ('status_logs', '1');
insert into chc_config (setting, value) values ('status_referrer', '1');
insert into chc_config (setting, value) values ('status_user_agents', '1');
insert into chc_config (setting, value) values ('status_clh', '1');
insert into chc_config (setting, value) values ('status_seiten', '1');
insert into chc_config (setting, value) values ('status_einstiegs_ausgangsseiten', '1');
insert into chc_config (setting, value) values ('status_aufloesungen', '1');
insert into chc_config (setting, value) values ('status_access', '1');
insert into chc_config (setting, value) values ('status_suchmaschinen_und_suchwoerter', '1');
insert into chc_config (setting, value) values ('status_suchphrasen', '1');
insert into chc_config (setting, value) values ('status_js', '1');
insert into chc_config (setting, value) values ('script_version', '3.1.1');
insert into chc_config (setting, value) values ('block_robots', '0');
insert into chc_config (setting, value) values ('statistiken_login_erforderlich', 'index:all_lists;');
insert into chc_config (setting, value) values ('blacklist_user_agents', '');
insert into chc_config (setting, value) values ('blacklist_referrers', '%q=www.%+sex%.%');
insert into chc_config (setting, value) values ('blacklist_pages', '');
insert into chc_config (setting, value) values ('blacklist_ips', '');
insert into chc_config (setting, value) values ('blacklist_hosts', '');
insert into chc_config (setting, value) values ('exclusion_list_user_agents', '');
insert into chc_config (setting, value) values ('exclusion_list_referrers', 'http://paar.de%; http://www.paar.de%; http://www.example.tld%; %blocked by Outpost%');
insert into chc_config (setting, value) values ('exclusion_list_keywords', '');
insert into chc_config (setting, value) values ('exclusion_list_search_phrases', '');
insert into chc_config (setting, value) values ('exclusion_list_pages', '');
insert into chc_config (setting, value) values ('exclusion_list_screen_resolutions', '');
insert into chc_config (setting, value) values ('hideout_list_pages', '');
insert into chc_config (setting, value) values ('hideout_list_screen_resolutions', '');
insert into chc_config (setting, value) values ('hideout_list_keywords', '');
insert into chc_config (setting, value) values ('hideout_list_search_phrases', '');
insert into chc_config (setting, value) values ('hideout_list_referrers', '');
insert into chc_config (setting, value) values ('hideout_list_user_agents', '');
insert into chc_config (setting, value) values ('referrer_kuerzen_nach', '27');
insert into chc_config (setting, value) values ('referrer_kuerzungszeichen', '...');
insert into chc_config (setting, value) values ('wordwrap_latest_x', '30');
insert into chc_config (setting, value) values ('wordwrap_top_x', '30');
insert into chc_config (setting, value) values ('wordwrap_referrer', '30');
insert into chc_config (setting, value) values ('wordwrap_refdomains', '30');
insert into chc_config (setting, value) values ('wordwrap_suchwoerter', '30');
insert into chc_config (setting, value) values ('wordwrap_suchphrasen', '30');
insert into chc_config (setting, value) values ('wordwrap_seite_online_users', '30');
insert into chc_config (setting, value) values ('wordwrap_seiten', '30');
insert into chc_config (setting, value) values ('wordwrap_browser', '0');
insert into chc_config (setting, value) values ('wordwrap_user_agents', '30');
insert into chc_config (setting, value) values ('wordwrap_aufloesungen', '0');
insert into chc_config (setting, value) values ('wordwrap_downloads', '30');
insert into chc_config (setting, value) values ('wordwrap_os', '0');
insert into chc_config (setting, value) values ('wordwrap_robots', '0');
insert into chc_config (setting, value) values ('wordwrap_laender', '0');
insert into chc_config (setting, value) values ('wordwrap_sprachen', '0');
insert into chc_config (setting, value) values ('wordwrap_hosts_tlds', '0');
insert into chc_config (setting, value) values ('wordwrap_all_lists', '50');
insert into chc_config (setting, value) values ('wordwrap_suchmaschinen', '30');
insert into chc_config (setting, value) values ('hideout_list_browsers', '');
insert into chc_config (setting, value) values ('hideout_list_os', '');
insert into chc_config (setting, value) values ('hideout_list_robots', '');
insert into chc_config (setting, value) values ('user_agents_kuerzen_nach', '0');
insert into chc_config (setting, value) values ('user_agents_kuerzungszeichen', '...');
insert into chc_config (setting, value) values ('fremde_URLs_verlinken', '0');
insert into chc_config (setting, value) values ('hideout_list_referring_domains', '');
insert into chc_config (setting, value) values ('gast_name', '');
insert into chc_config (setting, value) values ('gast_passwort', '');
insert into chc_config (setting, value) values ('admin_blocking_cookie', '0');
insert into chc_config (setting, value) values ('exclusion_list_search_engines', '');
insert into chc_config (setting, value) values ('hideout_list_search_engines', '');
insert into chc_config (setting, value) values ('default_counter_visibility', '1');
insert into chc_config (setting, value) values ('referrer_query_string_entfernen', '0');
insert into chc_config (setting, value) values ('seiten_query_string_bereinigung_variablen', 'latest; top; sort_by; sort_order; distr_type; distr_of; d_day; d_month; d_year; d_type; m_month; m_year; m_type; w_month; w_year; w_type; y_year; y_type; l_last; l_type; lang; type; clh; homepage_id; kp; p; month; p_month; d_month; h_month; ref_month; refdom_month; kp_month; se_month; b_month; os_month; r_month; clh_month; res_month; PHPSESSID; ');
insert into chc_config (setting, value) values ('seiten_query_string_bereinigung_modus', 'ohne');
insert into chc_config (setting, value) values ('timestamp_start_pseudo', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_access', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_referrer', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_user_agents', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_browser', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_os', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_robots', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_seiten', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_laender', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_sprachen', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_hosts_tlds', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_suchmaschinen', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_suchwoerter_suchphrasen', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_aufloesungen', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_javascript', '1177941362');
insert into chc_config (setting, value) values ('timestamp_start_verweisende_domains', '1177941362');
insert into chc_config (setting, value) values ('zeige_seitentitel', '1');
insert into chc_config (setting, value) values ('logdaten_zeige_seitentitel', '1');
insert into chc_config (setting, value) values ('default_homepage_url', 'http://www.paar.de');
insert into chc_config (setting, value) values ('homepages_urls', '1 => default_homepage_url; ');
insert into chc_config (setting, value) values ('default_counter_url', 'http://www.paar.de/chCounter');
insert into chc_config (setting, value) values ('counter_urls', '1 => default_counter_url; ');
insert into chc_config (setting, value) values ('aktiviere_seitenverwaltung_von_mehreren_domains', '0');
insert into chc_config (setting, value) values ('seitenstatistik:_zeige_homepages_getrennt', '0');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:user_agents:werte', '1;8640000');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:user_agents:aktiviert', '0');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:referrer:werte', '1;8640000');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:referrer:aktiviert', '0');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:verweisende_domains:werte', '1;8640000');
insert into chc_config (setting, value) values ('regelmaessiges_loeschen:verweisende_domains:aktiviert', '0');
insert into chc_config (setting, value) values ('darstellungsart_balkendiagramme_zugriffsstatistiken', 'relativ');
insert into chc_config (setting, value) values ('homepage_charset', 'ISO-8859-1');
insert into chc_config (setting, value) values ('js_gleichwertige_homepage_urls', '');
insert into chc_config (setting, value) values ('min_jscode_version', '3.0.0Beta8');
insert into chc_config (setting, value) values ('min_zeichenlaenge_suchwoerter_suchphrasen', '3');
insert into chc_config (setting, value) values ('counterstatus_statistikseiten', '1');
insert into chc_config (setting, value) values ('robots_von_js_stats_ausschliessen', '1');
insert into chc_config (setting, value) values ('php_self_oder_request_uri', 'REQUEST_URI');

drop table if exists chc_counted_users;
create table chc_counted_users (
  nr int(14) default '0' not null ,
  ip varchar(255) not null ,
  user_agent varchar(255) not null ,
  is_robot int(1) default '0' not null ,
  timestamp int(14) default '0' not null ,
  seitenaufrufe int(14) default '0' not null ,
  letzte_seite int(14) default '0' not null ,
  js int(1) default '0' not null ,
  aufloesung varchar(255) not null ,
  PRIMARY KEY (nr),
  KEY schluessel (ip, user_agent)
);


drop table if exists chc_data;
create table chc_data (
  besucher_gesamt int(14) default '0' not null ,
  besucher_heute int(14) default '0' not null ,
  heute_timestamp int(14) default '0' not null ,
  besucher_gestern int(14) default '0' not null ,
  max_online:anzahl int(14) default '0' not null ,
  max_online:timestamp int(14) default '0' not null ,
  max_besucher_pro_tag:anzahl int(14) default '0' not null ,
  max_besucher_pro_tag:timestamp int(14) default '0' not null ,
  seitenaufrufe_gesamt int(14) default '0' not null ,
  seitenaufrufe_heute int(14) default '0' not null ,
  seitenaufrufe_gestern int(14) default '0' not null ,
  seitenaufrufe_pro_besucher:besucher int(14) default '0' not null ,
  seitenaufrufe_pro_besucher:seitenaufrufe int(14) default '0' not null ,
  durchschnittlich_pro_tag:timestamp int(14) default '0' not null ,
  durchschnittlich_pro_tag:besucher int(14) default '0' not null ,
  durchschnittlich_pro_tag:seitenaufrufe int(14) default '0' not null ,
  max_seitenaufrufe_pro_tag:anzahl int(14) default '0' not null ,
  max_seitenaufrufe_pro_tag:timestamp int(14) default '0' not null ,
  js_alle int(14) default '0' not null ,
  js_robots int(14) default '0' not null ,
  js_aktiv int(14) default '0' not null ,
  timestamp_letztes_db_aufraeumen int(14) default '0' not null 
);


drop table if exists chc_downloads_and_hyperlinks;
create table chc_downloads_and_hyperlinks (
  id int(14) unsigned not null auto_increment,
  typ enum('download','hyperlink') default 'download' not null ,
  wert varchar(255) not null ,
  url varchar(255) not null ,
  timestamp_eintrag int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  anzahl int(14) default '0' not null ,
  in_statistik_verbergen int(1) default '0' not null ,
  PRIMARY KEY (id),
  KEY typ (typ)
);


drop table if exists chc_downloads_and_hyperlinks_logs;
create table chc_downloads_and_hyperlinks_logs (
  id int(14) default '0' not null ,
  typ enum('download','hyperlink') default 'download' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  anzahl int(14) default '0' not null ,
  KEY id (id),
  KEY monat (monat),
  KEY typ (typ)
);


drop table if exists chc_ignored_users;
create table chc_ignored_users (
  id int(14) unsigned not null auto_increment,
  ip varchar(255) not null ,
  host varchar(255) not null ,
  grund varchar(255) not null ,
  tmp_blocked int(1) default '0' not null ,
  user_agent varchar(255) not null ,
  is_robot int(1) default '0' not null ,
  timestamp int(14) default '0' not null ,
  seitenaufrufe int(14) default '0' not null ,
  PRIMARY KEY (id),
  KEY ip (ip, user_agent)
);


drop table if exists chc_locale_information;
create table chc_locale_information (
  typ enum('host_tld','country','language') default 'country' not null ,
  wert varchar(255) not null ,
  anzahl int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  KEY typ (typ),
  KEY monat (monat)
);

insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('host_tld', '.de', '1', '1177941376', '200704');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('language', 'de', '2', '1177946910', '200704');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('host_tld', '.at', '1', '1177946910', '200704');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('country', 'at', '1', '1177946910', '200704');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('host_tld', '.net', '1', '1177995987', '200705');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('host_tld', 'unresolved', '1', '1178091696', '200705');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('language', 'de', '2', '1178125289', '200705');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('host_tld', '.de', '1', '1178125289', '200705');
insert into chc_locale_information (typ, wert, anzahl, timestamp, monat) values ('country', 'de', '1', '1178125289', '200705');

drop table if exists chc_log_data;
create table chc_log_data (
  nr int(14) default '0' not null ,
  ip varchar(255) not null ,
  host varchar(255) not null ,
  user_agent varchar(255) not null ,
  is_robot int(1) default '0' not null ,
  http_accept_language varchar(255) not null ,
  timestamp int(14) default '0' not null ,
  referrer varchar(255) not null ,
  seitenaufrufe int(14) default '0' not null ,
  seiten text not null ,
  downloads text not null ,
  hyperlinks text not null ,
  js int(1) default '0' not null ,
  aufloesung varchar(255) not null ,
  PRIMARY KEY (nr),
  KEY timestamp (timestamp)
);

insert into chc_log_data (nr, ip, host, user_agent, is_robot, http_accept_language, timestamp, referrer, seitenaufrufe, seiten, downloads, hyperlinks, js, aufloesung) values ('1', '192.168.1.1', 'server.paar.de', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', 'de', '1177941376', 'http://www.paar.de/index.php', '56', '/index.php|1|1177941376|__|/index.php|1|1177941377|__|/index.php|1|1177941407|__|/index.php|1|1177941407|__|/index.php|1|1177964425|__|/index.php|1|1177964427|__|/index.php?full_errors=true|1|1177965635|__|/index.php?full_errors=true|1|1177966800|__|/index.php|1|1177966801|__|/index.php|1|1177974375|__|/index.php|1|1177974379|__|/index.php|1|1177979416|__|/index.php|1|1177979418|__|/index.php|1|1177980520|__|/index.php|1|1177980520|__|/index.php|1|1177980904|__|/index.php|1|1177980904|__|/index.php|1|1178031112|__|/index.php|1|1178031113|__|/index.php|1|1178042159|__|/index.php|1|1178042160|__|/index.php|1|1178047600|__|/index.php|1|1178047601|__|/index.php|1|1178123877|__|/index.php|1|1178123884|__|/index.php?OLCsid=da23fb14b64e4943a3df0303d753ffe4&ajax=true&cart_details_state=none|1|1178123960|__|/index.php|1|1178124761|__|/index.php|1|1178124766|__|/index.php|1|1178125079|__|/index.php|1|1178125084|__|/index.php|1|1178125237|__|/index.php|1|1178125237|__|/index.php|1|1178125261|__|/index.php|1|1178125266|__|/index.php|1|1178125988|__|/index.php|1|1178125993|__|/index.php|1|1178126045|__|/index.php|1|1178126050|__|/index.php|1|1178126092|__|/index.php|1|1178126098|__|/index.php|1|1178126161|__|/index.php|1|1178126166|__|/index.php|1|1178126581|__|/index.php|1|1178126586|__|/index.php|1|1178127572|__|/index.php|1|1178127572|__|/index.php|1|1178127778|__|/index.php|1|1178127779|__|/index.php|1|1178127894|__|/index.php|1|1178127894|__|/index.php|1|1178127909|__|/index.php|1|1178127909|__|/index.php|1|1178127986|__|/index.php|1|1178127987|__|/index.php|1|1178141658|__|/index.php|1|1178141659|__|', '', '', '1', '1280x1024');
insert into chc_log_data (nr, ip, host, user_agent, is_robot, http_accept_language, timestamp, referrer, seitenaufrufe, seiten, downloads, hyperlinks, js, aufloesung) values ('2', '62.47.224.195', 'M519P003.adsl.highway.telekom.at', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)', '0', 'de-at', '1177946910', 'http://www.scooterinfo.de/index.php?module=vquiz', '3', '/index.php?module=vquiz|1|1177946910|__|/index.php|1|1177946914|__|/index.php?module=vquiz|1|1177946925|__|', '', '', '1', '1024x768');
insert into chc_log_data (nr, ip, host, user_agent, is_robot, http_accept_language, timestamp, referrer, seitenaufrufe, seiten, downloads, hyperlinks, js, aufloesung) values ('3', '195.27.115.50', 'gimli.seekbot.net', 'Seekbot/1.0 (http://www.seekbot.net/bot.html) HTTPFetcher/2.2', '1', '', '1177995987', '', '1', '/index.php|1|1177995987|__|', '', '', '0', '');
insert into chc_log_data (nr, ip, host, user_agent, is_robot, http_accept_language, timestamp, referrer, seitenaufrufe, seiten, downloads, hyperlinks, js, aufloesung) values ('4', '80.81.24.232', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', 'de', '1178091696', 'http://www.paar.de/index.php', '14', '/index.php|1|1178091696|__|/index.php|1|1178091701|__|/index.php|1|1178098830|__|/index.php|1|1178098833|__|/index.php|1|1178107417|__|/index.php|1|1178107421|__|/index.php|1|1178119829|__|/index.php|1|1178119833|__|/index.php|1|1178182198|__|/index.php|1|1178182201|__|/index.php|1|1178182217|__|/index.php|1|1178182220|__|/index.php|1|1178182276|__|/index.php|1|1178182280|__|', '', '', '1', '1024x768');
insert into chc_log_data (nr, ip, host, user_agent, is_robot, http_accept_language, timestamp, referrer, seitenaufrufe, seiten, downloads, hyperlinks, js, aufloesung) values ('5', '192.168.1.8', 'pc-00008.paar.de', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '0', 'de-de,de;q=0.8,en-us;q=0.5,en;q=0.3', '1178125289', 'http://www.paar.de/index.php', '14', '/index.php|1|1178125289|__|/index.php|1|1178125289|__|/index.php|1|1178125540|__|/index.php|1|1178125541|__|/index.php|1|1178125566|__|/index.php|1|1178125566|__|/index.php|1|1178126199|__|/index.php|1|1178126199|__|/index.php|1|1178126384|__|/index.php|1|1178126384|__|/index.php|1|1178127595|__|/index.php|1|1178127595|__|/index.php|1|1178127944|__|/index.php|1|1178127945|__|', '', '', '1', '1280x1024');

drop table if exists chc_online_users;
create table chc_online_users (
  id int(14) unsigned not null auto_increment,
  nr int(14) default '0' not null ,
  ip varchar(255) not null ,
  user_agent varchar(255) not null ,
  is_robot int(1) default '0' not null ,
  timestamp_erster_aufruf int(14) default '0' not null ,
  timestamp_letzter_aufruf int(14) default '0' not null ,
  seite varchar(255) not null ,
  homepage_id int(2) default '0' not null ,
  seitenaufrufe int(14) default '0' not null ,
  PRIMARY KEY (id),
  KEY nr (nr)
);

insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('14', '4', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1178091696', '1178091701', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('15', '4', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1178098830', '1178098833', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('16', '4', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1178107417', '1178107421', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('17', '4', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1178119829', '1178119833', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('18', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178123877', '1178123960', '/index.php?OLCsid=da23fb14b64e4943a3df0303d753ffe4&ajax=true&cart_details_state=none', '1', '3');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('19', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178124761', '1178124766', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('20', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178125079', '1178125266', '/index.php', '1', '6');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('21', '5', '192.168.1.8', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '0', '1178125289', '1178125566', '/index.php', '1', '6');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('22', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178125988', '1178126166', '/index.php', '1', '8');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('23', '5', '192.168.1.8', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '0', '1178126199', '1178126384', '/index.php', '1', '4');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('24', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178126581', '1178126586', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('25', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178127572', '1178127987', '/index.php', '1', '10');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('26', '5', '192.168.1.8', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '0', '1178127595', '1178127595', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('27', '5', '192.168.1.8', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '0', '1178127944', '1178127945', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('28', '1', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1178141658', '1178141659', '/index.php', '1', '2');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('29', '4', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1178182198', '1178182280', '/index.php', '1', '6');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('30', '6', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1185464567', '1185464567', '/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('31', '6', '80.81.24.232', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1.4) Gecko/20070515 Firefox/2.0.0.4', '0', '1185465806', '1185465806', '/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('32', '6', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1185467696', '1185467696', '/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('33', '6', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1185468627', '1185468627', '/olc/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('34', '6', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1185469395', '1185469395', '/olc/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('35', '6', '192.168.1.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '0', '1185469706', '1185469706', '/olc/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('36', '6', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1186069658', '1186069658', '/olc/index.php', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('37', '6', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1186069997', '1186069997', '/olc/index.php?full_errors=true', '1', '1');
insert into chc_online_users (id, nr, ip, user_agent, is_robot, timestamp_erster_aufruf, timestamp_letzter_aufruf, seite, homepage_id, seitenaufrufe) values ('38', '6', '80.81.24.232', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '0', '1186069997', '1186069997', '/olc/index.php', '1', '1');

drop table if exists chc_pages;
create table chc_pages (
  id int(14) unsigned not null auto_increment,
  wert varchar(255) not null ,
  homepage_id int(2) default '0' not null ,
  counter_verzeichnis int(1) default '0' not null ,
  anzahl int(14) default '0' not null ,
  anzahl_einstiegsseite int(14) default '0' not null ,
  anzahl_ausgangsseite int(14) default '0' not null ,
  titel varchar(255) not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  PRIMARY KEY (id),
  KEY wert (wert),
  KEY homepage_id (homepage_id),
  KEY monat (monat)
);

insert into chc_pages (id, wert, homepage_id, counter_verzeichnis, anzahl, anzahl_einstiegsseite, anzahl_ausgangsseite, titel, timestamp, monat) values ('1', '/index.php', '1', '0', '8', '1', '0', 'Shop Start-Seite', '1177966801', '200704');
insert into chc_pages (id, wert, homepage_id, counter_verzeichnis, anzahl, anzahl_einstiegsseite, anzahl_ausgangsseite, titel, timestamp, monat) values ('2', '/index.php?module=vquiz', '1', '0', '2', '1', '1', 'Shop Start-Seite', '1177946925', '200704');
insert into chc_pages (id, wert, homepage_id, counter_verzeichnis, anzahl, anzahl_einstiegsseite, anzahl_ausgangsseite, titel, timestamp, monat) values ('3', '/index.php?full_errors=true', '1', '0', '2', '0', '0', 'Shop Start-Seite', '1177966800', '200704');
insert into chc_pages (id, wert, homepage_id, counter_verzeichnis, anzahl, anzahl_einstiegsseite, anzahl_ausgangsseite, titel, timestamp, monat) values ('4', '/index.php', '1', '0', '75', '3', '4', 'Shop Start-Seite', '1178182280', '200705');
insert into chc_pages (id, wert, homepage_id, counter_verzeichnis, anzahl, anzahl_einstiegsseite, anzahl_ausgangsseite, titel, timestamp, monat) values ('5', '/index.php?OLCsid=da23fb14b64e4943a3df0303d753ffe4&ajax=true&cart_details_state=none', '1', '0', '1', '0', '0', 'Shop Start-Seite', '1178123960', '200705');

drop table if exists chc_referrers;
create table chc_referrers (
  id int(14) unsigned not null auto_increment,
  typ enum('referrer','domain') default 'referrer' not null ,
  wert varchar(255) not null ,
  homepage_id int(2) default '0' not null ,
  anzahl int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  PRIMARY KEY (id),
  KEY typ (typ),
  KEY typ_2 (typ, wert),
  KEY homepage_id (homepage_id),
  KEY monat (monat)
);

insert into chc_referrers (id, typ, wert, homepage_id, anzahl, timestamp, monat) values ('1', 'referrer', 'http://www.scooterinfo.de/index.php?module=vquiz', '1', '1', '1177946910', '200704');
insert into chc_referrers (id, typ, wert, homepage_id, anzahl, timestamp, monat) values ('2', 'domain', 'www.scooterinfo.de', '1', '1', '1177946910', '200704');

drop table if exists chc_screen_resolutions;
create table chc_screen_resolutions (
  wert varchar(255) not null ,
  anzahl int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' 
);

insert into chc_screen_resolutions (wert, anzahl, timestamp, monat) values ('1280x1024', '1', '1177941377', '200704');
insert into chc_screen_resolutions (wert, anzahl, timestamp, monat) values ('1024x768', '1', '1177946914', '200704');
insert into chc_screen_resolutions (wert, anzahl, timestamp, monat) values ('1024x768', '1', '1178091699', '200705');
insert into chc_screen_resolutions (wert, anzahl, timestamp, monat) values ('1280x1024', '1', '1178125289', '200705');

drop table if exists chc_search_engines;
create table chc_search_engines (
  typ enum('suchmaschine','suchphrase','suchwort') default 'suchmaschine' not null ,
  wert varchar(255) not null ,
  anzahl int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  KEY typ (typ),
  KEY typ_2 (typ, wert),
  KEY monat (monat)
);


drop table if exists chc_user_agents;
create table chc_user_agents (
  typ enum('user_agent','browser','os','robot','version~browser','version~os','version~robot') default 'user_agent' not null ,
  wert varchar(255) not null ,
  anzahl int(14) default '0' not null ,
  timestamp int(14) default '0' not null ,
  monat int(6) default '0' ,
  KEY typ (typ),
  KEY typ_2 (typ, wert),
  KEY monat (monat)
);

insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('user_agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; InfoPath.2)', '1', '1177941376', '-1');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('browser', 'Internet Explorer', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('os', 'Windows', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Internet Explorer~7.0', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Internet Explorer~versionen_gesamt', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~os', 'Windows~NT', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~os', 'Windows~versionen_gesamt', '2', '1177946910', '200704');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('user_agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)', '1', '1177946910', '-1');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('user_agent', 'Seekbot/1.0 (http://www.seekbot.net/bot.html) HTTPFetcher/2.2', '1', '1177995987', '-1');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('robot', 'Seekbot', '1', '1177995987', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~robot', 'Seekbot~1.0', '1', '1177995987', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~robot', 'Seekbot~versionen_gesamt', '1', '1177995987', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('user_agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)', '1', '1178091696', '-1');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('browser', 'Internet Explorer', '1', '1178091696', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('os', 'Windows', '2', '1178125289', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Internet Explorer~7.0', '1', '1178091696', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Internet Explorer~versionen_gesamt', '1', '1178091696', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~os', 'Windows~NT', '2', '1178125289', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~os', 'Windows~versionen_gesamt', '2', '1178125289', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('user_agent', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1) Gecko/20061010 Firefox/2.0', '1', '1178125289', '-1');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('browser', 'Firefox', '1', '1178125289', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Firefox~2.0', '1', '1178125289', '200705');
insert into chc_user_agents (typ, wert, anzahl, timestamp, monat) values ('version~browser', 'Firefox~versionen_gesamt', '1', '1178125289', '200705');

drop table if exists olc_address_book;
create table olc_address_book (
  address_book_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  entry_gender char(1) not null ,
  entry_company varchar(32) ,
  entry_firstname varchar(32) not null ,
  entry_lastname varchar(32) not null ,
  entry_street_address varchar(64) not null ,
  entry_suburb varchar(32) ,
  entry_postcode varchar(10) not null ,
  entry_city varchar(32) not null ,
  entry_state varchar(32) ,
  entry_country_id int(11) default '0' not null ,
  entry_zone_id int(11) default '0' not null ,
  PRIMARY KEY (address_book_id),
  KEY idx_address_book_customers_id (customers_id)
);

insert into olc_address_book (address_book_id, customers_id, entry_gender, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, entry_zone_id) values ('1', '1', 'm', 'GAMEWARE', 'Stefan', 'Michl', 'Martinstra�e 31', '', '86551', 'Aichach', 'Bayern', '81', '81');

drop table if exists olc_address_format;
create table olc_address_format (
  address_format_id int(11) not null auto_increment,
  address_format varchar(128) not null ,
  address_summary varchar(48) not null ,
  PRIMARY KEY (address_format_id)
);

insert into olc_address_format (address_format_id, address_format, address_summary) values ('1', '$firstname $lastname$cr$streets$cr$city, $postcode$cr$statecomma$country', '$city / $country');
insert into olc_address_format (address_format_id, address_format, address_summary) values ('2', '$firstname $lastname$cr$streets$cr$city, $state    $postcode$cr$country', '$city, $state / $country');
insert into olc_address_format (address_format_id, address_format, address_summary) values ('3', '$firstname $lastname$cr$streets$cr$city$cr$postcode - $statecomma$country', '$state / $country');
insert into olc_address_format (address_format_id, address_format, address_summary) values ('4', '$firstname $lastname$cr$streets$cr$city ($postcode)$cr$country', '$postcode / $country');
insert into olc_address_format (address_format_id, address_format, address_summary) values ('5', '$firstname $lastname$cr$streets$cr$postcode $city$cr$country', '$city / $country');

drop table if exists olc_admin_access;
create table olc_admin_access (
  customers_id varchar(32) default '0' not null ,
  configuration int(1) default '0' not null ,
  modules int(1) default '0' not null ,
  countries int(1) default '0' not null ,
  currencies int(1) default '0' not null ,
  zones int(1) default '0' not null ,
  geo_zones int(1) default '0' not null ,
  tax_classes int(1) default '0' not null ,
  tax_rates int(1) default '0' not null ,
  accounting int(1) default '0' not null ,
  backup int(1) default '0' not null ,
  cache int(1) default '0' not null ,
  server_info int(1) default '0' not null ,
  whos_online int(1) default '0' not null ,
  languages int(1) default '0' not null ,
  define_language int(1) default '0' not null ,
  orders_status int(1) default '0' not null ,
  shipping_status int(1) default '0' not null ,
  module_export int(1) default '0' not null ,
  customers int(1) default '0' not null ,
  create_account int(1) default '0' not null ,
  customers_status int(1) default '0' not null ,
  orders int(1) default '0' not null ,
  print_packingslip int(1) default '0' not null ,
  print_order int(1) default '0' not null ,
  popup_memo int(1) default '0' not null ,
  coupon_admin int(1) default '0' not null ,
  gv_queue int(1) default '0' not null ,
  gv_mail int(1) default '0' not null ,
  gv_sent int(1) default '0' not null ,
  validproducts int(1) default '0' not null ,
  validcategories int(1) default '0' not null ,
  mail int(1) default '0' not null ,
  categories int(1) default '0' not null ,
  new_attributes int(1) default '0' not null ,
  products_attributes int(1) default '0' not null ,
  manufacturers int(1) default '0' not null ,
  reviews int(1) default '0' not null ,
  specials int(1) default '0' not null ,
  stats_products_expected int(1) default '0' not null ,
  stats_products_viewed int(1) default '0' not null ,
  stats_products_purchased int(1) default '0' not null ,
  stats_customers int(1) default '0' not null ,
  stats_sales_report int(1) default '0' not null ,
  banner_manager int(1) default '0' not null ,
  banner_statistics int(1) default '0' not null ,
  module_newsletter int(1) default '0' not null ,
  xml_export int(1) default '0' not null ,
  start int(1) default '0' not null ,
  content_manager int(1) default '0' not null ,
  content_preview int(1) default '0' not null ,
  credits int(1) default '0' not null ,
  blacklist int(1) default '0' not null ,
  orders_edit int(1) default '0' not null ,
  xsell_products int(1) default '0' not null ,
  affiliate_affiliates int(1) ,
  affiliate_banners int(1) ,
  affiliate_clicks int(1) ,
  affiliate_contact int(1) ,
  affiliate_invoice int(1) ,
  affiliate_payment int(1) ,
  affiliate_popup_image int(1) ,
  affiliate_sales int(1) ,
  affiliate_statistics int(1) ,
  affiliate_summary int(1) ,
  easypopulate int(1) ,
  froogle int(1) ,
  down_for_maintenance int(1) default '0' not null ,
  attributeManager int(1) default '0' not null ,
  google_sitemap int(1) default '0' not null ,
  elmar_start int(1) default '0' not null ,
  blz_update int(1) default '0' not null ,
  livehelp int(1) default '0' not null ,
  products_uvp int(1) default '0' not null ,
  products_vpe int(1) default '0' not null ,
  pdf_export int(1) default '0' not null ,
  pdf_datasheet int(1) default '0' not null ,
  listcategories int(1) default '0' not null ,
  listproducts int(1) default '0' not null ,
  chCounter int(1) default '0' not null ,
  paypal_ipn int(1) default '0' not null ,
  eazysales int(1) default '0' not null ,
  ebay int(1) default '0' not null ,
  campaigns int(1) default '0' not null ,
  stats_campaigns int(1) default '0' not null ,
  import_export int(1) default '0' not null ,
  PRIMARY KEY (customers_id)
);

insert into olc_admin_access (customers_id, configuration, modules, countries, currencies, zones, geo_zones, tax_classes, tax_rates, accounting, backup, cache, server_info, whos_online, languages, define_language, orders_status, shipping_status, module_export, customers, create_account, customers_status, orders, print_packingslip, print_order, popup_memo, coupon_admin, gv_queue, gv_mail, gv_sent, validproducts, validcategories, mail, categories, new_attributes, products_attributes, manufacturers, reviews, specials, stats_products_expected, stats_products_viewed, stats_products_purchased, stats_customers, stats_sales_report, banner_manager, banner_statistics, module_newsletter, xml_export, start, content_manager, content_preview, credits, blacklist, orders_edit, xsell_products, affiliate_affiliates, affiliate_banners, affiliate_clicks, affiliate_contact, affiliate_invoice, affiliate_payment, affiliate_popup_image, affiliate_sales, affiliate_statistics, affiliate_summary, easypopulate, froogle, down_for_maintenance, attributeManager, google_sitemap, elmar_start, blz_update, livehelp, products_uvp, products_vpe, pdf_export, pdf_datasheet, listcategories, listproducts, chCounter, paypal_ipn, eazysales, ebay, campaigns, stats_campaigns, import_export) values ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');
insert into olc_admin_access (customers_id, configuration, modules, countries, currencies, zones, geo_zones, tax_classes, tax_rates, accounting, backup, cache, server_info, whos_online, languages, define_language, orders_status, shipping_status, module_export, customers, create_account, customers_status, orders, print_packingslip, print_order, popup_memo, coupon_admin, gv_queue, gv_mail, gv_sent, validproducts, validcategories, mail, categories, new_attributes, products_attributes, manufacturers, reviews, specials, stats_products_expected, stats_products_viewed, stats_products_purchased, stats_customers, stats_sales_report, banner_manager, banner_statistics, module_newsletter, xml_export, start, content_manager, content_preview, credits, blacklist, orders_edit, xsell_products, affiliate_affiliates, affiliate_banners, affiliate_clicks, affiliate_contact, affiliate_invoice, affiliate_payment, affiliate_popup_image, affiliate_sales, affiliate_statistics, affiliate_summary, easypopulate, froogle, down_for_maintenance, attributeManager, google_sitemap, elmar_start, blz_update, livehelp, products_uvp, products_vpe, pdf_export, pdf_datasheet, listcategories, listproducts, chCounter, paypal_ipn, eazysales, ebay, campaigns, stats_campaigns, import_export) values ('groups', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '2', '2', '2', '3', '3', '3', '3', '3', '3', '4', '4', '4', '4', '2', '4', '2', '2', '2', '2', '5', '5', '5', '5', '5', '5', '5', '5', '2', '2', '2', '2', '2', '2', '2', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');

drop table if exists olc_affiliate_affiliate;
create table olc_affiliate_affiliate (
  affiliate_id int(11) not null auto_increment,
  affiliate_lft int(11) default '0' not null ,
  affiliate_rgt int(11) default '0' not null ,
  affiliate_root int(11) default '0' not null ,
  affiliate_gender char(1) not null ,
  affiliate_firstname varchar(32) not null ,
  affiliate_lastname varchar(32) not null ,
  affiliate_dob datetime default '0000-00-00 00:00:00' not null ,
  affiliate_email_address varchar(96) not null ,
  affiliate_telephone varchar(32) not null ,
  affiliate_fax varchar(32) not null ,
  affiliate_password varchar(40) not null ,
  affiliate_homepage varchar(96) not null ,
  affiliate_street_address varchar(64) not null ,
  affiliate_suburb varchar(64) not null ,
  affiliate_city varchar(32) not null ,
  affiliate_postcode varchar(10) not null ,
  affiliate_state varchar(32) not null ,
  affiliate_country_id int(11) default '0' not null ,
  affiliate_zone_id int(11) default '0' not null ,
  affiliate_agb tinyint(4) default '0' not null ,
  affiliate_company varchar(60) not null ,
  affiliate_company_taxid varchar(64) not null ,
  affiliate_commission_percent decimal(4,2) default '0.00' not null ,
  affiliate_payment_check varchar(100) not null ,
  affiliate_payment_paypal varchar(64) not null ,
  affiliate_payment_bank_name varchar(64) not null ,
  affiliate_payment_bank_branch_number varchar(64) not null ,
  affiliate_payment_bank_swift_code varchar(64) not null ,
  affiliate_payment_bank_account_name varchar(64) not null ,
  affiliate_payment_bank_account_number varchar(64) not null ,
  affiliate_date_of_last_logon datetime default '0000-00-00 00:00:00' not null ,
  affiliate_number_of_logons int(11) default '0' not null ,
  affiliate_date_account_created datetime default '0000-00-00 00:00:00' not null ,
  affiliate_date_account_last_modified datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (affiliate_id),
  KEY affiliate_root (affiliate_root),
  KEY affiliate_rgt (affiliate_rgt),
  KEY affiliate_lft (affiliate_lft)
);


drop table if exists olc_affiliate_banners;
create table olc_affiliate_banners (
  affiliate_banners_id int(11) not null auto_increment,
  affiliate_banners_title varchar(64) not null ,
  affiliate_products_id int(11) default '0' not null ,
  affiliate_banners_image varchar(64) not null ,
  affiliate_banners_group varchar(10) not null ,
  affiliate_banners_html_text text ,
  affiliate_expires_impressions int(7) default '0' ,
  affiliate_expires_date datetime ,
  affiliate_date_scheduled datetime ,
  affiliate_date_added datetime default '0000-00-00 00:00:00' not null ,
  affiliate_date_status_change datetime ,
  affiliate_status int(1) default '1' not null ,
  PRIMARY KEY (affiliate_banners_id)
);


drop table if exists olc_affiliate_banners_history;
create table olc_affiliate_banners_history (
  affiliate_banners_history_id int(11) not null auto_increment,
  affiliate_banners_products_id int(11) default '0' not null ,
  affiliate_banners_id int(11) default '0' not null ,
  affiliate_banners_affiliate_id int(11) default '0' not null ,
  affiliate_banners_shown int(11) default '0' not null ,
  affiliate_banners_clicks tinyint(4) default '0' not null ,
  affiliate_banners_history_date date default '0000-00-00' not null ,
  PRIMARY KEY (affiliate_banners_history_id, affiliate_banners_products_id)
);


drop table if exists olc_affiliate_clickthroughs;
create table olc_affiliate_clickthroughs (
  affiliate_clickthrough_id int(11) not null auto_increment,
  affiliate_id int(11) default '0' not null ,
  affiliate_clientdate datetime default '0000-00-00 00:00:00' not null ,
  affiliate_clientbrowser varchar(200) default 'Could Not Find This Data' ,
  affiliate_clientip varchar(50) default 'Could Not Find This Data' ,
  affiliate_clientreferer varchar(200) default 'none detected (maybe a direct link)' ,
  affiliate_products_id int(11) default '0' ,
  affiliate_banner_id int(11) default '0' not null ,
  PRIMARY KEY (affiliate_clickthrough_id),
  KEY refid (affiliate_id)
);


drop table if exists olc_affiliate_payment;
create table olc_affiliate_payment (
  affiliate_payment_id int(11) not null auto_increment,
  affiliate_id int(11) default '0' not null ,
  affiliate_payment decimal(15,2) default '0.00' not null ,
  affiliate_payment_tax decimal(15,2) default '0.00' not null ,
  affiliate_payment_total decimal(15,2) default '0.00' not null ,
  affiliate_payment_date datetime default '0000-00-00 00:00:00' not null ,
  affiliate_payment_last_modified datetime default '0000-00-00 00:00:00' not null ,
  affiliate_payment_status int(5) default '0' not null ,
  affiliate_firstname varchar(32) not null ,
  affiliate_lastname varchar(32) not null ,
  affiliate_street_address varchar(64) not null ,
  affiliate_suburb varchar(64) not null ,
  affiliate_city varchar(32) not null ,
  affiliate_postcode varchar(10) not null ,
  affiliate_country varchar(32) default '0' not null ,
  affiliate_company varchar(60) not null ,
  affiliate_state varchar(32) default '0' not null ,
  affiliate_address_format_id int(5) default '0' not null ,
  affiliate_last_modified datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (affiliate_payment_id)
);


drop table if exists olc_affiliate_payment_status;
create table olc_affiliate_payment_status (
  affiliate_payment_status_id int(11) default '0' not null ,
  affiliate_language_id int(11) default '1' not null ,
  affiliate_payment_status_name varchar(32) not null ,
  PRIMARY KEY (affiliate_payment_status_id, affiliate_language_id),
  KEY idx_affiliate_payment_status_name (affiliate_payment_status_name)
);

insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('0', '1', 'Pending');
insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('0', '2', 'Offen');
insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('0', '3', 'Pendiente');
insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('1', '1', 'Paid');
insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('1', '2', 'Ausgezahlt');
insert into olc_affiliate_payment_status (affiliate_payment_status_id, affiliate_language_id, affiliate_payment_status_name) values ('1', '3', 'Pagado');

drop table if exists olc_affiliate_payment_status_history;
create table olc_affiliate_payment_status_history (
  affiliate_status_history_id int(11) not null auto_increment,
  affiliate_payment_id int(11) default '0' not null ,
  affiliate_new_value int(5) default '0' not null ,
  affiliate_old_value int(5) ,
  affiliate_date_added datetime default '0000-00-00 00:00:00' not null ,
  affiliate_notified int(1) default '0' ,
  PRIMARY KEY (affiliate_status_history_id)
);


drop table if exists olc_affiliate_sales;
create table olc_affiliate_sales (
  affiliate_id int(11) default '0' not null ,
  affiliate_date datetime default '0000-00-00 00:00:00' not null ,
  affiliate_browser varchar(100) not null ,
  affiliate_ipaddress varchar(20) not null ,
  affiliate_orders_id int(11) default '0' not null ,
  affiliate_value decimal(15,2) default '0.00' not null ,
  affiliate_payment decimal(15,2) default '0.00' not null ,
  affiliate_clickthroughs_id int(11) default '0' not null ,
  affiliate_billing_status int(5) default '0' not null ,
  affiliate_payment_date datetime default '0000-00-00 00:00:00' not null ,
  affiliate_payment_id int(11) default '0' not null ,
  affiliate_percent decimal(4,2) default '0.00' not null ,
  affiliate_salesman int(11) default '0' not null ,
  affiliate_level tinyint(4) default '0' not null ,
  PRIMARY KEY (affiliate_id, affiliate_orders_id)
);


drop table if exists olc_auction_details;
create table olc_auction_details (
  id int(11) not null auto_increment,
  auction_id bigint(20) default '0' not null ,
  transaction_id bigint(20) default '0' ,
  endtime timestamp ,
  auction_endprice double default '0' not null ,
  amount int(11) default '0' not null ,
  buyer_id varchar(255) not null ,
  buyer_name varchar(255) not null ,
  buyer_email varchar(255) not null ,
  buyer_countrycode varchar(255) ,
  buyer_land varchar(255) not null ,
  buyer_zip varchar(255) not null ,
  buyer_city varchar(255) not null ,
  buyer_street varchar(255) not null ,
  buyer_state varchar(255) not null ,
  buyer_phone varchar(32) not null ,
  basket tinyint(4) default '0' ,
  order_number bigint(20) default '0' ,
  PRIMARY KEY (id)
);


drop table if exists olc_auction_list;
create table olc_auction_list (
  auction_id bigint(20) default '0' not null ,
  auction_title varchar(255) not null ,
  product_id int(11) default '0' not null ,
  predef_id int(11) default '0' not null ,
  quantity int(11) default '0' not null ,
  startprice double default '0' not null ,
  buynowprice double default '0' not null ,
  buynow tinyint(4) default '0' not null ,
  starttime timestamp ,
  endtime timestamp ,
  bidcount bigint(20) default '0' ,
  bidprice double default '0' ,
  ended tinyint(4) default '0' ,
  PRIMARY KEY (auction_id)
);


drop table if exists olc_auction_predefinition;
create table olc_auction_predefinition (
  predef_id bigint(20) not null auto_increment,
  product_id int(11) ,
  auction_type int(11) ,
  title varchar(255) ,
  subtitle varchar(255) ,
  cat1 bigint(20) ,
  cat2 bigint(20) ,
  description text ,
  auction int(1) default '0' not null ,
  express int(1) default '0' not null ,
  express_duration int(1) default '0' not null ,
  duration int(11) ,
  amount int(11) ,
  startprice double ,
  binprice double ,
  city varchar(255) ,
  country varchar(255) ,
  pic_url text ,
  gallery_pic_url varchar(255) ,
  gallery_pic_plus int(1) default '0' not null ,
  auto_resubmit int(1) default '0' not null ,
  bold tinyint(1) ,
  highlight tinyint(1) ,
  border tinyint(1) ,
  cod tinyint(1) ,
  cop tinyint(1) ,
  cc tinyint(1) ,
  paypal tinyint(1) ,
  de tinyint(1) ,
  at tinyint(1) ,
  ch tinyint(1) ,
  template varchar(255) ,
  PRIMARY KEY (predef_id)
);


drop table if exists olc_banktransfer;
create table olc_banktransfer (
  orders_id int(11) default '0' not null ,
  banktransfer_owner varchar(64) ,
  banktransfer_number varchar(24) ,
  banktransfer_bankname varchar(255) ,
  banktransfer_blz varchar(8) ,
  banktransfer_status int(11) ,
  banktransfer_prz char(2) ,
  banktransfer_fax char(2) ,
  KEY orders_id (orders_id)
);


drop table if exists olc_banktransfer_blz;
create table olc_banktransfer_blz (
  blz int(8) default '0' not null ,
  bankname varchar(58) not null ,
  prz char(2) not null ,
  land varchar(5) not null ,
  plz varchar(5) not null ,
  ort varchar(35) not null ,
  bankname_kurz varchar(27) not null ,
  KEY blz (blz),
  KEY plz (plz),
  KEY ort (ort),
  KEY land (land)
);


drop table if exists olc_banners;
create table olc_banners (
  banners_id int(11) not null auto_increment,
  banners_title varchar(64) not null ,
  banners_url varchar(255) not null ,
  banners_image varchar(64) not null ,
  banners_group varchar(10) not null ,
  banners_html_text text ,
  expires_impressions int(7) default '0' ,
  expires_date datetime ,
  date_scheduled datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  date_status_change datetime ,
  status int(1) default '1' not null ,
  PRIMARY KEY (banners_id)
);


drop table if exists olc_banners_history;
create table olc_banners_history (
  banners_history_id int(11) not null auto_increment,
  banners_id int(11) default '0' not null ,
  banners_shown int(5) default '0' not null ,
  banners_clicked int(5) default '0' not null ,
  banners_history_date datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (banners_history_id)
);


drop table if exists olc_box_configuration;
create table olc_box_configuration (
  box_id int(11) not null auto_increment,
  template varchar(30) ,
  box_key_name varchar(30) ,
  box_visible int(1) default '1' not null ,
  box_sort_order int(2) default '0' not null ,
  box_forced_visible int(1) default '0' not null ,
  box_real_name varchar(30) ,
  box_position_name varchar(30) ,
  last_modified datetime ,
  date_added datetime ,
  PRIMARY KEY (box_id)
);

insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('1', 'olc', 'SHOW_ADMIN', '1', '1', '1', 'box_ADMIN', 'box_r_03', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('2', 'olc', 'SHOW_CART', '1', '2', '1', 'box_CART', 'box_r_01', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('3', 'olc', 'SHOW_CATEGORIES', '1', '3', '1', 'box_CATEGORIES', 'box_l_01', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('4', 'olc', 'SHOW_CONTACT_US', '0', '4', '0', 'box_CONTACT_US', 'box_r_12', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('5', 'olc', 'SHOW_CONTENT', '1', '5', '1', 'box_CONTENT', 'box_l_05', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('6', 'olc', 'SHOW_INFOBOX', '1', '6', '1', 'box_INFOBOX', 'box_r_05', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('7', 'olc', 'SHOW_LOGIN', '1', '7', '1', 'box_LOGIN', 'box_r_02', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('8', 'olc', 'SHOW_MANUFACTURERS_INFO', '0', '8', '1', 'box_MANUFACTURERS_INFO', 'box_l_03', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('9', 'olc', 'SHOW_MANUFACTURERS', '0', '9', '1', 'box_MANUFACTURERS', 'box_l_02', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('10', 'olc', 'SHOW_SEARCH', '1', '10', '1', 'box_SEARCH', 'box_l_08', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('11', 'olc', 'SHOW_CHANGE_SKIN', '1', '11', '0', NULL, NULL, NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('12', 'olc', 'SHOW_ADD_A_QUICKIE', '1', '12', '0', 'box_ADD_A_QUICKIE', 'box_l_04', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('13', 'olc', 'SHOW_AFFILIATE', '1', '13', '0', 'box_AFFILIATE', 'box_l_13', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('14', 'olc', 'SHOW_BESTSELLERS', '1', '14', '0', 'box_BESTSELLERS', 'box_r_06', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('15', 'olc', 'SHOW_CENTER', '1', '15', '0', NULL, NULL, NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('16', 'olc', 'SHOW_CURRENCIES', '0', '16', '0', 'box_CURRENCIES', 'box_r_07', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('17', 'olc', 'SHOW_ORDER_HISTORY', '1', '17', '0', 'box_ORDER_HISTORY', 'box_l_12', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('18', 'olc', 'SHOW_INFORMATION', '1', '18', '0', 'box_INFORMATION', 'box_l_06', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('19', 'olc', 'SHOW_LANGUAGES', '0', '19', '0', 'box_LANGUAGES', 'box_r_08', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('20', 'olc', 'SHOW_LIVEHELP', '0', '20', '0', 'box_LIVEHELP', 'box_r_04', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('21', 'olc', 'SHOW_NEWSLETTER', '1', '21', '0', 'box_NEWSLETTER', 'box_r_10', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('22', 'olc', 'SHOW_LAST_VIEWED', '1', '22', '0', 'box_LAST_VIEWED', 'box_r_11', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('23', 'olc', 'SHOW_NOTIFICATIONS', '1', '23', '0', 'box_NOTIFICATIONS', 'box_r_09', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('24', 'olc', 'SHOW_REVIEWS', '1', '24', '0', 'box_REVIEWS', 'box_l_07', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('25', 'olc', 'SHOW_SPECIALS', '1', '25', '0', 'box_SPECIALS', 'box_l_09', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('26', 'olc', 'SHOW_TELL_FRIEND', '1', '26', '0', 'box_TELL_FRIEND', 'box_l_11', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('27', 'olc', 'SHOW_WHATSNEW', '1', '27', '0', 'box_WHATSNEW', 'box_l_10', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('28', 'olc', 'SHOW_TAB_NAVIGATION', '0', '28', '0', 'box_TAB_NAVIGATION', 'box_m_01', NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('29', 'olc', 'SHOW_PDF_CATALOG', '1', '29', '0', NULL, NULL, NULL, '2007-07-26 17:38:47');
insert into olc_box_configuration (box_id, template, box_key_name, box_visible, box_sort_order, box_forced_visible, box_real_name, box_position_name, last_modified, date_added) values ('30', 'olc', 'SHOW_GALLERY', '1', '30', '0', NULL, NULL, NULL, '2007-07-26 17:38:47');

drop table if exists olc_campaigns;
create table olc_campaigns (
  campaigns_id int(11) not null auto_increment,
  campaigns_name varchar(255) not null ,
  campaigns_refID varchar(64) ,
  campaigns_leads int(11) default '0' not null ,
  date_added datetime ,
  last_modified datetime ,
  PRIMARY KEY (campaigns_id),
  KEY IDX_CAMPAIGNS_NAME (campaigns_name)
);


drop table if exists olc_campaigns_ip;
create table olc_campaigns_ip (
  user_ip varchar(255) not null ,
  time datetime default '0000-00-00 00:00:00' not null ,
  campaign varchar(255) not null 
);


drop table if exists olc_cao_log;
create table olc_cao_log (
  id int(11) not null auto_increment,
  date datetime default '0000-00-00 00:00:00' not null ,
  user varchar(64) not null ,
  pw varchar(64) not null ,
  method varchar(64) not null ,
  action varchar(64) not null ,
  post_data mediumtext ,
  get_data mediumtext ,
  PRIMARY KEY (id)
);


drop table if exists olc_card_blacklist;
create table olc_card_blacklist (
  blacklist_id int(5) not null auto_increment,
  blacklist_card_number varchar(20) not null ,
  date_added datetime ,
  last_modified datetime ,
  KEY blacklist_id (blacklist_id)
);


drop table if exists olc_categories;
create table olc_categories (
  categories_id int(11) not null auto_increment,
  categories_image varchar(64) ,
  parent_id int(11) default '0' not null ,
  categories_status tinyint(1) unsigned default '1' not null ,
  categories_template varchar(64) ,
  group_ids text ,
  listing_template varchar(64) ,
  sort_order int(3) ,
  products_sorting varchar(32) ,
  products_sorting2 varchar(32) ,
  date_added datetime ,
  last_modified datetime ,
  PRIMARY KEY (categories_id),
  KEY idx_categories_parent_id (parent_id)
);


drop table if exists olc_categories_description;
create table olc_categories_description (
  categories_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  categories_name varchar(32) not null ,
  categories_heading_title varchar(255) not null ,
  categories_description text not null ,
  categories_meta_title varchar(100) not null ,
  categories_meta_description varchar(255) not null ,
  categories_meta_keywords varchar(255) not null ,
  PRIMARY KEY (categories_id, language_id),
  KEY idx_categories_name (categories_name)
);


drop table if exists olc_cm_file_flags;
create table olc_cm_file_flags (
  file_flag int(11) default '0' not null ,
  file_flag_name varchar(32) not null ,
  PRIMARY KEY (file_flag)
);

insert into olc_cm_file_flags (file_flag, file_flag_name) values ('0', 'information');
insert into olc_cm_file_flags (file_flag, file_flag_name) values ('1', 'content');
insert into olc_cm_file_flags (file_flag, file_flag_name) values ('2', 'links');
insert into olc_cm_file_flags (file_flag, file_flag_name) values ('900', 'affiliate');

drop table if exists olc_configuration;
create table olc_configuration (
  configuration_id int(11) not null auto_increment,
  configuration_key varchar(64) not null ,
  configuration_value text not null ,
  configuration_group_id int(11) default '0' not null ,
  sort_order int(5) ,
  last_modified datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  use_function varchar(255) ,
  set_function varchar(255) ,
  PRIMARY KEY (configuration_id),
  KEY idx_configuration_group_id (configuration_group_id)
);

insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('1', 'DB_VERSION', '2.0', '0', '0', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('2', 'EXPECTED_PRODUCTS_SORT', 'desc', '1', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'asc\', \'desc\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('3', 'EXPECTED_PRODUCTS_FIELD', 'date_expected', '1', '8', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'products_name\', \'date_expected\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('4', 'USE_DEFAULT_LANGUAGE_CURRENCY', 'false', '1', '9', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('5', 'DISPLAY_CART', 'true', '1', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('6', 'ALLOW_GUEST_TO_TELL_A_FRIEND', 'false', '1', '11', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('7', 'ADVANCED_SEARCH_DEFAULT_OPERATOR', 'and', '1', '12', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\"and\', \'or\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('8', 'SHOW_COUNTS', 'true', '1', '14', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('9', 'DEFAULT_CUSTOMERS_STATUS_ID_ADMIN', '0', '1', '15', NULL, '2007-07-26 17:38:47', 'xtc_get_customers_status_name', 'xtc_cfg_pull_down_customers_status_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('10', 'DEFAULT_CUSTOMERS_STATUS_ID_GUEST', '1', '1', '16', NULL, '2007-07-26 17:38:47', 'xtc_get_customers_status_name', 'xtc_cfg_pull_down_customers_status_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('11', 'DEFAULT_CUSTOMERS_STATUS_ID_COMPANY', '3', '1', '16', NULL, '2007-07-26 17:38:47', 'xtc_get_customers_status_name', 'xtc_cfg_pull_down_customers_status_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('12', 'CUSTOMER_STATUS_NO_FERNAG_INFO_IDS', '', '1', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('13', 'DEFAULT_CUSTOMERS_STATUS_ID', '2', '1', '18', NULL, '2007-07-26 17:38:47', 'xtc_get_customers_status_name', 'xtc_cfg_pull_down_customers_status_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('14', 'ALLOW_ADD_TO_CART', 'false', '1', '19', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('15', 'ALLOW_CATEGORY_DESCRIPTIONS', 'true', '1', '20', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('16', 'PRICE_IS_BRUTTO', 'true', '1', '22', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('17', 'PRICE_PRECISION', '4', '1', '23', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('18', 'NO_TAX_RAISED', '0', '1', '24', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('19', 'USE_STICKY_CART', '1', '1', '25', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('20', 'SHOW_SHORT_CART_ONLY', '0', '1', '25', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('21', 'USE_PDF_INVOICE', '1', '1', '26', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('22', 'CAO_INCLUDE', '0', '1', '28', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('23', 'EASYSALES_INCLUDE', '0', '1', '29', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('24', 'CRON_JOBS_LIST', '', '1', '30', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_textarea(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('25', 'VISITOR_PDF_CATALOGUE', 'false', '1', '31', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('26', 'GALLERY_PICTURES_PER_PAGE', '100', '1', '37', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('27', 'GALLERY_PICTURES_PER_LINE', '6', '1', '38', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('28', 'TRACKING_PRODUCTS_HISTORY_ENTRIES', '10', '1', '39', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('29', 'EBAY_FUNCTIONS_INCLUDE', 'false', '1', '42', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('30', 'STORE_NAME', 'GAMEWARE Computer und Spiele', '100', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('31', 'STORE_OWNER', 'OL-Commerce', '100', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('32', 'STORE_OWNER_EMAIL_ADDRESS', 'smichl@paar.de', '100', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('33', 'EMAIL_FROM', 'info@paar.de', '100', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('34', 'STORE_COUNTRY', '81', '100', '5', NULL, '2007-07-26 17:38:47', 'xtc_get_country_name', 'xtc_cfg_pull_down_country_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('35', 'STORE_ZONE', '', '100', '6', NULL, '2007-07-26 17:38:47', 'xtc_cfg_get_zone_name', 'xtc_cfg_pull_down_zone_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('36', 'STORE_NAME_ADDRESS', 'Shop Name
Addesse
Land-Plz Ort
Tel
Fax', '100', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_textarea(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('37', 'STORE_BANK_NAME', 'Stadtsparkasse Aichach', '100', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('38', 'STORE_BANK_BLZ', '7205120', '100', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('39', 'STORE_BANK_ACCOUNT', '6502', '100', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('40', 'STORE_BANK_BIC', '', '100', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('41', 'STORE_BANK_IBAN', '', '100', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('42', 'STORE_USTID', 'DE156161121', '100', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('43', 'STORE_TAXNR', '', '100', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('44', 'STORE_REGISTER', 'Amtsgericht Aichach', '100', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('45', 'STORE_REGISTER_NR', '', '100', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('46', 'STORE_MANAGER', 'Stefan Michl', '100', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('47', 'STORE_DIRECTOR', '', '100', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('48', 'ENTRY_FIRST_NAME_MIN_LENGTH', '2', '2', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('49', 'ENTRY_LAST_NAME_MIN_LENGTH', '2', '2', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('50', 'ENTRY_DOB_MIN_LENGTH', '10', '2', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('51', 'ENTRY_EMAIL_ADDRESS_MIN_LENGTH', '6', '2', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('52', 'ENTRY_STREET_ADDRESS_MIN_LENGTH', '5', '2', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('53', 'ENTRY_COMPANY_MIN_LENGTH', '2', '2', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('54', 'ENTRY_POSTCODE_MIN_LENGTH', '4', '2', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('55', 'ENTRY_CITY_MIN_LENGTH', '3', '2', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('56', 'ENTRY_STATE_MIN_LENGTH', '2', '2', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('57', 'ENTRY_TELEPHONE_MIN_LENGTH', '3', '2', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('58', 'ENTRY_PASSWORD_MIN_LENGTH', '5', '2', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('59', 'CC_OWNER_MIN_LENGTH', '3', '2', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('60', 'CC_NUMBER_MIN_LENGTH', '10', '2', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('61', 'REVIEW_TEXT_MIN_LENGTH', '50', '2', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('62', 'MIN_DISPLAY_BESTSELLERS', '1', '2', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('63', 'MIN_DISPLAY_ALSO_PURCHASED', '1', '2', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('64', 'MAX_ADDRESS_BOOK_ENTRIES', '5', '3', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('65', 'MAX_DISPLAY_SEARCH_RESULTS', '20', '3', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('66', 'MAX_DISPLAY_PAGE_LINKS', '5', '3', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('67', 'MAX_DISPLAY_SPECIAL_PRODUCTS', '9', '3', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('68', 'MAX_DISPLAY_NEW_PRODUCTS', '9', '3', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('69', 'MAX_DISPLAY_UPCOMING_PRODUCTS', '10', '3', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('70', 'MAX_DISPLAY_MANUFACTURERS_IN_A_LIST', '0', '3', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('71', 'MAX_MANUFACTURERS_LIST', '1', '3', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('72', 'MAX_DISPLAY_MANUFACTURER_NAME_LEN', '15', '3', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('73', 'MAX_DISPLAY_NEW_REVIEWS', '6', '3', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('74', 'MAX_RANDOM_SELECT_REVIEWS', '10', '3', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('75', 'MAX_RANDOM_SELECT_NEW', '10', '3', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('76', 'MAX_RANDOM_SELECT_SPECIALS', '10', '3', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('77', 'MAX_DISPLAY_CATEGORIES_PER_ROW', '3', '3', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('78', 'MAX_DISPLAY_PRODUCTS_NEW', '10', '3', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('79', 'MAX_DISPLAY_BESTSELLERS', '10', '3', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('80', 'MAX_DISPLAY_ALSO_PURCHASED', '6', '3', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('81', 'MAX_DISPLAY_PRODUCTS_IN_ORDER_HISTORY_BOX', '6', '3', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('82', 'MAX_DISPLAY_ORDER_HISTORY', '10', '3', '19', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('83', 'PRODUCT_REVIEWS_VIEW', '5', '3', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('84', 'MAX_PRODUCTS_QTY', '1000', '3', '21', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('85', 'CONFIG_CALCULATE_IMAGE_SIZE', 'true', '4', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('86', 'IMAGE_QUALITY', '80', '4', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('87', 'MO_PICS', '0', '4', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('88', 'PRODUCT_IMAGE_INFO_BEVEL', '', '4', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('89', 'PRODUCT_IMAGE_INFO_DROP_SHADDOW', '(3,333333,FFFFFF)', '4', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('90', 'PRODUCT_IMAGE_INFO_ELLIPSE', '', '4', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('91', 'PRODUCT_IMAGE_INFO_FRAME', '(FFFFFF,000000,3,EEEEEE)', '4', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('92', 'PRODUCT_IMAGE_INFO_GREYSCALE', '', '4', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('93', 'PRODUCT_IMAGE_INFO_HEIGHT', '160', '4', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('94', 'PRODUCT_IMAGE_INFO_MERGE', '(overlay.gif,10,-50,60,FF0000)', '4', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('95', 'PRODUCT_IMAGE_INFO_MOTION_BLUR', '', '4', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('96', 'PRODUCT_IMAGE_INFO_ROUND_EDGES', '', '4', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('97', 'PRODUCT_IMAGE_INFO_WIDTH', '200', '4', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('98', 'PRODUCT_IMAGE_POPUP_BEVEL', '(8,FFCCCC,330000)', '4', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('99', 'PRODUCT_IMAGE_POPUP_DROP_SHADDOW', '', '4', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('100', 'PRODUCT_IMAGE_POPUP_ELLIPSE', '', '4', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('101', 'PRODUCT_IMAGE_POPUP_FRAME', '', '4', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('102', 'PRODUCT_IMAGE_POPUP_GREYSCALE', '', '4', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('103', 'PRODUCT_IMAGE_POPUP_HEIGHT', '240', '4', '19', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('104', 'PRODUCT_IMAGE_POPUP_MERGE', '(overlay.gif,10,-50,60,FF0000)', '4', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('105', 'PRODUCT_IMAGE_POPUP_MOTION_BLUR', '', '4', '21', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('106', 'PRODUCT_IMAGE_POPUP_ROUND_EDGES', '', '4', '22', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('107', 'PRODUCT_IMAGE_POPUP_WIDTH', '300', '4', '23', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('108', 'PRODUCT_IMAGE_THUMBNAIL_BEVEL', '', '4', '24', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('109', 'PRODUCT_IMAGE_THUMBNAIL_DROP_SHADDOW', '', '4', '25', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('110', 'PRODUCT_IMAGE_THUMBNAIL_ELLIPSE', '', '4', '26', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('111', 'PRODUCT_IMAGE_THUMBNAIL_FRAME', '(FFFFFF,000000,3,EEEEEE)', '4', '27', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('112', 'PRODUCT_IMAGE_THUMBNAIL_GREYSCALE', '', '4', '28', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('113', 'PRODUCT_IMAGE_THUMBNAIL_HEIGHT', '80', '4', '29', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('114', 'PRODUCT_IMAGE_THUMBNAIL_MERGE', '', '4', '30', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('115', 'PRODUCT_IMAGE_THUMBNAIL_MOTION_BLUR', '(4,FFFFFF)', '4', '31', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('116', 'PRODUCT_IMAGE_THUMBNAIL_ROUND_EDGES', '', '4', '32', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('117', 'PRODUCT_IMAGE_THUMBNAIL_WIDTH', '120', '4', '33', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('118', 'PRODUCT_IMAGE_ON_THE_FLY', 'false', '4', '34', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('119', 'ACCOUNT_GENDER', 'true', '5', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('120', 'ACCOUNT_DOB', 'true', '5', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('121', 'ACCOUNT_COMPANY', 'true', '5', '3', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('122', 'ACCOUNT_SUBURB', 'true', '5', '4', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('123', 'ACCOUNT_STATE', 'true', '5', '5', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('124', 'ACCOUNT_OPTIONS', 'account', '5', '6', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'account\', \'guest\', \'both\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('125', 'DELETE_GUEST_ACCOUNT', 'true', '5', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('126', 'DEFAULT_CURRENCY', 'EUR', '6', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('127', 'DEFAULT_LANGUAGE', 'de', '6', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('128', 'DEFAULT_ORDERS_STATUS_ID', '1', '6', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('129', 'DEFAULT_SHIPPING_STATUS_ID', '1', '6', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('130', 'MODULE_EXPORT_INSTALLED', 'froogle.php;geizhals.php;image_processing.php;kelkoo.php;metashopper.php;milando.php;preisauskunft.php;preissuchmaschine.php;preistrend.php;vivendi.php', '6', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('131', 'MODULE_ORDER_TOTAL_INSTALLED', 'ot_subtotal.php;ot_shipping.php;ot_tax.php;ot_total.php', '6', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('132', 'MODULE_PAYMENT_INSTALLED', '', '6', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('133', 'MODULE_SHIPPING_INSTALLED', '', '6', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('134', 'MODULE_FROOGLE_FILE', 'froogle.txt', '6', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('135', 'MODULE_FROOGLE_STATUS', 'True', '6', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('136', 'MODULE_GEIZHALS_FILE', 'geizhals.csv', '6', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('137', 'MODULE_GEIZHALS_STATUS', 'True', '6', '12', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('138', 'MODULE_IMAGE_PROCESS_STATUS', 'True', '6', '13', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('139', 'MODULE_KELKOO_FILE', 'kelkoo.txt', '6', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('140', 'MODULE_KELKOO_STATUS', 'True', '6', '15', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('141', 'MODULE_METASHOPPER_FILE', 'metashopper.csv', '6', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('142', 'MODULE_METASHOPPER_STATUS', 'True', '6', '17', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('143', 'MODULE_MILANDO_FILE', 'milando.csv', '6', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('144', 'MODULE_MILANDO_STATUS', 'True', '6', '19', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('145', 'MODULE_ORDER_TOTAL_DISCOUNT_STATUS', 'true', '6', '20', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('146', 'MODULE_ORDER_TOTAL_SHIPPING_STATUS', 'true', '6', '21', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('147', 'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_STATUS', 'true', '6', '22', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('148', 'MODULE_ORDER_TOTAL_SUBTOTAL_STATUS', 'true', '6', '23', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('149', 'MODULE_ORDER_TOTAL_TAX_STATUS', 'true', '6', '24', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('150', 'MODULE_ORDER_TOTAL_TOTAL_STATUS', 'true', '6', '25', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('151', 'MODULE_PREISAUSKUNFT_FILE', 'preisauskunft.csv', '6', '26', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('152', 'MODULE_PREISAUSKUNFT_STATUS', 'True', '6', '27', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('153', 'MODULE_PREISSUCHMASCHINE_FILE', 'preissuchmaschine.csv', '6', '28', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('154', 'MODULE_PREISSUCHMASCHINE_STATUS', 'True', '6', '29', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('155', 'MODULE_PREISTREND_FILE', 'preistrend.txt', '6', '30', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('156', 'MODULE_PREISTREND_STATUS', 'True', '6', '31', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('157', 'MODULE_VIVENDI_FILE', 'vivendi.csv', '6', '32', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('158', 'MODULE_VIVENDI_STATUS', 'True', '6', '33', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('159', 'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_SORT_ORDER', '40', '6', '34', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('160', 'MODULE_ORDER_TOTAL_DISCOUNT_SORT_ORDER', '20', '6', '35', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('161', 'MODULE_ORDER_TOTAL_SHIPPING_SORT_ORDER', '30', '6', '36', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('162', 'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER', '10', '6', '37', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('163', 'MODULE_ORDER_TOTAL_TAX_SORT_ORDER', '50', '6', '38', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('164', 'MODULE_ORDER_TOTAL_TOTAL_SORT_ORDER', '99', '6', '39', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('165', 'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING', 'false', '6', '40', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('166', 'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER', '50', '6', '41', NULL, '2007-07-26 17:38:47', 'currencies->format', NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('167', 'MODULE_ORDER_TOTAL_SHIPPING_DESTINATION', 'national', '6', '42', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'national\', \'international\', \'both\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('168', 'SHIPPING_ORIGIN_COUNTRY', '81', '7', '1', NULL, '2007-07-26 17:38:47', 'xtc_get_country_name', 'xtc_cfg_pull_down_country_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('169', 'SHIPPING_ORIGIN_ZIP', '86551', '7', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('170', 'SHIPPING_MAX_WEIGHT', '50', '7', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('171', 'SHIPPING_BOX_WEIGHT', '3', '7', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('172', 'SHIPPING_BOX_PADDING', '10', '7', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('173', 'PRODUCT_LIST_FILTER', '1', '8', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('174', 'STOCK_CHECK', 'true', '9', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('175', 'ATTRIBUTE_STOCK_CHECK', 'true', '9', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('176', 'STOCK_LIMITED', 'true', '9', '3', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('177', 'STOCK_ALLOW_CHECKOUT', 'true', '9', '4', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('178', 'STOCK_MARK_PRODUCT_OUT_OF_STOCK', '***', '9', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('179', 'STOCK_REORDER_LEVEL', '5', '9', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('180', 'STORE_PAGE_PARSE_TIME', 'false', '10', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('181', 'STORE_PAGE_PARSE_TIME_LOG', 'tmp/page_parse_time.log', '10', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('182', 'STORE_PARSE_DATE_TIME_FORMAT', '%d.%m.%Y %H:%M:%S', '10', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('183', 'DISPLAY_PAGE_PARSE_TIME', 'true', '10', '4', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('184', 'STORE_DB_TRANSACTIONS', 'false', '10', '5', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('185', 'CACHE_CHECK', 'true', '11', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('186', 'USE_CACHE', 'false', '11', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('187', 'DIR_FS_CACHE', 'cache', '11', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('188', 'CACHE_LIFETIME', '3600', '11', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('189', 'DB_CACHE', 'false', '11', '5', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('190', 'DB_CACHE_EXPIRE', '3600', '11', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('191', 'EMAIL_TRANSPORT', 'mail', '12', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'sendmail\', \'smtp\', \'mail\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('192', 'SENDMAIL_PATH', '/usr/sbin/sendmail', '12', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('193', 'SMTP_MAIN_SERVER', 'localhost', '12', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('194', 'SMTP_Backup_Server', 'localhost', '12', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('195', 'SMTP_PORT', '25', '12', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('196', 'SMTP_USERNAME', 'Please Enter', '12', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('197', 'SMTP_PASSWORD', 'Please Enter', '12', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('198', 'SMTP_AUTH', 'false', '12', '8', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('199', 'EMAIL_LINEFEED', 'LF', '12', '9', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'LF\', \'CRLF\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('200', 'EMAIL_USE_HTML', 'false', '12', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('201', 'ENTRY_EMAIL_ADDRESS_CHECK', 'false', '12', '11', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('202', 'SEND_EMAILS', 'true', '12', '12', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('203', 'CONTACT_US_EMAIL_ADDRESS', 'info@paar.de', '12', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('204', 'CONTACT_US_NAME', 'Mail sent by Contact_us Form', '12', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('205', 'CONTACT_US_REPLY_ADDRESS', '', '12', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('206', 'CONTACT_US_REPLY_ADDRESS_NAME', '', '12', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('207', 'CONTACT_US_EMAIL_SUBJECT', '', '12', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('208', 'CONTACT_US_FORWARDING_STRING', '', '12', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('209', 'EMAIL_SUPPORT_ADDRESS', 'info@paar.de', '12', '19', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('210', 'EMAIL_SUPPORT_NAME', 'Mail sent by support systems', '12', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('211', 'EMAIL_SUPPORT_REPLY_ADDRESS', '', '12', '21', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('212', 'EMAIL_SUPPORT_REPLY_ADDRESS_NAME', '', '12', '22', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('213', 'EMAIL_SUPPORT_SUBJECT', '', '12', '23', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('214', 'EMAIL_SUPPORT_FORWARDING_STRING', '', '12', '24', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('215', 'EMAIL_BILLING_ADDRESS', 'info@paar.de', '12', '25', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('216', 'EMAIL_BILLING_NAME', 'Mail sent by billing systems', '12', '26', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('217', 'EMAIL_BILLING_REPLY_ADDRESS', '', '12', '27', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('218', 'EMAIL_BILLING_REPLY_ADDRESS_NAME', '', '12', '28', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('219', 'EMAIL_BILLING_SUBJECT', '', '12', '29', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('220', 'EMAIL_BILLING_FORWARDING_STRING', 'info@paar.de', '12', '30', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('221', 'EMAIL_BILLING_SUBJECT_ORDER', 'Your order Nr:{$nr} / {$date}', '12', '31', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('222', 'EMAIL_NEWSLETTER_PACAKGE_SIZE', '30', '12', '32', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('223', 'SEND_404_EMAIL', 'true', '12', '0', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('224', 'DOWNLOAD_ENABLED', 'false', '13', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('225', 'DOWNLOAD_BY_REDIRECT', 'false', '13', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('226', 'DOWNLOAD_MAX_DAYS', '7', '13', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('227', 'DOWNLOAD_MAX_COUNT', '5', '13', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('228', 'GZIP_COMPRESSION', 'false', '14', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('229', 'GZIP_LEVEL', '5', '14', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('230', 'SESSION_WRITE_DIRECTORY', '/tmp', '15', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('231', 'SESSION_FORCE_COOKIE_USE', 'False', '15', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('232', 'SESSION_CHECK_SSL_SESSION_ID', 'False', '15', '3', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('233', 'SESSION_CHECK_USER_AGENT', 'False', '15', '4', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('234', 'SESSION_CHECK_IP_ADDRESS', 'False', '15', '5', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('235', 'SESSION_BLOCK_SPIDERS', 'False', '15', '6', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('236', 'SESSION_RECREATE', 'False', '15', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('237', 'META_MIN_KEYWORD_LENGTH', '6', '16', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('238', 'META_KEYWORDS_NUMBER', '5', '16', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('239', 'META_AUTHOR', '', '16', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('240', 'META_PUBLISHER', '', '16', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('241', 'META_COMPANY', '', '16', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('242', 'META_TOPIC', 'shopping', '16', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('243', 'META_REPLY_TO', 'xx@xx.com', '16', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('244', 'META_REVISIT_AFTER', '14', '16', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('245', 'META_ROBOTS', 'index,follow', '16', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('246', 'META_DESCRIPTION', '', '16', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('247', 'META_KEYWORDS', '', '16', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('248', 'SEARCH_ENGINE_FRIENDLY_URLS', 'false', '16', '12', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('249', 'USE_SEO_EXTENDED', 'true', '16', '13', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('250', 'SEO_SEPARATOR', '-', '16', '14', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'-\', \'/\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('251', 'SEO_TERMINATOR', '.htm', '16', '16', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'.htm\', \'.html\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('252', 'SPIDER_FOOD_ROWS', '100', '16', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('253', 'USE_SPAW', 'true', '17', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('254', 'ACTIVATE_GIFT_SYSTEM', 'false', '17', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('255', 'SECURITY_CODE_LENGTH', '10', '17', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('256', 'NEW_SIGNUP_GIFT_VOUCHER_AMOUNT', '0', '17', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('257', 'NEW_SIGNUP_DISCOUNT_COUPON', '', '17', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('258', 'ACTIVATE_SHIPPING_STATUS', 'true', '17', '6', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('259', 'CHECK_CLIENT_AGENT', 'false', '17', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('260', 'DISPLAY_CONDITIONS_ON_CHECKOUT', 'false', '17', '8', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('261', 'SHOW_IP_LOG', 'false', '17', '9', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('262', 'GROUP_CHECK', 'true', '17', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('263', 'ACTIVATE_NAVIGATOR', 'false', '17', '11', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('264', 'QUICKLINK_ACTIVATED', 'true', '17', '12', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('265', 'DOWN_FOR_MAINTENANCE', 'false', '18', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('266', 'EXCLUDE_ADMIN_IP_FOR_MAINTENANCE', 'Ihre IP (ADMIN)', '18', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('267', 'ADMIN_PASSWORD_FOR_MAINTENANCE', 'olcommerce', '18', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('268', 'WARN_BEFORE_DOWN_FOR_MAINTENANCE', 'false', '18', '4', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('269', 'PERIOD_DOWN_FOR_MAINTENANCE', '', '18', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('270', 'AFFILIATE_EMAIL_ADDRESS', 'affiliate@localhost.com', '900', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('271', 'AFFILIATE_PERCENT', '10.0000', '900', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('272', 'AFFILIATE_THRESHOLD', '50.00', '900', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('273', 'AFFILIATE_COOKIE_LIFETIME', '7200', '900', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('274', 'AFFILIATE_BILLING_TIME', '30', '900', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('275', 'AFFILIATE_PAYMENT_ORDER_MIN_STATUS', '3', '900', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('276', 'AFFILIATE_USE_CHECK', 'true', '900', '7', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('277', 'AFFILIATE_USE_PAYPAL', 'true', '900', '8', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('278', 'AFFILIATE_USE_BANK', 'true', '900', '9', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('279', 'AFFILATE_INDIVIDUAL_PERCENTAGE', 'true', '900', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('280', 'AFFILATE_USE_TIER', 'false', '900', '11', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('281', 'AFFILIATE_TIER_LEVELS', '0', '900', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('282', 'AFFILIATE_TIER_PERCENTAGE', '8.00;5.00;1.00', '900', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('283', 'DEFAULT_PRODUCTS_VPE_ID', '0', '1000', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('284', 'SLIDESHOW_INTERVAL', '5', '19', '0', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('285', 'SLIDESHOW_INTERVAL_MIN', '3', '19', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('286', 'SLIDESHOW_PRODUCTS', 'false', '19', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('287', 'SLIDESHOW_PRODUCTS_HEIGHT', '230', '19', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('288', 'SLIDESHOW_PRODUCTS_WIDTH', '400', '19', '30', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('289', 'SLIDESHOW_PRODUCTS_BORDER', 'false', '19', '40', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('290', 'SLIDESHOW_PRODUCTS_CONTROLS', 'true', '19', '41', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('291', 'SLIDESHOW_IMAGES', 'false', '19', '50', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('292', 'SLIDESHOW_IMAGES_HEIGHT', '230', '19', '60', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('293', 'SLIDESHOW_IMAGES_WIDTH', '400', '19', '70', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('294', 'SLIDESHOW_IMAGES_BORDER', 'false', '19', '80', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('295', 'SLIDESHOW_IMAGES_CONTROLS', 'true', '19', '81', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('296', 'SLIDESHOW_IMAGES_SHOW_TEXT', 'true', '19', '90', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('297', 'CSV_TEXTSIGN', '\"', '20', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('298', 'CSV_SEPERATOR', '	', '20', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('299', 'COMPRESS_EXPORT', 'false', '20', '30', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('300', 'PDF_INVOICE_ORDER_CONFIRMATION', '1', '787', '0', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('301', 'PDF_INVOICE_MARK_COLOR', 'Black', '787', '1', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('302', 'PDF_INVOICE_MARK_COLOR_BG', 'Lightgrey', '787', '2', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('303', 'STORE_INVOICE_NUMBER', '12345', '787', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('304', 'STORE_PACKINGSLIP_NUMBER', '23456', '787', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('305', 'PDF_SHOW_LOGO', '1', '800', '1', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('306', 'PDF_IMAGE_KEEP_PROPORTIONS', '1', '800', '3', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('307', 'PDF_MAX_IMAGE_WIDTH', '200', '800', '4', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('308', 'PDF_MAX_IMAGE_HEIGHT', '200', '800', '5', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('309', 'PDF_SHOW_WATERMARK', '1', '800', '6', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('310', 'PDF_DOC_PATH', 'pdfdocs/', '800', '7', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('311', 'PDF_FILE_REDIRECT', '0', '800', '8', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('312', 'PDF_SHOW_BACKGROUND', '0', '800', '9', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('313', 'PDF_SAVE_DOCUMENT', '1', '800', '10', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('314', 'PDF_SHOW_PATH', '1', '800', '11', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('315', 'PDF_SHOW_IMAGES', '1', '800', '12', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('316', 'PDF_SHOW_MODEL', '1', '800', '13', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('317', 'PDF_SHOW_SHIPPING_TIME', '1', '800', '14', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('318', 'PDF_SHOW_DESCRIPTION', '1', '800', '15', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('319', 'PDF_SHOW_SHORT_DESCRIPTION', '1', '800', '16', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('320', 'PDF_SHOW_MANUFACTURER', '1', '800', '17', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('321', 'PDF_SHOW_PRICE', '1', '800', '18', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('322', 'PDF_SHOW_SPECIALS_PRICE', '1', '800', '19', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('323', 'PDF_SHOW_SPECIALS_PRICE_EXPIRES', '1', '800', '20', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('324', 'PDF_SHOW_OPTIONS', '1', '800', '21', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('325', 'PDF_SHOW_OPTIONS_PRICE', '1', '800', '22', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('326', 'PDF_SHOW_DATE_ADDED_AVAILABLE', '1', '800', '23', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('327', 'PDF_PAGE_BG_COLOR', 'ivory', '800', '24', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('328', 'PDF_HEADER_COLOR_TABLE', 'brown', '800', '25', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('329', 'PDF_HEADER_COLOR_TEXT', 'firebrick', '800', '26', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('330', 'PDF_BODY_COLOR_TEXT', 'brown', '800', '27', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('331', 'PDF_PRODUCT_NAME_COLOR_TABLE', 'Lightgrey', '800', '28', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('332', 'PDF_PRODUCT_NAME_COLOR_TEXT', 'white', '800', '29', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('333', 'PDF_FOOTER_CELL_BG_COLOR', 'silver', '800', '30', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('334', 'PDF_FOOTER_CELL_TEXT_COLOR', 'black', '800', '31', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('335', 'PDF_SPECIAL_PRICE_COLOR_TEXT', 'red', '800', '32', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('336', 'PDF_PAGE_WATERMARK_COLOR', 'aliceblue', '800', '33', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('337', 'PDF_OPTIONS_COLOR', 'black', '800', '34', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('338', 'PDF_OPTIONS_BG_COLOR', 'Lightgrey', '800', '35', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_display_color_sample(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('339', 'CURRENT_TEMPLATE', 'olc', '795', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_pull_down_template_sets(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('340', 'NO_BOX_LAYOUT', 'false', '795', '20', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('341', 'USE_UNIFIED_TEMPLATES', 'true', '795', '30', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('342', 'CHECK_UNIFIED_BOXES', 'false', '795', '40', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('343', 'OPEN_ALL_MENUE_LEVELS', 'false', '795', '50', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('344', 'SHOW_TAB_NAVIGATION', 'false', '795', '60', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('345', 'USE_COOL_MENU', 'false', '795', '70', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('346', 'USE_CSS_MENU', 'true', '795', '75', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('347', 'PRODUCTS_LISTING_COLUMNS', '2', '795', '80', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'1\', \'2\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('348', 'EBAY_MEMBER_NAME', 'ihr_ebay_name', '790', '0', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('349', 'EBAY_REAL_SHOP_URL', 'http://www.mein-shop-server.de/', '790', '2', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('350', 'EBAY_EBAY_EXPRESS_ONLY', 'false', '790', '10', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('351', 'EBAY_SHIPPING_MODULE', '', '790', '20', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_pull_down_shipping_list(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('352', 'EBAY_PAYPAL_EMAIL_ADDRESS', '', '790', '30', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('353', 'EBAY_TEST_MODE', 'true', '790', '40', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_select_option(array(\'true\', \'false\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('354', 'EBAY_TEST_MODE_DEVID', '', '790', '42', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('355', 'EBAY_TEST_MODE_APPID', '', '790', '44', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('356', 'EBAY_TEST_MODE_CERTID', '', '790', '46', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('357', 'EBAY_TEST_MODE_TOKEN', '', '790', '48', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_textarea(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('358', 'EBAY_PRODUCTION_DEVID', '', '790', '52', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('359', 'EBAY_PRODUCTION_APPID', '', '790', '54', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('360', 'EBAY_PRODUCTION_CERTID', '', '790', '56', NULL, '2007-07-26 17:38:47', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('361', 'EBAY_PRODUCTION_TOKEN', '', '790', '58', NULL, '2007-07-26 17:38:47', NULL, 'xtc_cfg_textarea(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('362', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('363', 'MODULE_PAYMENT_BARZAHL_STATUS', 'True', '6', '1', NULL, '2007-07-26 17:56:59', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('364', 'MODULE_PAYMENT_BARZAHL_ALLOWED', 'DE', '6', '0', NULL, '2007-07-26 17:56:59', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('365', 'MODULE_PAYMENT_BARZAHL_ZONE', '5', '6', '2', NULL, '2007-07-26 17:56:59', 'xtc_get_zone_class_title', 'xtc_cfg_pull_down_zone_classes(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('366', 'MODULE_PAYMENT_BARZAHL_SORT_ORDER', '0', '6', '0', NULL, '2007-07-26 17:56:59', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('367', 'MODULE_PAYMENT_BARZAHL_ORDER_STATUS_ID', '0', '6', '0', NULL, '2007-07-26 17:56:59', 'xtc_get_order_status_name', 'xtc_cfg_pull_down_order_statuses(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('368', 'MODULE_SHIPPING_DP_STATUS', 'True', '6', '0', NULL, '2007-08-02 18:03:44', NULL, 'xtc_cfg_select_option(array(\'True\', \'False\'),');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('369', 'MODULE_SHIPPING_DP_HANDLING', '0', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('370', 'MODULE_SHIPPING_DP_TAX_CLASS', '1', '6', '0', NULL, '2007-08-02 18:03:44', 'xtc_get_tax_class_title', 'xtc_cfg_pull_down_tax_classes(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('371', 'MODULE_SHIPPING_DP_ZONE', '5', '6', '0', NULL, '2007-08-02 18:03:44', 'xtc_get_zone_class_title', 'xtc_cfg_pull_down_zone_classes(');
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('372', 'MODULE_SHIPPING_DP_SORT_ORDER', '0', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('373', 'MODULE_SHIPPING_DP_ALLOWED', 'DE', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('374', 'MODULE_SHIPPING_DP_COUNTRIES_1', 'AD,AT,BE,CZ,DK,FO,FI,FR,GR,GL,IE,IT,LI,LU,MC,NL,PL,PT,SM,SK,SE,CH,VA,GB,SP', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('375', 'MODULE_SHIPPING_DP_COST_1', '5:16.50,10:20.50,20:28.50', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('376', 'MODULE_SHIPPING_DP_COUNTRIES_2', 'AL,AM,AZ,BY,BA,BG,HR,CY,GE,GI,HU,IS,KZ,LT,MK,MT,MD,NO,SI,UA,TR,YU,RU,RO,LV,EE', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('377', 'MODULE_SHIPPING_DP_COST_2', '5:25.00,10:35.00,20:45.00', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('378', 'MODULE_SHIPPING_DP_COUNTRIES_3', 'DZ,BH,CA,EG,IR,IQ,IL,JO,KW,LB,LY,OM,SA,SY,US,AE,YE,MA,QA,TN,PM', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('379', 'MODULE_SHIPPING_DP_COST_3', '5:29.00,10:39.00,20:59.00', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('380', 'MODULE_SHIPPING_DP_COUNTRIES_4', 'AF,AS,AO,AI,AG,AR,AW,AU,BS,BD,BB,BZ,BJ,BM,BT,BO,BW,BR,IO,BN,BF,BI,KH,CM,CV,KY,CF,TD,CL,CN,CC,CO,KM,CG,CR,CI,CU,DM,DO,EC,SV,ER,ET,FK,FJ,GF,PF,GA,GM,GH,GD,GP,GT,GN,GW,GY,HT,HN,HK,IN,id,JM,JP,KE,KI,KG,KP,KR,LA,LS', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('381', 'MODULE_SHIPPING_DP_COST_4', '5:35.00,10:50.00,20:80.00', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('382', 'MODULE_SHIPPING_DP_COUNTRIES_5', 'MO,MG,MW,MY,MV,ML,MQ,MR,MU,MX,MN,MS,MZ,MM,NA,NR,NP,AN,NC,NZ,NI,NE,NG,PK,PA,PG,PY,PE,PH,PN,RE,KN,LC,VC,SN,SC,SL,SO,LK,SR,SZ,ZA,SG,TG,TH,TZ,TT,TO,TM,TV,VN,WF,VE,UG,UZ,UY,ST,SH,SD,TW,GQ,LR,DJ,CG,RW,ZM,ZW', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('383', 'MODULE_SHIPPING_DP_COST_5', '5:35.00,10:50.00,20:80.00', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('384', 'MODULE_SHIPPING_DP_COUNTRIES_6', 'DE', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('385', 'MODULE_SHIPPING_DP_COST_6', '5:6.70,10:9.70,20:13.00', '6', '0', NULL, '2007-08-02 18:03:44', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('386', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('387', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('388', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('389', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('390', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('391', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('392', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('393', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('394', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('395', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('396', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('397', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('398', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('399', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('400', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('401', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('402', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('403', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('404', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('405', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('406', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('407', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('408', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('409', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('410', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('411', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('412', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('413', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);
insert into olc_configuration (configuration_id, configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('414', 'XTC_CONVERSION_DONE', '1', '0', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL);

drop table if exists olc_configuration_group;
create table olc_configuration_group (
  configuration_group_id int(11) not null auto_increment,
  configuration_group_title varchar(64) not null ,
  configuration_group_description varchar(255) not null ,
  sort_order int(5) ,
  visible int(1) default '1' ,
  PRIMARY KEY (configuration_group_id)
);

insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('900', 'Affiliate Program', 'Optionen des \"Affiliate\" Programms', '1', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('1', 'Mein Gesch�ft', 'Allgemeine Informationen �ber mein Gesch�ft', '1', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('100', 'Firmen-Daten', 'Name, Anschrift, eMail, Bank usw.', '1', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('2', 'Minimale Werte', 'Die Minimal-Werte f�r Funktionen/Daten', '2', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('3', 'Maximale Werte', 'Die Maximal-Werte f�r Funktionen/Daten', '3', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('4', 'Bild-Parameter', 'Einstellungen f�r Bild-Parameter', '4', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('5', 'Kunden-Details', 'Kunden-Konten Konfiguration', '5', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('6', 'Modul-Optionen', 'Erweiterte Modul-Optionen', '6', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('7', 'Versand-Optionen', 'Verf�gbare Versand-Optionen', '7', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('8', 'Produkt-Listen-Optionen', 'Konfiguration der Produkt-Listen-Optionen', '8', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('9', 'Lager-Verwaltung', 'Konfiguration der Lager-Optionen', '9', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('10', 'Logging-Optionen', 'Konfiguration der Logging-Optionen', '10', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('11', 'Cache-Optionen', 'Konfiguration der Cache-Optionen', '11', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('12', 'E-Mail Optionen', 'Optionen f�r den E-Mail Transport und HTML E-Mails', '12', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('13', 'Download-Optionen', 'Optionen f�r Download-Produkte', '13', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('14', 'GZip Kompression', 'Optionen f�r die GZip Kompression', '14', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('15', 'Sessions', 'Konfiguration der Session-Optionen', '15', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('16', 'Meta-Tags und Suchmaschinen', 'Konfiguration der Meta-Tags und Suchmaschinen-Optionen', '16', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('19', 'Slideshows', 'Konfiguration der Slideshow-Optionen', '19', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('20', 'Import/Export', 'Konfiguration der Import/Export-Optionen', '20', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('787', 'PDF-Rechnung', 'Einstellungen f�r die PDF-Rechnung', '17', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('800', 'PDF-Datenblatt-Generator', 'Konfiguriert den PDF-Datenblatt-Generator', '18', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('795', 'Men�s und Templates', 'Einstellungen f�r Men�s und Templates', '18', '1');
insert into olc_configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('790', 'eBay-Konnektor', 'Einstellungen f�r den eBay-Konnektor', '17', '1');

drop table if exists olc_content_manager;
create table olc_content_manager (
  content_id int(11) not null auto_increment,
  categories_id int(11) default '0' not null ,
  parent_id int(11) default '0' not null ,
  languages_id int(11) default '0' not null ,
  content_title text not null ,
  content_heading text not null ,
  content_text text not null ,
  file_flag int(1) default '0' not null ,
  content_file varchar(64) not null ,
  content_status int(1) default '0' not null ,
  content_group int(11) default '0' not null ,
  content_delete int(1) default '1' not null ,
  sort_order tinyint(4) default '0' not null ,
  PRIMARY KEY (content_id)
);

insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('1', '0', '0', '1', 'Shipping & Returns', 'Shipping & Returns', 'Put here your Shipping & Returns information.', '1', '', '1', '1', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('2', '0', '0', '1', 'Privacy Notice', 'Privacy Notice', 'Put here your Privacy Notice information.', '1', '', '1', '2', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('3', '0', '0', '1', 'Conditions of Use', 'Conditions of Use', 'Conditions of Use<br />Put here your Conditions of Use information. <br />1. Validity<br />2. Offers<br />3. Price<br />4. Dispatch and passage of the risk<br />5. Delivery<br />6. Terms of payment<br />7. Retention of title<br />8. Notices of defect, guarantee and compensation<br />9. Fair trading cancelling / non-acceptance<br />10. Place of delivery and area of jurisdiction<br />11. Final clauses', '1', '', '1', '3', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('4', '0', '0', '1', 'Impressum', 'Impressum', 'Put your&nbsp;Company information here.', '1', '', '1', '4', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('5', '0', '0', '1', 'Index', 'Willkommen', '{$greeting}<br/><br/> Dies ist die Standardinstallation des osCommerce Forking Projektes - OL-Commerce. Alle dargestellten Produkte dienen zur Demonstration der Funktionsweise. Wenn Sie Produkte bestellen, so werden diese weder ausgeliefert, noch in Rechnung gestellt. Alle Informationen zu den verschiedenen Produkten sind erfunden und daher kann kein Anspruch daraus abgeleitet werden.<br/><br/>Sollten Sie daran interessiert sein das Programm, welches die Grundlage f�r diesen Shop bildet, einzusetzen, so besuchen Sie bitte die Supportseite von OL-Commerce. Dieser Shop basiert auf OL-Commerce/AJAX <br/><br/>Der hier dargestellte Text kann im Admin-Bereich unter dem Punkt <b>Inhalte Manager</b>-Eintrag <b>Index</b> bearbeitet werden.', '1', '', '0', '5', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('6', '0', '0', '2', 'Liefer- und Versandkosten', 'Liefer- und Versandkosten', 'F�gen Sie hier Ihre Informationen �ber Liefer- und Versandkosten ein.', '1', '', '1', '1', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('7', '0', '0', '2', 'Privatsph�re und Datenschutz', 'Privatsph�re und Datenschutz', 'F�gen Sie hier Ihre Informationen �ber Privatsph�re und Datenschutz ein.', '1', '', '1', '2', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('8', '0', '0', '2', 'Unsere AGB\'s', 'Allgemeine Gesch�ftsbedingungen', '<strong>Allgemeine Gesch�ftsbedingungen<br/></strong><br/>F�gen Sie hier Ihre allgemeinen Gesch�ftsbedingungen ein.<br/>1. Geltung<br/>2. Angebote<br/>3. Preis<br/>4. Versand und Gefahr�bergang<br/>5. Lieferung<br/>6. Zahlungsbedingungen<br/>7. Eigentumsvorbehalt <br/>8. M�ngelr�gen, Gew�hrleistung und Schadenersatz<br/>9. Kulanzr�cknahme/Annahmeverweigerung<br/>10. Erf�llungsort und Gerichtsstand<br/>11. Schlussbestimmungen', '1', '', '1', '3', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('9', '0', '0', '2', 'Impressum', 'Impressum', 'F�gen Sie hier Ihr Impressum ein.', '1', '', '1', '4', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('10', '0', '0', '2', 'Index', 'Willkommen', '<p>{$greeting}<br/><br/>Dies ist die Standardinstallation des osCommerce Forking Projektes - OL-Commerce. Alle dargestellten Produkte dienen zur Demonstration der Funktionsweise. Wenn Sie Produkte bestellen, so werden diese weder ausgeliefert, noch in Rechnung gestellt. Alle Informationen zu den verschiedenen Produkten sind erfunden und daher kann kein Anspruch daraus abgeleitet werden.<br/><br/>Sollten Sie daran interessiert sein das Programm, welches die Grundlage f�r diesen Shop bildet, einzusetzen, so besuchen Sie bitte die Supportseite von OL-Commerce. Dieser Shop basiert auf der OL-Commerce Version v4/AJAX<br/><br/>Der hier dargestellte Text kann im AdminInterface unter dem Punkt <B>Content Manager</B> - Eintrag <b>Index</b> bearbeitet werden.</p>', '1', '', '0', '5', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('11', '0', '0', '2', 'Gutscheine', 'Gutscheine - Fragen und Antworte', '<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Gutscheine kaufen </strong></td></tr>
<tr>
<td class=main>Gutscheine k�nnen, falls sie im Shop angeboten werden, wie normale Artikel gekauft werden. Sobald Sie einen Gutschein gekauft haben und dieser nach erfolgreicher Zahlung freigeschaltet wurde, erscheint der Betrag unter Ihrem Warenkorb. Nun k�nnen Sie �ber den Link \" Gutschein versenden \" den gew�nschten Betrag per E-Mail versenden. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Wie man Gutscheine versendet </strong></td></tr>
<tr>
<td class=main>Um einen Gutschein zu versenden, klicken Sie bitte auf den Link \"Gutschein versenden\" in Ihrem Einkaufskorb. Um einen Gutschein zu versenden, ben�tigen wir folgende Angaben von Ihnen: Vor- und Nachname des Empf�ngers. Eine g�ltige E-Mail Adresse des Empf�ngers. Den gew�nschten Betrag (Sie k�nnen auch Teilbetr�ge Ihres Guthabens versenden). Eine kurze Nachricht an den Empf�nger. Bitte �berpr�fen Sie Ihre Angaben noch einmal vor dem Versenden. Sie haben vor dem Versenden jederzeit die M�glichkeit Ihre Angaben zu korrigieren. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Mit Gutscheinen Einkaufen. </strong></td></tr>
<tr>
<td class=main>Sobald Sie �ber ein Guthaben verf�gen, k�nnen Sie dieses zum Bezahlen Ihrer Bestellung verwenden. W�hrend des Bestellvorganges haben Sie die M�glichkeit Ihr Guthaben einzul�sen. Falls das Guthaben unter dem Warenwert liegt m�ssen Sie Ihre bevorzugte Zahlungsweise f�r den Differenzbetrag w�hlen. �bersteigt Ihr Guthaben den Warenwert, steht Ihnen das Restguthaben selbstverst�ndlich f�r Ihre n�chste Bestellung zur Verf�gung. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Gutscheine verbuchen. </strong></td></tr>
<tr>
<td class=main>Wenn Sie einen Gutschein per E-Mail erhalten haben, k�nnen Sie den Betrag wie folgt verbuchen:. <br/>1. Klicken Sie auf den in der E-Mail angegebenen Link. Falls Sie noch nicht �ber ein pers�nliches Kundenkonto verf�gen, haben Sie die M�glichkeit ein Konto zu er�ffnen. <br/>2. Nachdem Sie ein Produkt in den Warenkorb gelegt haben, k�nnen Sie dort Ihren Gutscheincode eingeben.</td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Falls es zu Problemen kommen sollte: </strong></td></tr>
<tr>
<td class=main>Falls es wider Erwarten zu Problemen mit einem Gutschein kommen sollte, kontaktieren Sie uns bitte per E-Mail : you@yourdomain.com. Bitte beschreiben Sie m�glichst genau das Problem, wichtige Angaben sind unter anderem: Ihre Kundennummer, der Gutscheincode, Fehlermeldungen des Systems sowie der von Ihnen benutzte Browser. </td></tr></TBODY></table>', '1', '', '0', '6', '1', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('12', '0', '0', '1', 'Gutscheine', 'Gutscheine - Fragen und Antworte', '<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Gutscheine kaufen </strong></td></tr>
<tr>
<td class=main>Gutscheine k�nnen, falls sie im Shop angeboten werden, wie normale Artikel gekauft werden. Sobald Sie einen Gutschein gekauft haben und dieser nach erfolgreicher Zahlung freigeschaltet wurde, erscheint der Betrag unter Ihrem Warenkorb. Nun k�nnen Sie �ber den Link \" Gutschein versenden \" den gew�nschten Betrag per E-Mail versenden. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Wie man Gutscheine versendet </strong></td></tr>
<tr>
<td class=main>Um einen Gutschein zu versenden, klicken Sie bitte auf den Link \"Gutschein versenden\" in Ihrem Einkaufskorb. Um einen Gutschein zu versenden, ben�tigen wir folgende Angaben von Ihnen: Vor- und Nachname des Empf�ngers. Eine g�ltige E-Mail Adresse des Empf�ngers. Den gew�nschten Betrag (Sie k�nnen auch Teilbetr�ge Ihres Guthabens versenden). Eine kurze Nachricht an den Empf�nger. Bitte �berpr�fen Sie Ihre Angaben noch einmal vor dem Versenden. Sie haben vor dem Versenden jederzeit die M�glichkeit Ihre Angaben zu korrigieren. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Mit Gutscheinen Einkaufen. </strong></td></tr>
<tr>
<td class=main>Sobald Sie �ber ein Guthaben verf�gen, k�nnen Sie dieses zum Bezahlen Ihrer Bestellung verwenden. W�hrend des Bestellvorganges haben Sie die M�glichkeit Ihr Guthaben einzul�sen. Falls das Guthaben unter dem Warenwert liegt m�ssen Sie Ihre bevorzugte Zahlungsweise f�r den Differenzbetrag w�hlen. �bersteigt Ihr Guthaben den Warenwert, steht Ihnen das Restguthaben selbstverst�ndlich f�r Ihre n�chste Bestellung zur Verf�gung. </td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Gutscheine verbuchen. </strong></td></tr>
<tr>
<td class=main>Wenn Sie einen Gutschein per E-Mail erhalten haben, k�nnen Sie den Betrag wie folgt verbuchen:. <br/>1. Klicken Sie auf den in der E-Mail angegebenen Link. Falls Sie noch nicht �ber ein pers�nliches Kundenkonto verf�gen, haben Sie die M�glichkeit ein Konto zu er�ffnen. <br/>2. Nachdem Sie ein Produkt in den Warenkorb gelegt haben, k�nnen Sie dort Ihren Gutscheincode eingeben.</td></tr></TBODY></table>
<table cellSpacing=0 cellPadding=0>
<TBODY>
<tr>
<td class=main><strong>Falls es zu Problemen kommen sollte: </strong></td></tr>
<tr>
<td class=main>Falls es wider Erwarten zu Problemen mit einem Gutschein kommen sollte, kontaktieren Sie uns bitte per E-Mail : you@yourdomain.com. Bitte beschreiben Sie m�glichst genau das Problem, wichtige Angaben sind unter anderem: Ihre Kundennummer, der Gutscheincode, Fehlermeldungen des Systems sowie der von Ihnen benutzte Browser. </td></tr></TBODY></table>', '1', '', '0', '6', '1', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('13', '0', '0', '2', 'Kontakt', 'Kontakt', '<p>Ihre Kontaktinformationen</p>', '1', '', '1', '7', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('14', '0', '0', '1', 'Contact', 'Contact', 'Please enter your contact informations.', '1', '', '1', '7', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('15', '0', '0', '2', 'Partner AGB', 'Unsere Affiliate AGB', 'Tragen Sie <strong>hier</strong> Ihre <EM><U>allgemeinen Gesch�ftsbedingungen</U></EM> f�r Ihr Partnerprogramm ein.', '900', '', '1', '900', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('16', '0', '0', '2', 'Affiliate Info', 'Affiliate Informationen', 'Tragen Sie <strong>hier</strong> Ihre <EM><U>Informationen zum Affiliate Programm</U></EM> ein.', '900', '', '1', '901', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('17', '0', '0', '2', 'Affiliate FAQ', 'H�ufig gestellte Fragen', 'Tragen Sie <strong>hier</strong> Ihre <EM><U>FAQ zum Affiliate Programm</U></EM> ein.', '900', '', '1', '902', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('18', '0', '0', '1', 'Partner T&C', 'Our Affiliate Terms and Conditions', 'Put in <strong>here</strong> your <EM><U>terms and conditions</U></EM> for your affiliate program.', '900', '', '1', '900', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('19', '0', '0', '1', 'Affiliate Info', 'Affiliate Information', 'Put in <strong>here</strong> your <EM><U>information about your affiliate program</U></EM>.', '900', '', '1', '901', '0', '0');
insert into olc_content_manager (content_id, categories_id, parent_id, languages_id, content_title, content_heading, content_text, file_flag, content_file, content_status, content_group, content_delete, sort_order) values ('20', '0', '0', '1', 'Affiliate FAQ', 'Frequently Asked Questions', 'Put in <strong>here</strong> some <EM><U>FAQ for your affiliate program</U></EM>.', '900', '', '1', '902', '0', '0');

drop table if exists olc_counter;
create table olc_counter (
  startdate char(8) ,
  counter int(12) 
);


drop table if exists olc_counter_history;
create table olc_counter_history (
  month char(8) ,
  counter int(12) 
);


drop table if exists olc_countries;
create table olc_countries (
  countries_id int(11) not null auto_increment,
  countries_name varchar(64) not null ,
  countries_iso_code_2 char(2) not null ,
  countries_iso_code_3 char(3) not null ,
  address_format_id int(11) default '0' not null ,
  PRIMARY KEY (countries_id),
  KEY IDX_countries_NAME (countries_name)
);

insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('1', 'Afghanistan', 'AF', 'AFG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('2', 'Albania', 'AL', 'ALB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('3', 'Algeria', 'DZ', 'DZA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('4', 'American Samoa', 'AS', 'ASM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('5', 'Andorra', 'AD', 'AND', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('6', 'Angola', 'AO', 'AGO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('7', 'Anguilla', 'AI', 'AIA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('8', 'Antarctica', 'AQ', 'ATA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('9', 'Antigua and Barbuda', 'AG', 'ATG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('10', 'Argentina', 'AR', 'ARG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('11', 'Armenia', 'AM', 'ARM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('12', 'Aruba', 'AW', 'ABW', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('13', 'Australia', 'AU', 'AUS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('14', '�sterreich', 'AT', 'AUT', '5');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('15', 'Azerbaijan', 'AZ', 'AZE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('16', 'Bahamas', 'BS', 'BHS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('17', 'Bahrain', 'BH', 'BHR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('18', 'Bangladesh', 'BD', 'BGD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('19', 'Barbados', 'BB', 'BRB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('20', 'Belarus', 'BY', 'BLR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('21', 'Belgien', 'BE', 'BEL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('22', 'Belize', 'BZ', 'BLZ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('23', 'Benin', 'BJ', 'BEN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('24', 'Bermuda', 'BM', 'BMU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('25', 'Bhutan', 'BT', 'BTN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('26', 'Bolivia', 'BO', 'BOL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('27', 'Bosnia and Herzegowina', 'BA', 'BIH', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('28', 'Botswana', 'BW', 'BWA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('29', 'Bouvet Island', 'BV', 'BVT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('30', 'Brazil', 'BR', 'BRA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('31', 'British Indian Ocean Territory', 'IO', 'IOT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('32', 'Brunei Darussalam', 'BN', 'BRN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('33', 'Bulgaria', 'BG', 'BGR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('34', 'Burkina Faso', 'BF', 'BFA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('35', 'Burundi', 'BI', 'BDI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('36', 'Cambodia', 'KH', 'KHM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('37', 'Cameroon', 'CM', 'CMR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('38', 'Canada', 'CA', 'CAN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('39', 'Cape Verde', 'CV', 'CPV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('40', 'Cayman Islands', 'KY', 'CYM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('41', 'Central African Republic', 'CF', 'CAF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('42', 'Chad', 'TD', 'TCD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('43', 'Chile', 'CL', 'CHL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('44', 'China', 'CN', 'CHN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('45', 'Christmas Island', 'CX', 'CXR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('46', 'Cocos (Keeling) Islands', 'CC', 'CCK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('47', 'Colombia', 'CO', 'COL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('48', 'Comoros', 'KM', 'COM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('49', 'Congo', 'CG', 'COG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('50', 'Cook Islands', 'CK', 'COK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('51', 'Costa Rica', 'CR', 'CRI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('52', 'Cote D\'Ivoire', 'CI', 'CIV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('53', 'Croatia', 'HR', 'HRV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('54', 'Cuba', 'CU', 'CUB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('55', 'Cyprus', 'CY', 'CYP', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('56', 'Czech Republic', 'CZ', 'CZE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('57', 'Denmark', 'DK', 'DNK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('58', 'Djibouti', 'DJ', 'DJI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('59', 'Dominica', 'DM', 'DMA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('60', 'Dominican Republic', 'DO', 'DOM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('61', 'East Timor', 'TP', 'TMP', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('62', 'Ecuador', 'EC', 'ECU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('63', 'Egypt', 'EG', 'EGY', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('64', 'El Salvador', 'SV', 'SLV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('65', 'Equatorial Guinea', 'GQ', 'GNQ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('66', 'Eritrea', 'ER', 'ERI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('67', 'Estonia', 'EE', 'EST', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('68', 'Ethiopia', 'ET', 'ETH', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('69', 'Falkland Islands (Malvinas)', 'FK', 'FLK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('70', 'Faroe Islands', 'FO', 'FRO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('71', 'Fiji', 'FJ', 'FJI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('72', 'Finland', 'FI', 'FIN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('73', 'France', 'FR', 'FRA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('74', 'France, Metropolitan', 'FX', 'FXX', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('75', 'French Guiana', 'GF', 'GUF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('76', 'French Polynesia', 'PF', 'PYF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('77', 'French Southern Territories', 'TF', 'ATF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('78', 'Gabon', 'GA', 'GAB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('79', 'Gambia', 'GM', 'GMB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('80', 'Georgia', 'GE', 'GEO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('81', 'Deutschland', 'DE', 'DEU', '5');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('82', 'Ghana', 'GH', 'GHA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('83', 'Gibraltar', 'GI', 'GIB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('84', 'Greece', 'GR', 'GRC', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('85', 'Greenland', 'GL', 'GRL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('86', 'Grenada', 'GD', 'GRD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('87', 'Guadeloupe', 'GP', 'GLP', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('88', 'Guam', 'GU', 'GUM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('89', 'Guatemala', 'GT', 'GTM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('90', 'Guinea', 'GN', 'GIN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('91', 'Guinea-bissau', 'GW', 'GNB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('92', 'Guyana', 'GY', 'GUY', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('93', 'Haiti', 'HT', 'HTI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('94', 'Heard and Mc Donald Islands', 'HM', 'HMD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('95', 'Honduras', 'HN', 'HND', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('96', 'Hong Kong', 'HK', 'HKG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('97', 'Hungary', 'HU', 'HUN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('98', 'Iceland', 'IS', 'ISL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('99', 'India', 'IN', 'IND', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('100', 'Indonesia', 'ID', 'IDN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('101', 'Iran (Islamic Republic of)', 'IR', 'IRN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('102', 'Iraq', 'IQ', 'IRQ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('103', 'Ireland', 'IE', 'IRL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('104', 'Israel', 'IL', 'ISR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('105', 'Italy', 'IT', 'ITA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('106', 'Jamaica', 'JM', 'JAM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('107', 'Japan', 'JP', 'JPN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('108', 'Jordan', 'JO', 'JOR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('109', 'Kazakhstan', 'KZ', 'KAZ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('110', 'Kenya', 'KE', 'KEN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('111', 'Kiribati', 'KI', 'KIR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('112', 'Korea, Democratic People\'s Republic of', 'KP', 'PRK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('113', 'Korea, Republic of', 'KR', 'KOR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('114', 'Kuwait', 'KW', 'KWT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('115', 'Kyrgyzstan', 'KG', 'KGZ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('116', 'Lao People\'s Democratic Republic', 'LA', 'LAO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('117', 'Latvia', 'LV', 'LVA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('118', 'Lebanon', 'LB', 'LBN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('119', 'Lesotho', 'LS', 'LSO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('120', 'Liberia', 'LR', 'LBR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('121', 'Libyan Arab Jamahiriya', 'LY', 'LBY', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('122', 'Liechtenstein', 'LI', 'LIE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('123', 'Lithuania', 'LT', 'LTU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('124', 'Luxembourg', 'LU', 'LUX', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('125', 'Macau', 'MO', 'MAC', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('126', 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('127', 'Madagascar', 'MG', 'MDG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('128', 'Malawi', 'MW', 'MWI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('129', 'Malaysia', 'MY', 'MYS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('130', 'Maldives', 'MV', 'MDV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('131', 'Mali', 'ML', 'MLI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('132', 'Malta', 'MT', 'MLT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('133', 'Marshall Islands', 'MH', 'MHL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('134', 'Martinique', 'MQ', 'MTQ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('135', 'Mauritania', 'MR', 'MRT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('136', 'Mauritius', 'MU', 'MUS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('137', 'Mayotte', 'YT', 'MYT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('138', 'Mexico', 'MX', 'MEX', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('139', 'Micronesia, Federated States of', 'FM', 'FSM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('140', 'Moldova, Republic of', 'MD', 'MDA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('141', 'Monaco', 'MC', 'MCO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('142', 'Mongolia', 'MN', 'MNG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('143', 'Montserrat', 'MS', 'MSR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('144', 'Morocco', 'MA', 'MAR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('145', 'Mozambique', 'MZ', 'MOZ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('146', 'Myanmar', 'MM', 'MMR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('147', 'Namibia', 'NA', 'NAM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('148', 'Nauru', 'NR', 'NRU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('149', 'Nepal', 'NP', 'NPL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('150', 'Netherlands', 'NL', 'NLD', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('151', 'Netherlands Antilles', 'AN', 'ANT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('152', 'New Caledonia', 'NC', 'NCL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('153', 'New Zealand', 'NZ', 'NZL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('154', 'Nicaragua', 'NI', 'NIC', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('155', 'Niger', 'NE', 'NER', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('156', 'Nigeria', 'NG', 'NGA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('157', 'Niue', 'NU', 'NIU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('158', 'Norfolk Island', 'NF', 'NFK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('159', 'Northern Mariana Islands', 'MP', 'MNP', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('160', 'Norway', 'NO', 'NOR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('161', 'Oman', 'OM', 'OMN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('162', 'Pakistan', 'PK', 'PAK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('163', 'Palau', 'PW', 'PLW', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('164', 'Panama', 'PA', 'PAN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('165', 'Papua New Guinea', 'PG', 'PNG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('166', 'Paraguay', 'PY', 'PRY', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('167', 'Peru', 'PE', 'PER', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('168', 'Philippines', 'PH', 'PHL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('169', 'Pitcairn', 'PN', 'PCN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('170', 'Poland', 'PL', 'POL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('171', 'Portugal', 'PT', 'PRT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('172', 'Puerto Rico', 'PR', 'PRI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('173', 'Qatar', 'QA', 'QAT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('174', 'Reunion', 'RE', 'REU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('175', 'Romania', 'RO', 'ROM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('176', 'Russian Federation', 'RU', 'RUS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('177', 'Rwanda', 'RW', 'RWA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('178', 'Saint Kitts and Nevis', 'KN', 'KNA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('179', 'Saint Lucia', 'LC', 'LCA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('180', 'Saint Vincent and the Grenadines', 'VC', 'VCT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('181', 'Samoa', 'WS', 'WSM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('182', 'San Marino', 'SM', 'SMR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('183', 'Sao Tome and Principe', 'ST', 'STP', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('184', 'Saudi Arabia', 'SA', 'SAU', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('185', 'Senegal', 'SN', 'SEN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('186', 'Seychelles', 'SC', 'SYC', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('187', 'Sierra Leone', 'SL', 'SLE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('188', 'Singapore', 'SG', 'SGP', '4');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('189', 'Slovakia (Slovak Republic)', 'SK', 'SVK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('190', 'Slovenia', 'SI', 'SVN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('191', 'Solomon Islands', 'SB', 'SLB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('192', 'Somalia', 'SO', 'SOM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('193', 'South Africa', 'ZA', 'ZAF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('194', 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('195', 'Spain', 'ES', 'ESP', '3');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('196', 'Sri Lanka', 'LK', 'LKA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('197', 'St. Helena', 'SH', 'SHN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('198', 'St. Pierre and Miquelon', 'PM', 'SPM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('199', 'Sudan', 'SD', 'SDN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('200', 'Suriname', 'SR', 'SUR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('201', 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('202', 'Swaziland', 'SZ', 'SWZ', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('203', 'Sweden', 'SE', 'SWE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('204', 'Schweiz', 'CH', 'CHE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('205', 'Syrian Arab Republic', 'SY', 'SYR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('206', 'Taiwan', 'TW', 'TWN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('207', 'Tajikistan', 'TJ', 'TJK', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('208', 'Tanzania, United Republic of', 'TZ', 'TZA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('209', 'Thailand', 'TH', 'THA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('210', 'Togo', 'TG', 'TGO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('211', 'Tokelau', 'TK', 'TKL', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('212', 'Tonga', 'TO', 'TON', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('213', 'Trinidad and Tobago', 'TT', 'TTO', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('214', 'Tunisia', 'TN', 'TUN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('215', 'Turkey', 'TR', 'TUR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('216', 'Turkmenistan', 'TM', 'TKM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('217', 'Turks and Caicos Islands', 'TC', 'TCA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('218', 'Tuvalu', 'TV', 'TUV', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('219', 'Uganda', 'UG', 'UGA', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('220', 'Ukraine', 'UA', 'UKR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('221', 'United Arab Emirates', 'AE', 'ARE', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('222', 'United Kingdom', 'GB', 'GBR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('223', 'United States', 'US', 'USA', '2');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('224', 'United States Minor Outlying Islands', 'UM', 'UMI', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('225', 'Uruguay', 'UY', 'URY', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('226', 'Uzbekistan', 'UZ', 'UZB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('227', 'Vanuatu', 'VU', 'VUT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('228', 'Vatican City State (Holy See)', 'VA', 'VAT', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('229', 'Venezuela', 'VE', 'VEN', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('230', 'Viet Nam', 'VN', 'VNM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('231', 'Virgin Islands (British)', 'VG', 'VGB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('232', 'Virgin Islands (U.S.)', 'VI', 'VIR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('233', 'Wallis and Futuna Islands', 'WF', 'WLF', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('234', 'Western Sahara', 'EH', 'ESH', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('235', 'Yemen', 'YE', 'YEM', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('236', 'Yugoslavia', 'YU', 'YUG', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('237', 'Zaire', 'ZR', 'ZAR', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('238', 'Zambia', 'ZM', 'ZMB', '1');
insert into olc_countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) values ('239', 'Zimbabwe', 'ZW', 'ZWE', '1');

drop table if exists olc_coupon_email_track;
create table olc_coupon_email_track (
  unique_id int(11) not null auto_increment,
  coupon_id int(11) default '0' not null ,
  customer_id_sent int(11) default '0' not null ,
  sent_firstname varchar(32) ,
  sent_lastname varchar(32) ,
  emailed_to varchar(32) ,
  date_sent datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (unique_id)
);


drop table if exists olc_coupon_gv_customer;
create table olc_coupon_gv_customer (
  customer_id int(5) default '0' not null ,
  amount decimal(8,4) default '0.0000' not null ,
  PRIMARY KEY (customer_id),
  KEY customer_id (customer_id)
);


drop table if exists olc_coupon_gv_queue;
create table olc_coupon_gv_queue (
  unique_id int(5) not null auto_increment,
  customer_id int(5) default '0' not null ,
  order_id int(5) default '0' not null ,
  amount decimal(8,4) default '0.0000' not null ,
  date_created datetime default '0000-00-00 00:00:00' not null ,
  ipaddr varchar(255) not null ,
  release_flag char(1) default 'N' not null ,
  PRIMARY KEY (unique_id),
  KEY uid (unique_id, customer_id, order_id)
);


drop table if exists olc_coupon_redeem_track;
create table olc_coupon_redeem_track (
  unique_id int(11) not null auto_increment,
  coupon_id int(11) default '0' not null ,
  customer_id int(11) default '0' not null ,
  redeem_date datetime default '0000-00-00 00:00:00' not null ,
  redeem_ip varchar(32) not null ,
  order_id int(11) default '0' not null ,
  PRIMARY KEY (unique_id)
);


drop table if exists olc_coupons;
create table olc_coupons (
  coupon_id int(11) not null auto_increment,
  coupon_type char(1) default 'F' not null ,
  coupon_code varchar(32) not null ,
  coupon_amount decimal(8,4) default '0.0000' not null ,
  coupon_minimum_order decimal(8,4) default '0.0000' not null ,
  coupon_start_date datetime default '0000-00-00 00:00:00' not null ,
  coupon_expire_date datetime default '0000-00-00 00:00:00' not null ,
  uses_per_coupon int(5) default '1' not null ,
  uses_per_user int(5) default '0' not null ,
  restrict_to_products varchar(255) ,
  restrict_to_categories varchar(255) ,
  restrict_to_customers text ,
  coupon_active char(1) default 'Y' not null ,
  date_created datetime default '0000-00-00 00:00:00' not null ,
  date_modified datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (coupon_id)
);


drop table if exists olc_coupons_description;
create table olc_coupons_description (
  coupon_id int(11) default '0' not null ,
  language_id int(11) default '0' not null ,
  coupon_name varchar(32) not null ,
  coupon_description text ,
  KEY coupon_id (coupon_id)
);


drop table if exists olc_currencies;
create table olc_currencies (
  currencies_id int(11) not null auto_increment,
  title varchar(32) not null ,
  code char(3) not null ,
  symbol_left varchar(12) ,
  symbol_right varchar(12) ,
  decimal_point char(1) ,
  thousands_point char(1) ,
  decimal_places char(1) ,
  value float(13,8) ,
  last_updated datetime ,
  PRIMARY KEY (currencies_id)
);

insert into olc_currencies (currencies_id, title, code, symbol_left, symbol_right, decimal_point, thousands_point, decimal_places, value, last_updated) values ('1', 'Euro', 'EUR', '', 'EUR', ',', '.', '2', '1.00000000', '2007-07-26 17:38:47');

drop table if exists olc_customers;
create table olc_customers (
  customers_id int(11) not null auto_increment,
  customers_cid varchar(32) ,
  customers_warning varchar(32) ,
  customers_status int(5) default '1' not null ,
  customers_gender char(1) not null ,
  customers_firstname varchar(32) not null ,
  customers_lastname varchar(32) not null ,
  customers_dob datetime default '0000-00-00 00:00:00' not null ,
  customers_email_address varchar(96) not null ,
  customers_email_type tinyint(1) ,
  customers_default_address_id int(11) default '0' not null ,
  customers_telephone varchar(32) not null ,
  customers_fax varchar(32) ,
  customers_password varchar(40) not null ,
  customers_newsletter char(1) ,
  customers_newsletter_mode char(1) default '0' not null ,
  customers_paypal_payerid varchar(20) ,
  customers_paypal_ec tinyint(1) unsigned default '0' not null ,
  customers_ebay_name varchar(255) not null ,
  member_flag char(1) default '0' not null ,
  delete_user char(1) default '1' not null ,
  account_type int(1) default '0' not null ,
  PRIMARY KEY (customers_id)
);

insert into olc_customers (customers_id, customers_cid, customers_warning, customers_status, customers_gender, customers_firstname, customers_lastname, customers_dob, customers_email_address, customers_email_type, customers_default_address_id, customers_telephone, customers_fax, customers_password, customers_newsletter, customers_newsletter_mode, customers_paypal_payerid, customers_paypal_ec, customers_ebay_name, member_flag, delete_user, account_type) values ('1', NULL, NULL, '0', 'm', 'Stefan', 'Michl', '1962-07-19 00:00:00', 'smichl@paar.de', '1', '1', '08251/53250', '08251/53250', '806055bd6317f19a5ff783e0ec40f989', NULL, '0', NULL, '0', '', '0', '0', '0');

drop table if exists olc_customers_basket;
create table olc_customers_basket (
  customers_basket_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  products_id tinytext not null ,
  customers_basket_quantity int(2) default '0' not null ,
  final_price decimal(15,4) default '0.0000' not null ,
  customers_basket_date_added varchar(8) ,
  auction tinyint(4) default '0' not null ,
  auctionid bigint(20) ,
  PRIMARY KEY (customers_basket_id)
);


drop table if exists olc_customers_basket_attributes;
create table olc_customers_basket_attributes (
  customers_basket_attributes_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  products_id tinytext not null ,
  products_options_id int(11) default '0' not null ,
  products_options_value_id int(11) default '0' not null ,
  auctionid bigint(20) ,
  PRIMARY KEY (customers_basket_attributes_id)
);


drop table if exists olc_customers_basket_attributes_save;
create table olc_customers_basket_attributes_save (
  customers_basket_attributes_id int(11) not null auto_increment,
  customers_basket_id int(11) default '0' not null ,
  customers_id int(11) default '0' not null ,
  products_id tinytext not null ,
  products_options_id int(11) default '0' not null ,
  products_options_value_id int(11) default '0' not null ,
  auctionid bigint(20) default '0' ,
  PRIMARY KEY (customers_basket_attributes_id),
  KEY customers_id (customers_id),
  KEY customers_basket_id (customers_basket_id)
);


drop table if exists olc_customers_basket_save;
create table olc_customers_basket_save (
  customers_basket_save_id int(11) not null auto_increment,
  customers_basket_id int(11) default '0' not null ,
  customers_id int(11) default '0' not null ,
  products_id tinytext not null ,
  customers_basket_quantity int(2) default '0' not null ,
  final_price decimal(15,4) default '0.0000' not null ,
  customers_basket_date_added varchar(8) ,
  auction tinyint(4) default '0' not null ,
  auctionid bigint(20) ,
  PRIMARY KEY (customers_basket_save_id),
  KEY customers_id (customers_id),
  KEY customers_basket_id (customers_basket_id)
);


drop table if exists olc_customers_basket_save_baskets;
create table olc_customers_basket_save_baskets (
  customers_basket_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  basket_name varchar(255) ,
  basket_date_added varchar(8) ,
  basket_last_used varchar(8) ,
  PRIMARY KEY (customers_basket_id),
  KEY customers_id (customers_id),
  KEY customers_basket_id (customers_basket_id),
  KEY basket_last_used (basket_last_used)
);


drop table if exists olc_customers_info;
create table olc_customers_info (
  customers_info_id int(11) default '0' not null ,
  customers_info_date_of_last_logon datetime ,
  customers_info_number_of_logons int(5) ,
  customers_info_date_account_created datetime ,
  customers_info_date_account_last_modified datetime ,
  global_product_notifications int(1) default '0' ,
  PRIMARY KEY (customers_info_id)
);

insert into olc_customers_info (customers_info_id, customers_info_date_of_last_logon, customers_info_number_of_logons, customers_info_date_account_created, customers_info_date_account_last_modified, global_product_notifications) values ('1', '2007-08-23 23:12:48', '19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');

drop table if exists olc_customers_ip;
create table olc_customers_ip (
  customers_ip_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  customers_ip varchar(255) not null ,
  customers_ip_date datetime default '0000-00-00 00:00:00' not null ,
  customers_host varchar(255) not null ,
  customers_advertiser varchar(30) ,
  customers_referer_url varchar(255) ,
  PRIMARY KEY (customers_ip_id),
  KEY customers_id (customers_id)
);


drop table if exists olc_customers_memo;
create table olc_customers_memo (
  memo_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  memo_date date default '0000-00-00' not null ,
  memo_title text not null ,
  memo_text text not null ,
  poster_id int(11) default '0' not null ,
  PRIMARY KEY (memo_id)
);


drop table if exists olc_customers_status;
create table olc_customers_status (
  customers_status_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  customers_status_name varchar(32) not null ,
  customers_status_public int(1) default '1' not null ,
  customers_status_image varchar(64) ,
  customers_status_discount decimal(4,2) default '0.00' ,
  customers_status_ot_discount_flag char(1) default '0' not null ,
  customers_status_ot_discount decimal(4,2) default '0.00' ,
  customers_status_graduated_prices char(1) default '0' not null ,
  customers_status_show_price int(1) default '1' not null ,
  customers_status_show_price_tax int(1) default '1' not null ,
  customers_status_add_tax_ot int(1) default '0' not null ,
  customers_status_payment_unallowed varchar(255) not null ,
  customers_status_shipping_unallowed varchar(255) not null ,
  customers_status_discount_attributes int(1) default '0' not null ,
  customers_fsk18 int(1) default '1' not null ,
  customers_fsk18_display int(1) default '1' not null ,
  PRIMARY KEY (customers_status_id, language_id),
  KEY idx_orders_status_name (customers_status_name)
);

insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('0', '1', 'Admin', '1', 'admin_status.gif', '0.00', '1', '0.00', '1', '1', '1', '0', '', '', '0', '1', '1');
insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('0', '2', 'Admin', '1', 'admin_status.gif', '0.00', '1', '0.00', '1', '1', '1', '0', '', '', '0', '1', '1');
insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('1', '1', 'Guest', '1', 'guest_status.gif', '0.00', '0', '0.00', '0', '1', '1', '0', '', '', '0', '1', '1');
insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('1', '2', 'Gast', '1', 'guest_status.gif', '0.00', '0', '0.00', '0', '1', '1', '0', '', '', '0', '1', '1');
insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('2', '1', 'New customer', '1', 'customer_status.gif', '0.00', '0', '0.00', '1', '1', '1', '0', '', '', '0', '1', '1');
insert into olc_customers_status (customers_status_id, language_id, customers_status_name, customers_status_public, customers_status_image, customers_status_discount, customers_status_ot_discount_flag, customers_status_ot_discount, customers_status_graduated_prices, customers_status_show_price, customers_status_show_price_tax, customers_status_add_tax_ot, customers_status_payment_unallowed, customers_status_shipping_unallowed, customers_status_discount_attributes, customers_fsk18, customers_fsk18_display) values ('2', '2', 'Neuer Kunde', '1', 'customer_status.gif', '0.00', '0', '0.00', '1', '1', '1', '0', '', '', '0', '1', '1');

drop table if exists olc_customers_status_history;
create table olc_customers_status_history (
  customers_status_history_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  new_value int(5) default '0' not null ,
  old_value int(5) ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  customer_notified int(1) default '0' ,
  PRIMARY KEY (customers_status_history_id)
);


drop table if exists olc_ebay_auctiontype;
create table olc_ebay_auctiontype (
  id int(11) default '0' not null ,
  name varchar(255) not null ,
  description varchar(255) not null ,
  PRIMARY KEY (id)
);

insert into olc_ebay_auctiontype (id, name, description) values ('1', 'Chinese', '1 Artikel, Steigerungsauktion + optional Fixpreis');
insert into olc_ebay_auctiontype (id, name, description) values ('2', 'Dutch', 'Mehrere Artikel, Steigerungsauktion + optional Fixpreis');
insert into olc_ebay_auctiontype (id, name, description) values ('6', 'StoresFixedPrice', 'eBay-Shop');
insert into olc_ebay_auctiontype (id, name, description) values ('9', 'FixedPriceItem', '1 oder mehrere Artikel, Fixpreis');
insert into olc_ebay_auctiontype (id, name, description) values ('12', 'Express', 'eBay Express');

drop table if exists olc_ebay_categories;
create table olc_ebay_categories (
  myid bigint(20) not null auto_increment,
  name varchar(100) not null ,
  id int(11) default '0' not null ,
  parentid int(11) default '0' not null ,
  leaf set('0','1') default '0' ,
  virtual set('0','1') not null ,
  expired set('0','1') not null ,
  PRIMARY KEY (myid)
);


drop table if exists olc_ebay_config;
create table olc_ebay_config (
  id int(11) not null auto_increment,
  category_version varchar(5) ,
  category_update_time timestamp ,
  event_update_time timestamp ,
  transaction_update_time timestamp ,
  PRIMARY KEY (id)
);

insert into olc_ebay_config (id, category_version, category_update_time, event_update_time, transaction_update_time) values ('1', NULL, NULL, NULL, NULL);

drop table if exists olc_ebay_products;
create table olc_ebay_products (
  products_id int(11) default '0' not null ,
  auction_description varchar(255) not null ,
  PRIMARY KEY (products_id)
);


drop table if exists olc_geo_zones;
create table olc_geo_zones (
  geo_zone_id int(11) not null auto_increment,
  geo_zone_name varchar(32) not null ,
  geo_zone_description varchar(255) not null ,
  last_modified datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (geo_zone_id)
);

insert into olc_geo_zones (geo_zone_id, geo_zone_name, geo_zone_description, last_modified, date_added) values ('6', 'Steuerzone EU-Ausland', '', NULL, '2007-07-26 17:41:11');
insert into olc_geo_zones (geo_zone_id, geo_zone_name, geo_zone_description, last_modified, date_added) values ('5', 'Steuerzone EU', 'Steuerzone f�r die EU', NULL, '2007-07-26 17:41:11');
insert into olc_geo_zones (geo_zone_id, geo_zone_name, geo_zone_description, last_modified, date_added) values ('7', 'Steuerzone B2B', '', NULL, '2007-07-26 17:41:11');

drop table if exists olc_languages;
create table olc_languages (
  languages_id int(11) not null auto_increment,
  name varchar(32) not null ,
  code char(2) not null ,
  image varchar(64) ,
  directory varchar(32) ,
  sort_order int(3) ,
  language_charset text not null ,
  PRIMARY KEY (languages_id),
  KEY IDX_LANGUAGES_NAME (name)
);

insert into olc_languages (languages_id, name, code, image, directory, sort_order, language_charset) values ('1', 'Deutsch', 'de', 'icon.gif', 'german', '1', 'iso-8859-15');

drop table if exists olc_manufacturers;
create table olc_manufacturers (
  manufacturers_id int(11) not null auto_increment,
  manufacturers_name varchar(32) not null ,
  manufacturers_image varchar(64) ,
  date_added datetime ,
  last_modified datetime ,
  PRIMARY KEY (manufacturers_id),
  KEY IDX_MANUFACTURERS_NAME (manufacturers_name)
);


drop table if exists olc_manufacturers_info;
create table olc_manufacturers_info (
  manufacturers_id int(11) default '0' not null ,
  languages_id int(11) default '0' not null ,
  manufacturers_meta_title varchar(100) not null ,
  manufacturers_meta_description varchar(255) not null ,
  manufacturers_meta_keywords varchar(255) not null ,
  manufacturers_url varchar(255) not null ,
  url_clicked int(5) default '0' not null ,
  date_last_click datetime ,
  PRIMARY KEY (manufacturers_id, languages_id)
);


drop table if exists olc_media_content;
create table olc_media_content (
  file_id int(11) not null auto_increment,
  old_filename text not null ,
  new_filename text not null ,
  file_comment text not null ,
  PRIMARY KEY (file_id)
);


drop table if exists olc_module_newsletter;
create table olc_module_newsletter (
  newsletter_id int(11) not null auto_increment,
  title text not null ,
  bc text not null ,
  cc text not null ,
  date datetime ,
  status int(1) default '0' not null ,
  body text not null ,
  PRIMARY KEY (newsletter_id)
);


drop table if exists olc_newsletter_recipients;
create table olc_newsletter_recipients (
  mail_id int(11) not null auto_increment,
  customers_email_address varchar(96) not null ,
  customers_email_type tinyint(1) ,
  customers_id int(11) default '0' not null ,
  customers_status int(5) default '0' not null ,
  customers_firstname varchar(32) not null ,
  customers_lastname varchar(32) not null ,
  mail_status int(1) default '0' not null ,
  mail_key varchar(32) not null ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (mail_id)
);


drop table if exists olc_newsletters;
create table olc_newsletters (
  newsletters_id int(11) not null auto_increment,
  title varchar(255) not null ,
  content text not null ,
  module varchar(255) not null ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  date_sent datetime ,
  status int(1) ,
  locked int(1) default '0' ,
  PRIMARY KEY (newsletters_id)
);


drop table if exists olc_newsletters_history;
create table olc_newsletters_history (
  news_hist_id int(11) default '0' not null ,
  news_hist_cs int(11) default '0' not null ,
  news_hist_cs_date_sent date ,
  PRIMARY KEY (news_hist_id)
);


drop table if exists olc_orders;
create table olc_orders (
  orders_id int(11) not null auto_increment,
  customers_id int(11) default '0' not null ,
  customers_cid varchar(32) ,
  customers_status int(11) ,
  customers_status_name varchar(32) not null ,
  customers_status_image varchar(64) ,
  customers_status_discount decimal(4,2) ,
  customers_name varchar(64) not null ,
  customers_company varchar(32) ,
  customers_street_address varchar(64) not null ,
  customers_suburb varchar(32) ,
  customers_city varchar(32) not null ,
  customers_postcode varchar(10) not null ,
  customers_state varchar(32) ,
  customers_country varchar(32) not null ,
  customers_telephone varchar(32) not null ,
  customers_email_address varchar(96) not null ,
  customers_email_type tinyint(1) ,
  customers_address_format_id int(5) default '0' not null ,
  customers_order_reference varchar(32) ,
  delivery_name varchar(64) not null ,
  delivery_firstname varchar(32) not null ,
  delivery_lastname varchar(32) not null ,
  delivery_company varchar(32) ,
  delivery_street_address varchar(64) not null ,
  delivery_suburb varchar(32) ,
  delivery_city varchar(32) not null ,
  delivery_postcode varchar(10) not null ,
  delivery_state varchar(32) ,
  delivery_country varchar(32) not null ,
  delivery_country_iso_code_2 char(2) not null ,
  delivery_address_format_id int(5) default '0' not null ,
  delivery_packingslip_number varchar(20) not null ,
  delivery_packingslip_date date default '0000-00-00' not null ,
  billing_name varchar(64) not null ,
  billing_firstname varchar(32) not null ,
  billing_lastname varchar(32) not null ,
  billing_company varchar(32) ,
  billing_street_address varchar(64) not null ,
  billing_suburb varchar(32) ,
  billing_city varchar(32) not null ,
  billing_postcode varchar(10) not null ,
  billing_state varchar(32) ,
  billing_country varchar(32) not null ,
  billing_country_iso_code_2 char(2) not null ,
  billing_address_format_id int(5) default '0' not null ,
  billing_invoice_number varchar(20) not null ,
  billing_invoice_date date default '0000-00-00' not null ,
  payment_method varchar(255) not null ,
  cc_type varchar(20) ,
  cc_owner varchar(64) ,
  cc_number varchar(64) ,
  cc_expires varchar(4) ,
  cc_start varchar(4) ,
  cc_issue char(3) ,
  cc_cvv varchar(4) ,
  comments varchar(255) ,
  last_modified datetime ,
  date_purchased datetime ,
  orders_status int(5) default '0' not null ,
  orders_date_finished datetime ,
  currency char(3) ,
  currency_value decimal(14,6) ,
  account_type int(1) default '0' not null ,
  payment_class varchar(32) not null ,
  shipping_method varchar(255) not null ,
  shipping_class varchar(32) not null ,
  customers_ip varchar(255) not null ,
  language varchar(32) not null ,
  orders_trackcode varchar(64) ,
  orders_discount int(11) default '0' not null ,
  payment_id int(11) default '0' not null ,
  shipping_tax decimal(7,4) default '19.0000' not null ,
  PRIMARY KEY (orders_id)
);


drop table if exists olc_orders_products;
create table olc_orders_products (
  orders_products_id int(11) not null auto_increment,
  orders_id int(11) default '0' not null ,
  products_id int(11) default '0' not null ,
  products_model varchar(64) ,
  products_name varchar(64) not null ,
  products_price decimal(15,4) default '0.0000' not null ,
  products_discount_made decimal(4,2) ,
  final_price decimal(15,4) default '0.0000' not null ,
  products_tax decimal(7,4) default '0.0000' not null ,
  products_quantity int(2) default '0' not null ,
  allow_tax int(1) default '0' not null ,
  PRIMARY KEY (orders_products_id)
);


drop table if exists olc_orders_products_attributes;
create table olc_orders_products_attributes (
  orders_products_attributes_id int(11) not null auto_increment,
  orders_id int(11) default '0' not null ,
  orders_products_id int(11) default '0' not null ,
  products_options varchar(32) not null ,
  products_options_values varchar(32) not null ,
  options_values_price decimal(15,4) default '0.0000' not null ,
  price_prefix char(1) not null ,
  products_options_id int(11) default '0' not null ,
  products_options_values_id int(11) default '0' not null ,
  PRIMARY KEY (orders_products_attributes_id)
);


drop table if exists olc_orders_products_download;
create table olc_orders_products_download (
  orders_products_download_id int(11) not null auto_increment,
  orders_id int(11) default '0' not null ,
  orders_products_id int(11) default '0' not null ,
  orders_products_filename varchar(255) not null ,
  download_maxdays int(2) default '0' not null ,
  download_count int(2) default '0' not null ,
  PRIMARY KEY (orders_products_download_id)
);


drop table if exists olc_orders_recalculate;
create table olc_orders_recalculate (
  orders_recalculate_id int(11) not null auto_increment,
  orders_id int(11) default '0' not null ,
  n_price decimal(15,4) default '0.0000' not null ,
  b_price decimal(15,4) default '0.0000' not null ,
  tax decimal(15,4) default '0.0000' not null ,
  tax_rate decimal(7,4) default '0.0000' not null ,
  class varchar(32) not null ,
  PRIMARY KEY (orders_recalculate_id)
);


drop table if exists olc_orders_session_info;
create table olc_orders_session_info (
  txn_signature varchar(32) not null ,
  orders_id int(11) default '0' not null ,
  payment varchar(32) not null ,
  payment_title varchar(32) not null ,
  payment_amount decimal(7,2) default '0.00' not null ,
  payment_currency char(3) not null ,
  payment_currency_val float(13,8) ,
  sendto int(11) default '1' not null ,
  billto int(11) default '1' not null ,
  language varchar(32) not null ,
  language_id int(11) default '1' not null ,
  currency char(3) not null ,
  currency_value float(13,8) ,
  firstname varchar(32) not null ,
  lastname varchar(32) not null ,
  content_type varchar(32) not null ,
  affiliate_id int(11) default '0' not null ,
  affiliate_date datetime default '0000-00-00 00:00:00' not null ,
  affiliate_browser varchar(100) not null ,
  affiliate_ipaddress varchar(20) not null ,
  affiliate_clickthroughs_id int(11) default '0' not null ,
  PRIMARY KEY (txn_signature, orders_id),
  KEY idx_orders_session_info_txn_signature (txn_signature)
);


drop table if exists olc_orders_status;
create table olc_orders_status (
  orders_status_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  orders_status_name varchar(32) not null ,
  PRIMARY KEY (orders_status_id, language_id),
  KEY idx_orders_status_name (orders_status_name)
);

insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('1', '1', 'Pending');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('1', '2', 'Offen');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('2', '1', 'Processing');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('2', '2', 'In Bearbeitung');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('3', '1', 'Delivered');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('3', '2', 'Versendet');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('4', '1', 'On Hold');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('4', '2', 'Blockiert');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('5', '1', 'Refunded');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('5', '2', 'Erstattet');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('6', '1', 'Canceled');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('6', '2', 'Ung�ltig');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('7', '1', 'Completed');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('7', '2', 'Abgeschlossen');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('8', '1', 'Failed');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('8', '2', 'Fehlgeschlagen');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('9', '1', 'Denied');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('9', '2', 'Abgelehnt');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('10', '1', 'Reversed');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('10', '2', 'Zur�ckerstattet');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('11', '1', 'Canceled Reversal');
insert into olc_orders_status (orders_status_id, language_id, orders_status_name) values ('11', '2', 'Zur�ckerstattung aufgehoben');

drop table if exists olc_orders_status_history;
create table olc_orders_status_history (
  orders_status_history_id int(11) not null auto_increment,
  orders_id int(11) default '0' not null ,
  orders_status_id int(5) default '0' not null ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  customer_notified int(1) default '0' ,
  comments text ,
  PRIMARY KEY (orders_status_history_id)
);


drop table if exists olc_orders_total;
create table olc_orders_total (
  orders_total_id int(10) unsigned not null auto_increment,
  orders_id int(11) default '0' not null ,
  title varchar(255) not null ,
  text varchar(255) not null ,
  value decimal(15,4) default '0.0000' not null ,
  class varchar(32) not null ,
  sort_order int(11) default '0' not null ,
  PRIMARY KEY (orders_total_id),
  KEY idx_orders_total_orders_id (orders_id)
);


drop table if exists olc_payment_moneybookers;
create table olc_payment_moneybookers (
  mb_TRID varchar(255) not null ,
  mb_ERRNO smallint(3) unsigned default '0' not null ,
  mb_ERRTXT varchar(255) not null ,
  mb_DATE datetime default '0000-00-00 00:00:00' not null ,
  mb_MBTID bigint(18) unsigned default '0' not null ,
  mb_STATUS tinyint(1) default '0' not null ,
  mb_ORDERID int(11) unsigned default '0' not null ,
  PRIMARY KEY (mb_TRID)
);


drop table if exists olc_payment_moneybookers_countries;
create table olc_payment_moneybookers_countries (
  osc_cID int(11) default '0' not null ,
  mb_cID char(3) not null ,
  PRIMARY KEY (osc_cID)
);

insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('2', 'ALB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('3', 'ALG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('4', 'AME');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('5', 'AND');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('6', 'AGL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('7', 'ANG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('9', 'ANT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('10', 'ARG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('11', 'ARM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('12', 'ARU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('13', 'AUS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('14', 'AUT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('15', 'AZE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('16', 'BMS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('17', 'BAH');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('18', 'BAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('19', 'BAR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('20', 'BLR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('21', 'BGM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('22', 'BEL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('23', 'BEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('24', 'BER');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('26', 'BOL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('27', 'BOS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('28', 'BOT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('30', 'BRA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('32', 'BRU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('33', 'BUL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('34', 'BKF');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('35', 'BUR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('36', 'CAM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('37', 'CMR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('38', 'CAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('39', 'CAP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('40', 'CAY');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('41', 'CEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('42', 'CHA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('43', 'CHL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('44', 'CHN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('47', 'COL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('49', 'CON');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('51', 'COS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('52', 'COT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('53', 'CRO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('54', 'CUB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('55', 'CYP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('56', 'CZE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('57', 'DEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('58', 'DJI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('59', 'DOM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('60', 'DRP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('62', 'ECU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('64', 'EL_');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('65', 'EQU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('66', 'ERI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('67', 'EST');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('68', 'ETH');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('70', 'FAR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('71', 'FIJ');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('72', 'FIN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('73', 'FRA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('75', 'FRE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('78', 'GAB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('79', 'GAM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('80', 'GEO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('81', 'GER');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('82', 'GHA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('83', 'GIB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('84', 'GRC');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('85', 'GRL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('87', 'GDL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('88', 'GUM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('89', 'GUA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('90', 'GUI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('91', 'GBS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('92', 'GUY');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('93', 'HAI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('95', 'HON');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('96', 'HKG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('97', 'HUN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('98', 'ICE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('99', 'IND');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('101', 'IRN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('102', 'IRA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('103', 'IRE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('104', 'ISR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('105', 'ITA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('106', 'JAM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('107', 'JAP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('108', 'JOR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('109', 'KAZ');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('110', 'KEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('112', 'SKO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('113', 'KOR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('114', 'KUW');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('115', 'KYR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('116', 'LAO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('117', 'LAT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('141', 'MCO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('119', 'LES');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('120', 'LIB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('121', 'LBY');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('122', 'LIE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('123', 'LIT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('124', 'LUX');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('125', 'MAC');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('126', 'F.Y');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('127', 'MAD');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('128', 'MLW');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('129', 'MLS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('130', 'MAL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('131', 'MLI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('132', 'MLT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('134', 'MAR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('135', 'MRT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('136', 'MAU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('138', 'MEX');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('140', 'MOL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('142', 'MON');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('143', 'MTT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('144', 'MOR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('145', 'MOZ');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('76', 'PYF');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('147', 'NAM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('149', 'NEP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('150', 'NED');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('151', 'NET');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('152', 'CDN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('153', 'NEW');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('154', 'NIC');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('155', 'NIG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('69', 'FLK');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('160', 'NWY');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('161', 'OMA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('162', 'PAK');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('164', 'PAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('165', 'PAP');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('166', 'PAR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('167', 'PER');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('168', 'PHI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('170', 'POL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('171', 'POR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('172', 'PUE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('173', 'QAT');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('175', 'ROM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('176', 'RUS');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('177', 'RWA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('178', 'SKN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('179', 'SLU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('180', 'ST.');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('181', 'WES');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('182', 'SAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('183', 'SAO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('184', 'SAU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('185', 'SEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('186', 'SEY');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('187', 'SIE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('188', 'SIN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('189', 'SLO');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('190', 'SLV');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('191', 'SOL');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('192', 'SOM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('193', 'SOU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('195', 'SPA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('196', 'SRI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('199', 'SUD');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('200', 'SUR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('202', 'SWA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('203', 'SWE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('204', 'SWI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('205', 'SYR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('206', 'TWN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('207', 'TAJ');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('208', 'TAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('209', 'THA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('210', 'TOG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('212', 'TON');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('213', 'TRI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('214', 'TUN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('215', 'TUR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('216', 'TKM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('217', 'TCI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('219', 'UGA');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('231', 'BRI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('221', 'UAE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('222', 'GBR');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('223', 'UNI');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('225', 'URU');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('226', 'UZB');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('227', 'VAN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('229', 'VEN');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('230', 'VIE');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('232', 'US_');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('235', 'YEM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('236', 'YUG');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('238', 'ZAM');
insert into olc_payment_moneybookers_countries (osc_cID, mb_cID) values ('239', 'ZIM');

drop table if exists olc_payment_moneybookers_currencies;
create table olc_payment_moneybookers_currencies (
  mb_currID char(3) not null ,
  mb_currName varchar(255) not null ,
  PRIMARY KEY (mb_currID)
);

insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('AUD', 'Australian Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('BGN', 'Bulgarian Lev');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('CAD', 'Canadian Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('CHF', 'Swiss Franc');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('CZK', 'Czech Koruna');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('DKK', 'Danish Krone');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('EEK', 'Estonian Koruna');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('EUR', 'Euro');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('GBP', 'Pound Sterling');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('HKD', 'Hong Kong Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('HUF', 'Forint');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('ILS', 'Shekel');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('ISK', 'Iceland Krona');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('JPY', 'Yen');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('KRW', 'South-Korean Won');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('LVL', 'Latvian Lat');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('MYR', 'Malaysian Ringgit');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('NOK', 'Norwegian Krone');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('NZD', 'New Zealand Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('PLN', 'Zloty');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('SEK', 'Swedish Krona');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('SGD', 'Singapore Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('SKK', 'Slovak Koruna');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('THB', 'Baht');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('TWD', 'New Taiwan Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('USD', 'US Dollar');
insert into olc_payment_moneybookers_currencies (mb_currID, mb_currName) values ('ZAR', 'South-African Rand');

drop table if exists olc_paypal;
create table olc_paypal (
  paypal_id int(11) unsigned not null auto_increment,
  txn_type varchar(10) not null ,
  reason_code varchar(15) ,
  payment_type varchar(7) not null ,
  payment_status varchar(17) not null ,
  pending_reason varchar(14) ,
  invoice varchar(64) ,
  mc_currency char(3) not null ,
  first_name varchar(32) not null ,
  last_name varchar(32) not null ,
  payer_business_name varchar(64) ,
  address_name varchar(32) ,
  address_street varchar(64) ,
  address_city varchar(32) ,
  address_state varchar(32) ,
  address_zip varchar(10) ,
  address_country varchar(64) ,
  address_status varchar(11) ,
  payer_email varchar(96) not null ,
  payer_id varchar(32) not null ,
  payer_status varchar(10) not null ,
  payment_date datetime ,
  payment_time_zone varchar(4) not null ,
  business varchar(96) not null ,
  receiver_email varchar(96) not null ,
  receiver_id varchar(32) not null ,
  txn_id varchar(17) not null ,
  parent_txn_id varchar(17) ,
  num_cart_items tinyint(4) unsigned default '1' not null ,
  mc_gross decimal(7,2) default '0.00' not null ,
  mc_fee decimal(7,2) default '0.00' not null ,
  payment_gross decimal(7,2) ,
  payment_fee decimal(7,2) ,
  settle_amount decimal(7,2) ,
  settle_currency char(3) ,
  exchange_rate decimal(4,2) ,
  for_auction varchar(5) default 'false' not null ,
  auction_buyer_id varchar(64) not null ,
  auction_closing_date datetime default '0000-00-00 00:00:00' not null ,
  auction_multi_item tinyint(4) default '0' not null ,
  quantity int(11) default '0' not null ,
  tax decimal(7,2) ,
  notify_version decimal(2,1) default '0.0' not null ,
  verify_sign varchar(128) not null ,
  last_modified datetime ,
  date_added datetime ,
  memo text ,
  PRIMARY KEY (paypal_id, txn_id),
  KEY idx_paypal_paypal_id (paypal_id)
);


drop table if exists olc_paypal_auction;
create table olc_paypal_auction (
  paypal_id int(11) default '0' not null ,
  item_number varchar(96) not null ,
  auction_buyer_id varchar(96) not null ,
  auction_multi_item tinyint(4) default '0' not null ,
  auction_closing_date datetime default '0000-00-00 00:00:00' not null ,
  is_old int(1) default '0' not null ,
  PRIMARY KEY (paypal_id, item_number)
);


drop table if exists olc_paypal_payment_status_history;
create table olc_paypal_payment_status_history (
  payment_status_history_id int(11) not null auto_increment,
  paypal_id int(11) default '0' not null ,
  payment_status varchar(17) not null ,
  pending_reason varchar(14) ,
  reason_code varchar(15) ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (payment_status_history_id)
);


drop table if exists olc_personal_offers_by_customers_status_0;
create table olc_personal_offers_by_customers_status_0 (
  price_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  quantity int(11) ,
  personal_offer decimal(15,4) ,
  PRIMARY KEY (price_id)
);


drop table if exists olc_personal_offers_by_customers_status_1;
create table olc_personal_offers_by_customers_status_1 (
  price_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  quantity int(11) ,
  personal_offer decimal(15,4) ,
  PRIMARY KEY (price_id)
);


drop table if exists olc_personal_offers_by_customers_status_2;
create table olc_personal_offers_by_customers_status_2 (
  price_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  quantity int(11) ,
  personal_offer decimal(15,4) ,
  PRIMARY KEY (price_id)
);


drop table if exists olc_personal_offers_by_customers_status_3;
create table olc_personal_offers_by_customers_status_3 (
  price_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  quantity int(11) ,
  personal_offer decimal(15,4) ,
  PRIMARY KEY (price_id)
);


drop table if exists olc_plz;
create table olc_plz (
  plz varchar(5) not null ,
  ort varchar(50) not null ,
  land char(3) not null ,
  bundesland char(2) not null ,
  vorwahl varchar(6) not null ,
  KEY plz (plz),
  KEY land (land)
);


drop table if exists olc_products;
create table olc_products (
  products_id int(11) not null auto_increment,
  products_ean varchar(128) ,
  products_quantity int(4) default '0' not null ,
  products_shippingtime int(4) default '0' not null ,
  products_model varchar(64) ,
  group_ids text ,
  products_sort int(4) ,
  products_image varchar(64) ,
  products_image_medium varchar(64) not null ,
  products_image_large varchar(64) not null ,
  products_price decimal(15,4) default '0.0000' not null ,
  products_discount_allowed decimal(3,2) default '0.00' not null ,
  products_date_added datetime default '0000-00-00 00:00:00' not null ,
  products_last_modified datetime ,
  products_date_available datetime ,
  products_weight decimal(5,2) default '0.00' not null ,
  products_status tinyint(1) default '0' not null ,
  products_promotion_status tinyint(1) default '0' not null ,
  products_promotion_show_title tinyint(1) default '0' not null ,
  products_promotion_show_desc tinyint(1) default '0' not null ,
  products_tax_class_id int(11) default '0' not null ,
  product_template varchar(64) ,
  options_template varchar(64) ,
  manufacturers_id int(11) ,
  products_ordered int(11) default '0' not null ,
  products_fsk18 int(1) default '0' not null ,
  products_uvp decimal(15,2) default '0.00' not null ,
  products_vpe int(1) default '0' not null ,
  products_vpe_status int(11) default '0' not null ,
  products_vpe_value decimal(15,2) default '0.00' not null ,
  products_baseprice_show int(1) ,
  products_baseprice_value decimal(15,2) ,
  products_min_order_quantity int(11) ,
  products_min_order_vpe int(11) ,
  PRIMARY KEY (products_id),
  KEY idx_products_date_added (products_date_added),
  KEY products_model (products_model)
);


drop table if exists olc_products_attributes;
create table olc_products_attributes (
  products_attributes_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  options_id int(11) default '0' not null ,
  options_values_id int(11) default '0' not null ,
  options_values_price decimal(15,4) default '0.0000' not null ,
  price_prefix char(1) not null ,
  attributes_model varchar(64) ,
  attributes_stock int(4) ,
  options_values_weight decimal(15,4) default '0.0000' not null ,
  weight_prefix char(1) not null ,
  sortorder int(11) ,
  PRIMARY KEY (products_attributes_id)
);


drop table if exists olc_products_attributes_download;
create table olc_products_attributes_download (
  products_attributes_id int(11) default '0' not null ,
  products_attributes_filename varchar(255) not null ,
  products_attributes_maxdays int(2) default '0' ,
  products_attributes_maxcount int(2) default '0' ,
  PRIMARY KEY (products_attributes_id)
);


drop table if exists olc_products_content;
create table olc_products_content (
  content_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  content_name varchar(32) not null ,
  content_file varchar(64) not null ,
  content_link text not null ,
  languages_id int(11) default '0' not null ,
  content_read int(11) default '0' not null ,
  file_comment text not null ,
  PRIMARY KEY (content_id)
);


drop table if exists olc_products_description;
create table olc_products_description (
  products_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  products_name varchar(64) not null ,
  products_description text ,
  products_short_description text ,
  products_meta_title text not null ,
  products_meta_description text not null ,
  products_meta_keywords text not null ,
  products_url varchar(255) ,
  products_viewed int(11) default '0' ,
  products_promotion_desc text ,
  products_promotion_title varchar(255) ,
  products_promotion_image varchar(255) ,
  PRIMARY KEY (products_id, language_id),
  KEY products_name (products_name)
);


drop table if exists olc_products_graduated_prices;
create table olc_products_graduated_prices (
  products_id int(11) default '0' not null ,
  quantity int(11) default '0' not null ,
  unitprice decimal(15,4) default '0.0000' not null ,
  KEY products_id (products_id)
);


drop table if exists olc_products_images;
create table olc_products_images (
  image_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  image_nr smallint(6) default '0' not null ,
  image_name varchar(254) not null ,
  PRIMARY KEY (image_id)
);


drop table if exists olc_products_notifications;
create table olc_products_notifications (
  products_id int(11) default '0' not null ,
  customers_id int(11) default '0' not null ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (products_id, customers_id)
);


drop table if exists olc_products_options;
create table olc_products_options (
  products_options_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  products_options_name varchar(32) not null ,
  PRIMARY KEY (products_options_id, language_id)
);


drop table if exists olc_products_options_values;
create table olc_products_options_values (
  products_options_values_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  products_options_values_name varchar(64) not null ,
  PRIMARY KEY (products_options_values_id, language_id)
);


drop table if exists olc_products_options_values_to_products_options;
create table olc_products_options_values_to_products_options (
  products_options_values_to_products_options_id int(11) not null auto_increment,
  products_options_id int(11) default '0' not null ,
  products_options_values_id int(11) default '0' not null ,
  PRIMARY KEY (products_options_values_to_products_options_id)
);


drop table if exists olc_products_to_categories;
create table olc_products_to_categories (
  products_id int(11) default '0' not null ,
  categories_id int(11) default '0' not null ,
  PRIMARY KEY (products_id, categories_id)
);


drop table if exists olc_products_vpe;
create table olc_products_vpe (
  products_vpe_id int(1) default '0' not null ,
  language_id int(11) default '0' not null ,
  products_vpe_name varchar(32) not null 
);

insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('1', '1', 'Piece');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('2', '1', 'ml,Content');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('3', '1', 'gr,Weight');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('4', '1', 'gr,Content');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('1', '2', 'St�ck');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('2', '2', 'ml,Inhalt');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('3', '2', 'gr,Gewicht');
insert into olc_products_vpe (products_vpe_id, language_id, products_vpe_name) values ('4', '2', 'gr,Inhalt');

drop table if exists olc_products_xsell;
create table olc_products_xsell (
  ID int(10) not null auto_increment,
  products_id int(10) unsigned default '1' not null ,
  xsell_id int(10) unsigned default '1' not null ,
  sort_order int(10) unsigned default '1' not null ,
  PRIMARY KEY (ID)
);


drop table if exists olc_reviews;
create table olc_reviews (
  reviews_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  customers_id int(11) ,
  customers_name varchar(64) not null ,
  reviews_rating int(1) ,
  date_added datetime ,
  last_modified datetime ,
  reviews_read int(5) default '0' not null ,
  PRIMARY KEY (reviews_id)
);


drop table if exists olc_reviews_description;
create table olc_reviews_description (
  reviews_id int(11) default '0' not null ,
  languages_id int(11) default '0' not null ,
  reviews_text text not null ,
  PRIMARY KEY (reviews_id, languages_id)
);


drop table if exists olc_sessions;
create table olc_sessions (
  sesskey varchar(32) not null ,
  expiry int(11) unsigned default '0' not null ,
  value text not null ,
  PRIMARY KEY (sesskey),
  KEY expiry (expiry)
);

insert into olc_sessions (sesskey, expiry, value) values ('d7a40e5d56eeb17b955541fa02706765', '1187911263', 'DIR_FS_MULTI_SHOP|N;navigation|O:17:\"navigationhistory\":2:{s:4:\"path\";a:0:{}s:8:\"snapshot\";a:4:{s:4:\"page\";s:9:\"index.php\";s:4:\"mode\";s:6:\"NONSSL\";s:3:\"get\";a:0:{}s:4:\"post\";a:2:{s:4:\"ajax\";s:4:\"true\";s:18:\"cart_details_state\";s:4:\"none\";}}}spider_visit|b:0;allow_keys|N;is_admin|b:1;user_info|a:4:{s:7:\"user_ip\";s:11:\"192.168.1.3\";s:9:\"user_host\";s:16:\"pc-00003.paar.de\";s:10:\"advertiser\";N;s:11:\"referer_url\";N;}language_id|s:1:\"1\";language_code|s:2:\"de\";language|s:6:\"german\";language_charset|s:11:\"iso-8859-15\";language_name|s:7:\"Deutsch\";boxes.php|s:39:\"templates/common/source/boxes/boxes.php\";box_relations|a:24:{s:17:\"box_ADD_A_QUICKIE\";s:8:\"box_r_05\";s:9:\"box_ADMIN\";s:8:\"box_r_03\";s:13:\"box_AFFILIATE\";s:8:\"box_l_13\";s:15:\"box_BESTSELLERS\";s:8:\"box_r_07\";s:8:\"box_CART\";s:8:\"box_r_01\";s:14:\"box_CATEGORIES\";s:8:\"box_l_01\";s:11:\"box_CONTENT\";s:8:\"box_l_04\";s:14:\"box_CURRENCIES\";s:8:\"box_r_10\";s:11:\"box_INFOBOX\";s:8:\"box_r_08\";s:15:\"box_INFORMATION\";s:8:\"box_l_06\";s:13:\"box_LANGUAGES\";s:8:\"box_r_11\";s:15:\"box_LAST_VIEWED\";s:8:\"box_l_12\";s:9:\"box_LOGIN\";s:8:\"box_r_02\";s:22:\"box_MANUFACTURERS_INFO\";s:8:\"box_l_03\";s:17:\"box_MANUFACTURERS\";s:8:\"box_l_05\";s:14:\"box_NEWSLETTER\";s:8:\"box_l_09\";s:17:\"box_NOTIFICATIONS\";s:8:\"box_l_08\";s:17:\"box_ORDER_HISTORY\";s:8:\"box_l_11\";s:11:\"box_REVIEWS\";s:8:\"box_l_10\";s:10:\"box_SEARCH\";s:8:\"box_r_06\";s:12:\"box_SPECIALS\";s:8:\"box_l_02\";s:15:\"box_TELL_FRIEND\";s:8:\"box_l_07\";s:12:\"box_WHATSNEW\";s:8:\"box_r_04\";s:14:\"box_NAVIGATION\";s:14:\"box_NAVIGATION\";}box_constants|a:27:{s:18:\"SHOW_ADD_A_QUICKIE\";b:1;s:10:\"SHOW_ADMIN\";b:1;s:14:\"SHOW_AFFILIATE\";b:1;s:16:\"SHOW_BESTSELLERS\";b:1;s:9:\"SHOW_CART\";b:1;s:15:\"SHOW_CATEGORIES\";b:1;s:15:\"SHOW_CONTACT_US\";b:0;s:12:\"SHOW_CONTENT\";b:1;s:15:\"SHOW_CURRENCIES\";b:1;s:12:\"SHOW_INFOBOX\";b:1;s:16:\"SHOW_INFORMATION\";b:1;s:14:\"SHOW_LANGUAGES\";b:1;s:16:\"SHOW_LAST_VIEWED\";b:1;s:13:\"SHOW_LIVEHELP\";b:0;s:10:\"SHOW_LOGIN\";b:1;s:23:\"SHOW_MANUFACTURERS_INFO\";b:1;s:18:\"SHOW_MANUFACTURERS\";b:1;s:15:\"SHOW_NEWSLETTER\";b:1;s:18:\"SHOW_NOTIFICATIONS\";b:1;s:18:\"SHOW_ORDER_HISTORY\";b:1;s:12:\"SHOW_REVIEWS\";b:1;s:11:\"SHOW_SEARCH\";b:1;s:13:\"SHOW_SPECIALS\";b:1;s:19:\"SHOW_TAB_NAVIGATION\";b:0;s:16:\"SHOW_TELL_FRIEND\";b:1;s:13:\"SHOW_WHATSNEW\";b:1;s:15:\"SHOW_NAVIGATION\";b:1;}javascript_check_done|b:1;javascript|b:1;ajax|s:4:\"true\";chCounter_active|b:1;blz_validation|b:0;plz_validation|b:0;vornamen_validation|b:0;currency|s:3:\"EUR\";cart|O:12:\"shoppingcart\":5:{s:8:\"contents\";a:0:{}s:5:\"total\";i:0;s:6:\"weight\";i:0;s:6:\"cartID\";N;s:12:\"content_type\";b:0;}account_type|s:1:\"0\";customers_status|a:17:{s:21:\"customers_status_name\";s:5:\"Admin\";s:25:\"customers_status_discount\";s:4:\"0.00\";s:23:\"customers_status_public\";s:1:\"1\";s:22:\"customers_status_image\";s:16:\"admin_status.gif\";s:33:\"customers_status_ot_discount_flag\";s:1:\"1\";s:28:\"customers_status_ot_discount\";s:4:\"0.00\";s:33:\"customers_status_graduated_prices\";s:1:\"1\";s:27:\"customers_status_show_price\";s:1:\"1\";s:31:\"customers_status_show_price_tax\";s:1:\"1\";s:27:\"customers_status_add_tax_ot\";s:1:\"0\";s:34:\"customers_status_payment_unallowed\";s:0:\"\";s:35:\"customers_status_shipping_unallowed\";s:0:\"\";s:36:\"customers_status_discount_attributes\";s:1:\"0\";s:15:\"customers_fsk18\";s:1:\"1\";s:23:\"customers_fsk18_display\";s:1:\"1\";s:19:\"customers_status_id\";s:1:\"0\";s:12:\"customers_id\";s:1:\"1\";}text_footer|s:237:\"Copyright � GAMEWARE Computer und Spiele. Powered by <a href=\"http://www.ol-commerce.de\" target=\"_blank\">OL-Commerce v5/AJAX (RC 5.0a.2)</a><br/><font style=\"font-weight:normal\">Irrt�mer, �nderungen und Zwischenverkauf vorbehalten</font>\";template_check|b:1;template_change|b:1;chcounter_start|b:1;debug|s:5:\"false\";product_listing_v2.html|b:0;main_content.html|b:0;affiliate.php|s:43:\"templates/common/source/boxes/affiliate.php\";box_affiliate.html|b:0;categories.php|s:44:\"templates/common/source/boxes/categories.php\";inc/xtc_show_category.inc.php|s:53:\"templates/common/source/inc/xtc_show_category.inc.php\";box_categories.html|b:0;manufacturers.php|s:47:\"templates/common/source/boxes/manufacturers.php\";add_a_quickie.php|s:47:\"templates/common/source/boxes/add_a_quickie.php\";box_add_a_quickie.html|b:0;whats_new.php|s:43:\"templates/common/source/boxes/whats_new.php\";search.php|s:40:\"templates/common/source/boxes/search.php\";box_search.html|b:0;content.php|s:41:\"templates/common/source/boxes/content.php\";box_content.html|b:0;information.php|s:45:\"templates/common/source/boxes/information.php\";languages.php|s:43:\"templates/common/source/boxes/languages.php\";currencies.php|s:44:\"templates/common/source/boxes/currencies.php\";newsletter.php|s:44:\"templates/common/source/boxes/newsletter.php\";box_newsletter.html|b:0;infobox.php|s:41:\"templates/common/source/boxes/infobox.php\";box_infobox.html|b:0;loginbox.php|s:42:\"templates/common/source/boxes/loginbox.php\";box_login.html|b:0;specials.php|s:42:\"templates/common/source/boxes/specials.php\";shopping_cart.php|s:47:\"templates/common/source/boxes/shopping_cart.php\";cart_details_state|s:4:\"none\";box_cart.html|b:0;sticky_cart_visible|N;tell_a_friend.php|s:47:\"templates/common/source/boxes/tell_a_friend.php\";best_sellers.php|s:46:\"templates/common/source/boxes/best_sellers.php\";product_notifications.php|s:55:\"templates/common/source/boxes/product_notifications.php\";reviews.php|s:41:\"templates/common/source/boxes/reviews.php\";last_viewed.php|s:45:\"templates/common/source/boxes/last_viewed.php\";box_tell_friend.html|b:0;customer_gender|s:1:\"m\";customer_last_name|s:5:\"Michl\";customer_id|s:1:\"1\";customer_default_address_id|s:1:\"1\";customer_first_name|s:6:\"Stefan\";customer_country_id|s:2:\"81\";customer_zone_id|s:2:\"81\";debug_output|s:0:\"\";mail_impressum.html|b:0;mail_impressum.txt|b:0;content.html|b:0;admin_box_displayed|b:1;info_box_displayed|b:1;admin.php|s:39:\"templates/common/source/boxes/admin.php\";box_admin.html|b:0;order_history.php|s:47:\"templates/common/source/boxes/order_history.php\";box_order_history.html|b:0;have_saved_carts|b:0;nr_saved_carts|i:0;checked_saved_carts|b:1;actual_content|a:1:{s:0:\"\";a:1:{s:3:\"qty\";i:0;}}full_errors|b:1;limited_access|b:0;selected_box|s:13:\"configuration\";');
insert into olc_sessions (sesskey, expiry, value) values ('819809089f25b261bd28ce2772529852', '1187910615', 'debug_output|s:0:\"\";DIR_FS_MULTI_SHOP|N;navigation|O:17:\"navigationhistory\":2:{s:4:\"path\";a:0:{}s:8:\"snapshot\";a:4:{s:4:\"page\";s:9:\"index.php\";s:4:\"mode\";s:6:\"NONSSL\";s:3:\"get\";a:0:{}s:4:\"post\";a:0:{}}}spider_visit|b:0;allow_keys|N;is_admin|N;header|b:0;user_info|a:4:{s:7:\"user_ip\";s:11:\"192.168.1.3\";s:9:\"user_host\";s:16:\"pc-00003.paar.de\";s:10:\"advertiser\";N;s:11:\"referer_url\";N;}language_id|s:1:\"1\";language_code|s:2:\"de\";language|s:6:\"german\";language_charset|s:11:\"iso-8859-15\";language_name|s:7:\"Deutsch\";boxes.php|s:39:\"templates/common/source/boxes/boxes.php\";box_relations|a:24:{s:17:\"box_ADD_A_QUICKIE\";s:8:\"box_r_05\";s:9:\"box_ADMIN\";s:8:\"box_r_03\";s:13:\"box_AFFILIATE\";s:8:\"box_l_13\";s:15:\"box_BESTSELLERS\";s:8:\"box_r_07\";s:8:\"box_CART\";s:8:\"box_r_01\";s:14:\"box_CATEGORIES\";s:8:\"box_l_01\";s:11:\"box_CONTENT\";s:8:\"box_l_04\";s:14:\"box_CURRENCIES\";s:8:\"box_r_10\";s:11:\"box_INFOBOX\";s:8:\"box_r_08\";s:15:\"box_INFORMATION\";s:8:\"box_l_06\";s:13:\"box_LANGUAGES\";s:8:\"box_r_11\";s:15:\"box_LAST_VIEWED\";s:8:\"box_l_12\";s:9:\"box_LOGIN\";s:8:\"box_r_02\";s:22:\"box_MANUFACTURERS_INFO\";s:8:\"box_l_03\";s:17:\"box_MANUFACTURERS\";s:8:\"box_l_05\";s:14:\"box_NEWSLETTER\";s:8:\"box_l_09\";s:17:\"box_NOTIFICATIONS\";s:8:\"box_l_08\";s:17:\"box_ORDER_HISTORY\";s:8:\"box_l_11\";s:11:\"box_REVIEWS\";s:8:\"box_l_10\";s:10:\"box_SEARCH\";s:8:\"box_r_06\";s:12:\"box_SPECIALS\";s:8:\"box_l_02\";s:15:\"box_TELL_FRIEND\";s:8:\"box_l_07\";s:12:\"box_WHATSNEW\";s:8:\"box_r_04\";s:14:\"box_NAVIGATION\";s:14:\"box_NAVIGATION\";}box_constants|a:27:{s:18:\"SHOW_ADD_A_QUICKIE\";b:1;s:10:\"SHOW_ADMIN\";b:1;s:14:\"SHOW_AFFILIATE\";b:1;s:16:\"SHOW_BESTSELLERS\";b:1;s:9:\"SHOW_CART\";b:1;s:15:\"SHOW_CATEGORIES\";b:1;s:15:\"SHOW_CONTACT_US\";b:0;s:12:\"SHOW_CONTENT\";b:1;s:15:\"SHOW_CURRENCIES\";b:1;s:12:\"SHOW_INFOBOX\";b:1;s:16:\"SHOW_INFORMATION\";b:1;s:14:\"SHOW_LANGUAGES\";b:1;s:16:\"SHOW_LAST_VIEWED\";b:1;s:13:\"SHOW_LIVEHELP\";b:0;s:10:\"SHOW_LOGIN\";b:1;s:23:\"SHOW_MANUFACTURERS_INFO\";b:1;s:18:\"SHOW_MANUFACTURERS\";b:1;s:15:\"SHOW_NEWSLETTER\";b:1;s:18:\"SHOW_NOTIFICATIONS\";b:1;s:18:\"SHOW_ORDER_HISTORY\";b:1;s:12:\"SHOW_REVIEWS\";b:1;s:11:\"SHOW_SEARCH\";b:1;s:13:\"SHOW_SPECIALS\";b:1;s:19:\"SHOW_TAB_NAVIGATION\";b:0;s:16:\"SHOW_TELL_FRIEND\";b:1;s:13:\"SHOW_WHATSNEW\";b:1;s:15:\"SHOW_NAVIGATION\";b:1;}javascript_check_done|b:1;chCounter_active|b:1;currency|s:3:\"EUR\";cart|O:12:\"shoppingcart\":5:{s:8:\"contents\";a:0:{}s:5:\"total\";i:0;s:6:\"weight\";i:0;s:6:\"cartID\";N;s:12:\"content_type\";b:0;}account_type|s:1:\"0\";customers_status|a:17:{s:21:\"customers_status_name\";s:5:\"Guest\";s:25:\"customers_status_discount\";s:4:\"0.00\";s:23:\"customers_status_public\";s:1:\"1\";s:22:\"customers_status_image\";s:16:\"guest_status.gif\";s:33:\"customers_status_ot_discount_flag\";s:1:\"0\";s:28:\"customers_status_ot_discount\";s:4:\"0.00\";s:33:\"customers_status_graduated_prices\";s:1:\"0\";s:27:\"customers_status_show_price\";s:1:\"1\";s:31:\"customers_status_show_price_tax\";s:1:\"1\";s:27:\"customers_status_add_tax_ot\";s:1:\"0\";s:34:\"customers_status_payment_unallowed\";s:0:\"\";s:35:\"customers_status_shipping_unallowed\";s:0:\"\";s:36:\"customers_status_discount_attributes\";s:1:\"0\";s:15:\"customers_fsk18\";s:1:\"1\";s:23:\"customers_fsk18_display\";s:1:\"1\";s:19:\"customers_status_id\";s:1:\"1\";s:12:\"customers_id\";N;}text_footer|s:237:\"Copyright � GAMEWARE Computer und Spiele. Powered by <a href=\"http://www.ol-commerce.de\" target=\"_blank\">OL-Commerce v5/AJAX (RC 5.0a.2)</a><br/><font style=\"font-weight:normal\">Irrt�mer, �nderungen und Zwischenverkauf vorbehalten</font>\";template_check|b:1;template_change|b:1;chcounter_start|b:1;product_listing_v2.html|b:0;main_content.html|b:0;affiliate.php|s:43:\"templates/common/source/boxes/affiliate.php\";box_affiliate.html|b:0;categories.php|s:44:\"templates/common/source/boxes/categories.php\";inc/xtc_show_category.inc.php|s:53:\"templates/common/source/inc/xtc_show_category.inc.php\";box_categories.html|b:0;manufacturers.php|s:47:\"templates/common/source/boxes/manufacturers.php\";add_a_quickie.php|s:47:\"templates/common/source/boxes/add_a_quickie.php\";box_add_a_quickie.html|b:0;whats_new.php|s:43:\"templates/common/source/boxes/whats_new.php\";search.php|s:40:\"templates/common/source/boxes/search.php\";box_search.html|b:0;content.php|s:41:\"templates/common/source/boxes/content.php\";box_content.html|b:0;information.php|s:45:\"templates/common/source/boxes/information.php\";languages.php|s:43:\"templates/common/source/boxes/languages.php\";currencies.php|s:44:\"templates/common/source/boxes/currencies.php\";newsletter.php|s:44:\"templates/common/source/boxes/newsletter.php\";box_newsletter.html|b:0;infobox.php|s:41:\"templates/common/source/boxes/infobox.php\";box_infobox.html|b:0;loginbox.php|s:42:\"templates/common/source/boxes/loginbox.php\";box_login.html|b:0;specials.php|s:42:\"templates/common/source/boxes/specials.php\";shopping_cart.php|s:47:\"templates/common/source/boxes/shopping_cart.php\";box_cart.html|b:0;tell_a_friend.php|s:47:\"templates/common/source/boxes/tell_a_friend.php\";best_sellers.php|s:46:\"templates/common/source/boxes/best_sellers.php\";product_notifications.php|s:55:\"templates/common/source/boxes/product_notifications.php\";reviews.php|s:41:\"templates/common/source/boxes/reviews.php\";last_viewed.php|s:45:\"templates/common/source/boxes/last_viewed.php\";box_tell_friend.html|b:0;actual_content|a:1:{s:0:\"\";a:1:{s:3:\"qty\";i:0;}}');

drop table if exists olc_shipping_status;
create table olc_shipping_status (
  shipping_status_id int(11) default '0' not null ,
  language_id int(11) default '1' not null ,
  shipping_status_name varchar(32) not null ,
  shipping_status_image varchar(32) not null ,
  PRIMARY KEY (shipping_status_id, language_id),
  KEY idx_shipping_status_name (shipping_status_name)
);

insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('1', '1', '3-4 Days', 'ampel_gruen.gif');
insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('1', '2', '3-4 Tage', 'ampel_gruen.gif');
insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('2', '1', '1 Week', 'ampel_gelb.gif');
insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('2', '2', '1 Woche', 'ampel_gelb.gif');
insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('3', '1', '2 Weeks', 'ampel_rot.gif');
insert into olc_shipping_status (shipping_status_id, language_id, shipping_status_name, shipping_status_image) values ('3', '2', '2 Wochen', 'ampel_rot.gif');

drop table if exists olc_specials;
create table olc_specials (
  specials_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  specials_new_products_price decimal(15,4) default '0.0000' not null ,
  specials_date_added datetime ,
  specials_last_modified datetime ,
  expires_date datetime ,
  date_status_change datetime ,
  status int(1) default '1' not null ,
  PRIMARY KEY (specials_id)
);


drop table if exists olc_tax_class;
create table olc_tax_class (
  tax_class_id int(11) not null auto_increment,
  tax_class_title varchar(32) not null ,
  tax_class_description varchar(255) not null ,
  last_modified datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (tax_class_id)
);

insert into olc_tax_class (tax_class_id, tax_class_title, tax_class_description, last_modified, date_added) values ('1', 'Standardsatz', '', NULL, '2007-07-26 17:41:11');
insert into olc_tax_class (tax_class_id, tax_class_title, tax_class_description, last_modified, date_added) values ('2', 'erm��igter Steuersatz', '', NULL, '2007-07-26 17:41:11');

drop table if exists olc_tax_rates;
create table olc_tax_rates (
  tax_rates_id int(11) not null auto_increment,
  tax_zone_id int(11) default '0' not null ,
  tax_class_id int(11) default '0' not null ,
  tax_priority int(5) default '1' ,
  tax_rate decimal(7,4) default '0.0000' not null ,
  tax_description varchar(255) not null ,
  last_modified datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (tax_rates_id)
);

insert into olc_tax_rates (tax_rates_id, tax_zone_id, tax_class_id, tax_priority, tax_rate, tax_description, last_modified, date_added) values ('1', '5', '1', '1', '19.0000', 'UST 19%', NULL, '2007-07-26 17:41:11');
insert into olc_tax_rates (tax_rates_id, tax_zone_id, tax_class_id, tax_priority, tax_rate, tax_description, last_modified, date_added) values ('2', '5', '2', '1', '7.0000', 'UST 7%', NULL, '2007-07-26 17:41:11');
insert into olc_tax_rates (tax_rates_id, tax_zone_id, tax_class_id, tax_priority, tax_rate, tax_description, last_modified, date_added) values ('3', '6', '1', '1', '0.0000', 'EU-AUS-UST 0%', NULL, '2007-07-26 17:41:11');
insert into olc_tax_rates (tax_rates_id, tax_zone_id, tax_class_id, tax_priority, tax_rate, tax_description, last_modified, date_added) values ('4', '6', '2', '1', '0.0000', 'EU-AUS-UST 0%', NULL, '2007-07-26 17:41:11');

drop table if exists olc_vornamen;
create table olc_vornamen (
  vorname varchar(20) not null ,
  geschlecht text not null ,
  KEY vorname (vorname)
);


drop table if exists olc_whos_online;
create table olc_whos_online (
  customer_id int(11) ,
  full_name varchar(64) not null ,
  session_id varchar(128) not null ,
  ip_address varchar(255) not null ,
  time_entry varchar(14) not null ,
  time_last_click varchar(14) not null ,
  last_page_url varchar(64) not null ,
  PRIMARY KEY (session_id)
);

insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '1bc0699e3b0f1727f0a440e0ddf44eef', '', '1185464562', '1185464702', 'shop_content.php?coID=7&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'b58a84669c9ef7a50b98dc9b6cf323b3', '', '1185465802', '1185465850', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'bde7d419c18d5f2ad6164ec9256ab5b6', '', '1185465922', '1185465928', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '5332ab66a493b5bda6c6abacaac3c49b', '', '1185467696', '1185467972', 'shop_content.php?coID=4&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', 'e52e9ea8e24a7155e70cc343ab6d202b', '', '1185468543', '1185468784', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '878a8ba57550410eaa1db9be775ecadb', '', '1185468838', '1185468838', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', '', '16aa5abee5cd60bb798a54e79bbd69f4', '', '1185469395', '1185469421', 'login.php?action=process');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'c7723e7ff816dd28ae565288b160afc9', '', '1185469705', '1185469705', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '9817928d9e77382509b599bc2b4f807d', '', '1186069654', '1186070704', 'sitemap.php&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'ab06736c3c09c1f9169df0d5340bd538', '', '1186070456', '1186070460', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', 'cca4a3e06070f6e60225eb86caa268df', '', '1186071668', '1186072895', 'pdf_export.php?u=true');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '03d038e5d4f13a3af03a44e0acc5c5e4', '', '1186073695', '1186073712', 'shop_content.php?coID=3&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'e980617f82086a6673020d90e842394e', '', '1186078260', '1186078261', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '070233966e89217020578336a52cd556', '', '1186083682', '1186083693', 'index.php&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '75a19155190ebe8b3295ca550f8c7ae9', '', '1186083792', '1186083801', 'display_vvcodes.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', '', '8a9b9df1e895aad9e88858f5c3bd4828', '', '1186084070', '1186084078', 'login.php?action=process');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '0f2ab34c25a472319fc0e96be0a2f0be', '', '1186085650', '1186085660', 'index.php&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', '', '0ffdd54434c6b189ad30a09ceca25b55', '', '1186126049', '1186126100', 'login.php?action=process');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'b6a592176c12cdf5c0300bb97e893d77', '', '1186133048', '1186133067', 'advanced_search.php&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '842e495a0ca0299f7af0defd4e9a392a', '', '1186134316', '1186134319', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '1298699d43524f7717214f181fc0e6c4', '', '1186149729', '1186149847', 'login.php&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '12ad30f8ffe3d906294e19d7e2060bfd', '', '1186151719', '1186151757', 'shop_content.php?coID=1&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '9fe987804947b5275f24a46ec171e6c3', '', '1186157054', '1186157078', 'shop_content.php?coID=2&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'f55ee62636f8fca8e9b56b7cc171c035', '', '1186224429', '1186224433', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '195a5d5a41f0f1bd193d2b23ab74fb69', '', '1186260152', '1186261064', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '6c4ab8576f0ec6c75d51152d92d3328f', '', '1186263342', '1186263447', 'shop_content.php?coID=7&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '3e59a2c04e617c1ac17b1f0cfa107645', '', '1186263850', '1186263858', 'shop_content.php?coID=7&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '76d4291a3706540d6a2bfb8e261f83ea', '', '1186264510', '1186264754', 'shop_content.php?coID=3&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '964e03cae0f7bd9b45df4ec3c078f51c', '', '1186388599', '1186388792', 'shop_content.php?coID=1&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '92ccf429069d5f93553c636d3f3803a4', '', '1186406009', '1186408018', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '57205e927f7c2933f797303c42d09fcd', '', '1186419031', '1186419095', 'shop_content.php?coID=1&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'cb71a0323f1fdea7c5b86cbbcc34cb21', '', '1186419338', '1186419364', 'shop_content.php?coID=901&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '05a1509bf9f26f15ddccf3c5b5402254', '', '1186419503', '1186419504', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '181ef5de415a760b7e6b22811c70aec4', '', '1186563377', '1186563988', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '222f024351115f228ebe32222a92db7a', '', '1186564008', '1186564013', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '44eea7d3dee0cf0439e69e64ec1fbf94', '', '1186609995', '1186610019', 'shop_content.php?coID=4&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '32847a1146374857b2ce3aaa1d963035', '', '1186610109', '1186610110', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '63592f5f27a5e4fa5237a944569bcc7e', '', '1186610335', '1186610336', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'e1fb89d9391dab696f9dd83f75533b8c', '', '1186610484', '1186610489', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'e21bb29aca7b8db058949a97c7895b0c', '', '1186610693', '1186610693', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '5b82a4f2e3c753656e64a9060ab3c833', '', '1186779053', '1186779205', 'shop_content.php?coID=3&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '0b338ad75861dd106b4d89132a58e1a6', '', '1186787175', '1186787222', 'display_vvcodes.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '6e2cdbc84fade89d061d3cc411fda101', '', '1187377209', '1187377689', 'pdf_export.php?u=true');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'b6fd46f3a1550d5aa3e39c18d806ae33', '', '1187377644', '1187377644', 'olc');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'c0e5a21261b44e4defbe38c7f04c42bf', '', '1187549401', '1187549864', 'shop_content.php?coID=4&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'b7128ffa4774c99dfce88514c276cb61', '', '1187550532', '1187562232', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '779b8c7be53587fdd1e1204fb6b0bf52', '', '1187554445', '1187555644', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '7d04cc751da49aee2c3e11577f0f42b3', '', '1187560540', '1187560540', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '1d82b3e2f377658113f63020d6e63b75', '', '1187718766', '1187718788', 'shop_content.php?coID=1&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '4cbc629cc4f1093d54f94947ed49215c', '', '1187721797', '1187721798', 'index.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '04d456bd56afc463e60e1bf250f64153', '', '1187737722', '1187737776', 'shop_content.php?coID=7&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', 'e04408b0eeba8cc3021f29ea8092e404', '', '1187771699', '1187774304', 'shop_content.php?coID=4&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '487d9b33e02bd408cd079f0f96699f51', '', '1187806985', '1187807022', 'advanced_search_result.php?keywords=%27%3Balert%28String.fromCha');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', 'ed9b2a8ad5efb76dd4f3a555aa9102f2', '', '1187808529', '1187808545', 'shop_content.php?coID=1&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', '531a5e18882022511105d2e0131df5b6', '', '1187812128', '1187812137', 'shop_content.php?coID=2&cart_details_state=none');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('0', 'Guest', '819809089f25b261bd28ce2772529852', '', '1187903409', '1187903415', 'olcindex.php');
insert into olc_whos_online (customer_id, full_name, session_id, ip_address, time_entry, time_last_click, last_page_url) values ('1', 'Stefan Michl', 'd7a40e5d56eeb17b955541fa02706765', '', '1187903559', '1187903752', 'index.php');

drop table if exists olc_whos_online_data;
create table olc_whos_online_data (
  session_id varchar(128) not null ,
  online_ips longtext ,
  online_ips_text longtext ,
  PRIMARY KEY (session_id)
);

insert into olc_whos_online_data (session_id, online_ips, online_ips_text) values ('0', '', '');

drop table if exists olc_zones;
create table olc_zones (
  zone_id int(11) not null auto_increment,
  zone_country_id int(11) default '0' not null ,
  zone_code varchar(32) not null ,
  zone_name varchar(32) not null ,
  PRIMARY KEY (zone_id)
);

insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('1', '223', 'AL', 'Alabama');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('2', '223', 'AK', 'Alaska');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('3', '223', 'AS', 'American Samoa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('4', '223', 'AZ', 'Arizona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('5', '223', 'AR', 'Arkansas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('6', '223', 'AF', 'Armed Forces Africa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('7', '223', 'AA', 'Armed Forces Americas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('8', '223', 'AC', 'Armed Forces Canada');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('9', '223', 'AE', 'Armed Forces Europe');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('10', '223', 'AM', 'Armed Forces Middle East');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('11', '223', 'AP', 'Armed Forces Pacific');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('12', '223', 'CA', 'California');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('13', '223', 'CO', 'Colorado');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('14', '223', 'CT', 'Connecticut');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('15', '223', 'DE', 'Delaware');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('16', '223', 'DC', 'District of Columbia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('17', '223', 'FM', 'Federated States Of Micronesia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('18', '223', 'FL', 'Florida');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('19', '223', 'GA', 'Georgia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('20', '223', 'GU', 'Guam');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('21', '223', 'HI', 'Hawaii');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('22', '223', 'ID', 'Idaho');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('23', '223', 'IL', 'Illinois');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('24', '223', 'IN', 'Indiana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('25', '223', 'IA', 'Iowa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('26', '223', 'KS', 'Kansas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('27', '223', 'KY', 'Kentucky');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('28', '223', 'LA', 'Louisiana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('29', '223', 'ME', 'Maine');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('30', '223', 'MH', 'Marshall Islands');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('31', '223', 'MD', 'Maryland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('32', '223', 'MA', 'Massachusetts');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('33', '223', 'MI', 'Michigan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('34', '223', 'MN', 'Minnesota');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('35', '223', 'MS', 'Mississippi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('36', '223', 'MO', 'Missouri');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('37', '223', 'MT', 'Montana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('38', '223', 'NE', 'Nebraska');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('39', '223', 'NV', 'Nevada');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('40', '223', 'NH', 'New Hampshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('41', '223', 'NJ', 'New Jersey');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('42', '223', 'NM', 'New Mexico');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('43', '223', 'NY', 'New York');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('44', '223', 'NC', 'North Carolina');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('45', '223', 'ND', 'North Dakota');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('46', '223', 'MP', 'Northern Mariana Islands');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('47', '223', 'OH', 'Ohio');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('48', '223', 'OK', 'Oklahoma');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('49', '223', 'OR', 'Oregon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('50', '223', 'PW', 'Palau');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('51', '223', 'PA', 'Pennsylvania');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('52', '223', 'PR', 'Puerto Rico');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('53', '223', 'RI', 'Rhode Island');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('54', '223', 'SC', 'South Carolina');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('55', '223', 'SD', 'South Dakota');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('56', '223', 'TN', 'Tennessee');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('57', '223', 'TX', 'Texas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('58', '223', 'UT', 'Utah');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('59', '223', 'VT', 'Vermont');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('60', '223', 'VI', 'Virgin Islands');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('61', '223', 'VA', 'Virginia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('62', '223', 'WA', 'Washington');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('63', '223', 'WV', 'West Virginia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('64', '223', 'WI', 'Wisconsin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('65', '223', 'WY', 'Wyoming');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('66', '38', 'AB', 'Alberta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('67', '38', 'BC', 'British Columbia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('68', '38', 'MB', 'Manitoba');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('69', '38', 'NF', 'Newfoundland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('70', '38', 'NB', 'New Brunswick');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('71', '38', 'NS', 'Nova Scotia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('72', '38', 'NT', 'Northwest Territories');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('73', '38', 'NU', 'Nunavut');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('74', '38', 'ON', 'Ontario');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('75', '38', 'PE', 'Prince Edward Island');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('76', '38', 'QC', 'Quebec');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('77', '38', 'SK', 'Saskatchewan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('78', '38', 'YT', 'Yukon Territory');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('79', '81', 'NDS', 'Niedersachsen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('80', '81', 'BAW', 'Baden-W�rttemberg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('81', '81', 'BAY', 'Bayern');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('82', '81', 'BER', 'Berlin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('83', '81', 'BRG', 'Brandenburg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('84', '81', 'BRE', 'Bremen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('85', '81', 'HAM', 'Hamburg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('86', '81', 'HES', 'Hessen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('87', '81', 'MEC', 'Mecklenburg-Vorpommern');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('88', '81', 'NRW', 'Nordrhein-Westfalen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('89', '81', 'RHE', 'Rheinland-Pfalz');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('90', '81', 'SAR', 'Saarland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('91', '81', 'SAS', 'Sachsen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('92', '81', 'SAC', 'Sachsen-Anhalt');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('93', '81', 'SCN', 'Schleswig-Holstein');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('94', '81', 'THE', 'Th�ringen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('95', '14', 'WI', 'Wien');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('96', '14', 'NO', 'Nieder�sterreich');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('97', '14', 'OO', 'Ober�sterreich');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('98', '14', 'SB', 'Salzburg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('99', '14', 'KN', 'K�rnten');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('100', '14', 'ST', 'Steiermark');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('101', '14', 'TI', 'Tirol');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('102', '14', 'BL', 'Burgenland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('103', '14', 'VB', 'Voralberg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('104', '204', 'AG', 'Aargau');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('105', '204', 'AI', 'Appenzell Innerrhoden');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('106', '204', 'AR', 'Appenzell Ausserrhoden');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('107', '204', 'BE', 'Bern');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('108', '204', 'BL', 'Basel-Landschaft');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('109', '204', 'BS', 'Basel-Stadt');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('110', '204', 'FR', 'Freiburg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('111', '204', 'GE', 'Genf');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('112', '204', 'GL', 'Glarus');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('113', '204', 'GR', 'Graub�nden');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('114', '204', 'JU', 'Jura');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('115', '204', 'LU', 'Luzern');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('116', '204', 'NE', 'Neuenburg');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('117', '204', 'NW', 'Nidwalden');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('118', '204', 'OW', 'Obwalden');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('119', '204', 'SG', 'St. Gallen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('120', '204', 'SH', 'Schaffhausen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('121', '204', 'SO', 'Solothurn');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('122', '204', 'SZ', 'Schwyz');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('123', '204', 'TG', 'Thurgau');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('124', '204', 'TI', 'Tessin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('125', '204', 'UR', 'Uri');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('126', '204', 'VD', 'Waadt');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('127', '204', 'VS', 'Wallis');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('128', '204', 'ZG', 'Zug');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('129', '204', 'ZH', 'Z�rich');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('130', '204', 'DE', 'Deutschland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('131', '204', 'IT', 'Italien');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('132', '204', 'FL', 'Liechtenstein');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('133', '195', 'A Coru�a', 'A Coru�a');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('134', '195', 'Alava', 'Alava');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('135', '195', 'Albacete', 'Albacete');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('136', '195', 'Alicante', 'Alicante');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('137', '195', 'Almeria', 'Almeria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('138', '195', 'Asturias', 'Asturias');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('139', '195', 'Avila', 'Avila');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('140', '195', 'Badajoz', 'Badajoz');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('141', '195', 'Baleares', 'Baleares');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('142', '195', 'Barcelona', 'Barcelona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('143', '195', 'Burgos', 'Burgos');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('144', '195', 'Caceres', 'Caceres');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('145', '195', 'Cadiz', 'Cadiz');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('146', '195', 'Cantabria', 'Cantabria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('147', '195', 'Castellon', 'Castellon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('148', '195', 'Ceuta', 'Ceuta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('149', '195', 'Ciudad Real', 'Ciudad Real');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('150', '195', 'Cordoba', 'Cordoba');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('151', '195', 'Cuenca', 'Cuenca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('152', '195', 'Girona', 'Girona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('153', '195', 'Granada', 'Granada');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('154', '195', 'Guadalajara', 'Guadalajara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('155', '195', 'Guipuzcoa', 'Guipuzcoa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('156', '195', 'Huelva', 'Huelva');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('157', '195', 'Huesca', 'Huesca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('158', '195', 'Jaen', 'Jaen');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('159', '195', 'La Rioja', 'La Rioja');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('160', '195', 'Las Palmas', 'Las Palmas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('161', '195', 'Leon', 'Leon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('162', '195', 'Lleida', 'Lleida');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('163', '195', 'Lugo', 'Lugo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('164', '195', 'Madrid', 'Madrid');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('165', '195', 'Malaga', 'Malaga');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('166', '195', 'Melilla', 'Melilla');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('167', '195', 'Murcia', 'Murcia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('168', '195', 'Navarra', 'Navarra');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('169', '195', 'Ourense', 'Ourense');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('170', '195', 'Palencia', 'Palencia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('171', '195', 'Pontevedra', 'Pontevedra');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('172', '195', 'Salamanca', 'Salamanca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('173', '195', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('174', '195', 'Segovia', 'Segovia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('175', '195', 'Sevilla', 'Sevilla');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('176', '195', 'Soria', 'Soria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('177', '195', 'Tarragona', 'Tarragona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('178', '195', 'Teruel', 'Teruel');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('179', '195', 'Toledo', 'Toledo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('180', '195', 'Valencia', 'Valencia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('181', '195', 'Valladolid', 'Valladolid');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('182', '195', 'Vizcaya', 'Vizcaya');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('183', '195', 'Zamora', 'Zamora');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('184', '195', 'Zaragoza', 'Zaragoza');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('185', '13', 'NSW', 'New South Wales');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('186', '13', 'VIC', 'Victoria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('187', '13', 'QLD', 'Queensland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('188', '13', 'NT', 'Northern Territory');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('189', '13', 'WA', 'Western Australia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('190', '13', 'SA', 'South Australia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('191', '13', 'TAS', 'Tasmania');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('192', '13', 'ACT', 'Australian Capital Territory');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('193', '153', 'Northland', 'Northland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('194', '153', 'Auckland', 'Auckland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('195', '153', 'Waikato', 'Waikato');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('196', '153', 'Bay of Plenty', 'Bay of Plenty');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('197', '153', 'Gisborne', 'Gisborne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('198', '153', 'Hawkes Bay', 'Hawkes Bay');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('199', '153', 'Taranaki', 'Taranaki');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('200', '153', 'Manawatu-Wanganui', 'Manawatu-Wanganui');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('201', '153', 'Wellington', 'Wellington');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('202', '153', 'West Coast', 'West Coast');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('203', '153', 'Canterbury', 'Canterbury');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('204', '153', 'Otago', 'Otago');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('205', '153', 'Southland', 'Southland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('206', '153', 'Tasman', 'Tasman');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('207', '153', 'Nelson', 'Nelson');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('208', '153', 'Marlborough', 'Marlborough');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('209', '30', 'SP', 'S�o Paulo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('210', '30', 'RJ', 'Rio de Janeiro');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('211', '30', 'PE', 'Pernanbuco');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('212', '30', 'BA', 'Bahia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('213', '30', 'AM', 'Amazonas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('214', '30', 'MG', 'Minas Gerais');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('215', '30', 'ES', 'Espirito Santo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('216', '30', 'RS', 'Rio Grande do Sul');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('217', '30', 'PR', 'Paran�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('218', '30', 'SC', 'Santa Catarina');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('219', '30', 'RG', 'Rio Grande do Norte');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('220', '30', 'MS', 'Mato Grosso do Sul');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('221', '30', 'MT', 'Mato Grosso');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('222', '30', 'GO', 'Goias');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('223', '30', 'TO', 'Tocantins');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('224', '30', 'DF', 'Distrito Federal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('225', '30', 'RO', 'Rondonia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('226', '30', 'AC', 'Acre');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('227', '30', 'AP', 'Amapa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('228', '30', 'RO', 'Roraima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('229', '30', 'AL', 'Alagoas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('230', '30', 'CE', 'Cear�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('231', '30', 'MA', 'Maranh�o');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('232', '30', 'PA', 'Par�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('233', '30', 'PB', 'Para�ba');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('234', '30', 'PI', 'Piau�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('235', '30', 'SE', 'Sergipe');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('236', '43', 'I', 'I Regi�n de Tarapac�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('237', '43', 'II', 'II Regi�n de Antofagasta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('238', '43', 'III', 'III Regi�n de Atacama');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('239', '43', 'IV', 'IV Regi�n de Coquimbo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('240', '43', 'V', 'V Regi�n de Valapara�so');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('241', '43', 'RM', 'Regi�n Metropolitana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('242', '43', 'VI', 'VI Regi�n de L. B. O�higgins');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('243', '43', 'VII', 'VII Regi�n del Maule');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('244', '43', 'VIII', 'VIII Regi�n del B�o B�o');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('245', '43', 'IX', 'IX Regi�n de la Araucan�a');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('246', '43', 'X', 'X Regi�n de los Lagos');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('247', '43', 'XI', 'XI Regi�n de Ays�n');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('248', '43', 'XII', 'XII Regi�n de Magallanes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('249', '47', 'AMA', 'Amazonas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('250', '47', 'ANT', 'Antioquia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('251', '47', 'ARA', 'Arauca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('252', '47', 'ATL', 'Atlantico');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('253', '47', 'BOL', 'Bolivar');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('254', '47', 'BOY', 'Boyaca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('255', '47', 'CAL', 'Caldas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('256', '47', 'CAQ', 'Caqueta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('257', '47', 'CAS', 'Casanare');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('258', '47', 'CAU', 'Cauca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('259', '47', 'CES', 'Cesar');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('260', '47', 'CHO', 'Choco');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('261', '47', 'COR', 'Cordoba');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('262', '47', 'CUN', 'Cundinamarca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('263', '47', 'HUI', 'Huila');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('264', '47', 'GUA', 'Guainia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('265', '47', 'GUA', 'Guajira');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('266', '47', 'GUV', 'Guaviare');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('267', '47', 'MAG', 'Magdalena');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('268', '47', 'MET', 'Meta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('269', '47', 'NAR', 'Narino');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('270', '47', 'NDS', 'Norte de Santander');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('271', '47', 'PUT', 'Putumayo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('272', '47', 'QUI', 'Quindio');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('273', '47', 'RIS', 'Risaralda');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('274', '47', 'SAI', 'San Andres Islas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('275', '47', 'SAN', 'Santander');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('276', '47', 'SUC', 'Sucre');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('277', '47', 'TOL', 'Tolima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('278', '47', 'VAL', 'Valle');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('279', '47', 'VAU', 'Vaupes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('280', '47', 'VIC', 'Vichada');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('281', '73', 'Et', 'Etranger');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('282', '73', '01', 'Ain');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('283', '73', '02', 'Aisne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('284', '73', '03', 'Allier');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('285', '73', '04', 'Alpes de Haute Provence');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('286', '73', '05', 'Hautes-Alpes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('287', '73', '06', 'Alpes Maritimes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('288', '73', '07', 'Ard�che');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('289', '73', '08', 'Ardennes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('290', '73', '09', 'Ari�ge');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('291', '73', '10', 'Aube');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('292', '73', '11', 'Aude');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('293', '73', '12', 'Aveyron');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('294', '73', '13', 'Bouches du Rh�ne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('295', '73', '14', 'Calvados');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('296', '73', '15', 'Cantal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('297', '73', '16', 'Charente');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('298', '73', '17', 'Charente Maritime');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('299', '73', '18', 'Cher');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('300', '73', '19', 'Corr�ze');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('301', '73', '2A', 'Corse du Sud');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('302', '73', '2B', 'Haute Corse');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('303', '73', '21', 'C�te d\'Or');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('304', '73', '22', 'C�tes d\'Armor');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('305', '73', '23', 'Creuse');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('306', '73', '24', 'Dordogne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('307', '73', '25', 'Doubs');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('308', '73', '26', 'Dr�me');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('309', '73', '27', 'Eure');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('310', '73', '28', 'Eure et Loir');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('311', '73', '29', 'Finist�re');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('312', '73', '30', 'Gard');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('313', '73', '31', 'Haute Garonne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('314', '73', '32', 'Gers');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('315', '73', '33', 'Gironde');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('316', '73', '34', 'H�rault');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('317', '73', '35', 'Ille et Vilaine');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('318', '73', '36', 'Indre');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('319', '73', '37', 'Indre et Loire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('320', '73', '38', 'Is�re');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('321', '73', '39', 'Jura');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('322', '73', '40', 'Landes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('323', '73', '41', 'Loir et Cher');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('324', '73', '42', 'Loire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('325', '73', '43', 'Haute Loire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('326', '73', '44', 'Loire Atlantique');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('327', '73', '45', 'Loiret');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('328', '73', '46', 'Lot');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('329', '73', '47', 'Lot et Garonne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('330', '73', '48', 'Loz�re');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('331', '73', '49', 'Maine et Loire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('332', '73', '50', 'Manche');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('333', '73', '51', 'Marne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('334', '73', '52', 'Haute Marne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('335', '73', '53', 'Mayenne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('336', '73', '54', 'Meurthe et Moselle');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('337', '73', '55', 'Meuse');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('338', '73', '56', 'Morbihan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('339', '73', '57', 'Moselle');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('340', '73', '58', 'Ni�vre');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('341', '73', '59', 'Nord');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('342', '73', '60', 'Oise');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('343', '73', '61', 'Orne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('344', '73', '62', 'Pas de Calais');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('345', '73', '63', 'Puy de D�me');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('346', '73', '64', 'Pyr�n�es Atlantiques');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('347', '73', '65', 'Hautes Pyr�n�es');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('348', '73', '66', 'Pyr�n�es Orientales');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('349', '73', '67', 'Bas Rhin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('350', '73', '68', 'Haut Rhin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('351', '73', '69', 'Rh�ne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('352', '73', '70', 'Haute Sa�ne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('353', '73', '71', 'Sa�ne et Loire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('354', '73', '72', 'Sarthe');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('355', '73', '73', 'Savoie');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('356', '73', '74', 'Haute Savoie');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('357', '73', '75', 'Paris');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('358', '73', '76', 'Seine Maritime');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('359', '73', '77', 'Seine et Marne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('360', '73', '78', 'Yvelines');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('361', '73', '79', 'Deux S�vres');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('362', '73', '80', 'Somme');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('363', '73', '81', 'Tarn');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('364', '73', '82', 'Tarn et Garonne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('365', '73', '83', 'Var');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('366', '73', '84', 'Vaucluse');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('367', '73', '85', 'Vend�e');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('368', '73', '86', 'Vienne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('369', '73', '87', 'Haute Vienne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('370', '73', '88', 'Vosges');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('371', '73', '89', 'Yonne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('372', '73', '90', 'Territoire de Belfort');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('373', '73', '91', 'Essonne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('374', '73', '92', 'Hauts de Seine');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('375', '73', '93', 'Seine St-Denis');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('376', '73', '94', 'Val de Marne');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('377', '73', '95', 'Val d\'Oise');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('378', '73', '971 (DOM)', 'Guadeloupe');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('379', '73', '972 (DOM)', 'Martinique');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('380', '73', '973 (DOM)', 'Guyane');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('381', '73', '974 (DOM)', 'Saint Denis');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('382', '73', '975 (DOM)', 'St-Pierre de Miquelon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('383', '73', '976 (TOM)', 'Mayotte');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('384', '73', '984 (TOM)', 'Terres australes et Antartiques');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('385', '73', '985 (TOM)', 'Nouvelle Cal�donie');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('386', '73', '986 (TOM)', 'Wallis et Futuna');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('387', '73', '987 (TOM)', 'Polyn�sie fran�aise');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('388', '99', 'DL', 'Delhi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('389', '99', 'MH', 'Maharashtra');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('390', '99', 'TN', 'Tamil Nadu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('391', '99', 'KL', 'Kerala');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('392', '99', 'AP', 'Andhra Pradesh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('393', '99', 'KA', 'Karnataka');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('394', '99', 'GA', 'Goa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('395', '99', 'MP', 'Madhya Pradesh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('396', '99', 'PY', 'Pondicherry');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('397', '99', 'GJ', 'Gujarat');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('398', '99', 'OR', 'Orrisa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('399', '99', 'CA', 'Chhatisgarh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('400', '99', 'JH', 'Jharkhand');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('401', '99', 'BR', 'Bihar');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('402', '99', 'WB', 'West Bengal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('403', '99', 'UP', 'Uttar Pradesh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('404', '99', 'RJ', 'Rajasthan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('405', '99', 'PB', 'Punjab');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('406', '99', 'HR', 'Haryana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('407', '99', 'CH', 'Chandigarh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('408', '99', 'JK', 'Jammu & Kashmir');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('409', '99', 'HP', 'Himachal Pradesh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('410', '99', 'UA', 'Uttaranchal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('411', '99', 'LK', 'Lakshadweep');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('412', '99', 'AN', 'Andaman & Nicobar');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('413', '99', 'MG', 'Meghalaya');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('414', '99', 'AS', 'Assam');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('415', '99', 'DR', 'Dadra & Nagar Haveli');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('416', '99', 'DN', 'Daman & Diu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('417', '99', 'SK', 'Sikkim');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('418', '99', 'TR', 'Tripura');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('419', '99', 'MZ', 'Mizoram');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('420', '99', 'MN', 'Manipur');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('421', '99', 'NL', 'Nagaland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('422', '99', 'AR', 'Arunachal Pradesh');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('423', '105', 'AG', 'Agrigento');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('424', '105', 'AL', 'Alessandria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('425', '105', 'AN', 'Ancona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('426', '105', 'AO', 'Aosta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('427', '105', 'AR', 'Arezzo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('428', '105', 'AP', 'Ascoli Piceno');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('429', '105', 'AT', 'Asti');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('430', '105', 'AV', 'Avellino');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('431', '105', 'BA', 'Bari');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('432', '105', 'BL', 'Belluno');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('433', '105', 'BN', 'Benevento');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('434', '105', 'BG', 'Bergamo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('435', '105', 'BI', 'Biella');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('436', '105', 'BO', 'Bologna');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('437', '105', 'BZ', 'Bolzano');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('438', '105', 'BS', 'Brescia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('439', '105', 'BR', 'Brindisi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('440', '105', 'CA', 'Cagliari');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('441', '105', 'CL', 'Caltanissetta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('442', '105', 'CB', 'Campobasso');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('443', '105', 'CE', 'Caserta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('444', '105', 'CT', 'Catania');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('445', '105', 'CZ', 'Catanzaro');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('446', '105', 'CH', 'Chieti');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('447', '105', 'CO', 'Como');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('448', '105', 'CS', 'Cosenza');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('449', '105', 'CR', 'Cremona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('450', '105', 'KR', 'Crotone');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('451', '105', 'CN', 'Cuneo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('452', '105', 'EN', 'Enna');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('453', '105', 'FE', 'Ferrara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('454', '105', 'FI', 'Firenze');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('455', '105', 'FG', 'Foggia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('456', '105', 'FO', 'Forl�');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('457', '105', 'FR', 'Frosinone');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('458', '105', 'GE', 'Genova');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('459', '105', 'GO', 'Gorizia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('460', '105', 'GR', 'Grosseto');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('461', '105', 'IM', 'Imperia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('462', '105', 'IS', 'Isernia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('463', '105', 'AQ', 'Aquila');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('464', '105', 'SP', 'La Spezia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('465', '105', 'LT', 'Latina');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('466', '105', 'LE', 'Lecce');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('467', '105', 'LC', 'Lecco');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('468', '105', 'LI', 'Livorno');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('469', '105', 'LO', 'Lodi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('470', '105', 'LU', 'Lucca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('471', '105', 'MC', 'Macerata');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('472', '105', 'MN', 'Mantova');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('473', '105', 'MS', 'Massa-Carrara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('474', '105', 'MT', 'Matera');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('475', '105', 'ME', 'Messina');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('476', '105', 'MI', 'Milano');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('477', '105', 'MO', 'Modena');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('478', '105', 'NA', 'Napoli');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('479', '105', 'NO', 'Novara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('480', '105', 'NU', 'Nuoro');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('481', '105', 'OR', 'Oristano');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('482', '105', 'PD', 'Padova');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('483', '105', 'PA', 'Palermo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('484', '105', 'PR', 'Parma');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('485', '105', 'PG', 'Perugia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('486', '105', 'PV', 'Pavia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('487', '105', 'PS', 'Pesaro e Urbino');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('488', '105', 'PE', 'Pescara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('489', '105', 'PC', 'Piacenza');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('490', '105', 'PI', 'Pisa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('491', '105', 'PT', 'Pistoia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('492', '105', 'PN', 'Pordenone');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('493', '105', 'PZ', 'Potenza');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('494', '105', 'PO', 'Prato');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('495', '105', 'RG', 'Ragusa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('496', '105', 'RA', 'Ravenna');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('497', '105', 'RC', 'Reggio di Calabria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('498', '105', 'RE', 'Reggio Emilia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('499', '105', 'RI', 'Rieti');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('500', '105', 'RN', 'Rimini');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('501', '105', 'RM', 'Roma');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('502', '105', 'RO', 'Rovigo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('503', '105', 'SA', 'Salerno');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('504', '105', 'SS', 'Sassari');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('505', '105', 'SV', 'Savona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('506', '105', 'SI', 'Siena');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('507', '105', 'SR', 'Siracusa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('508', '105', 'SO', 'Sondrio');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('509', '105', 'TA', 'Taranto');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('510', '105', 'TE', 'Teramo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('511', '105', 'TR', 'Terni');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('512', '105', 'TO', 'Torino');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('513', '105', 'TP', 'Trapani');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('514', '105', 'TN', 'Trento');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('515', '105', 'TV', 'Treviso');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('516', '105', 'TS', 'Trieste');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('517', '105', 'UD', 'Udine');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('518', '105', 'VA', 'Varese');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('519', '105', 'VE', 'Venezia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('520', '105', 'VB', 'Verbania');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('521', '105', 'VC', 'Vercelli');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('522', '105', 'VR', 'Verona');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('523', '105', 'VV', 'Vibo Valentia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('524', '105', 'VI', 'Vicenza');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('525', '105', 'VT', 'Viterbo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('526', '107', 'Niigata', 'Niigata');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('527', '107', 'Toyama', 'Toyama');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('528', '107', 'Ishikawa', 'Ishikawa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('529', '107', 'Fukui', 'Fukui');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('530', '107', 'Yamanashi', 'Yamanashi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('531', '107', 'Nagano', 'Nagano');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('532', '107', 'Gifu', 'Gifu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('533', '107', 'Shizuoka', 'Shizuoka');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('534', '107', 'Aichi', 'Aichi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('535', '107', 'Mie', 'Mie');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('536', '107', 'Shiga', 'Shiga');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('537', '107', 'Kyoto', 'Kyoto');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('538', '107', 'Osaka', 'Osaka');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('539', '107', 'Hyogo', 'Hyogo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('540', '107', 'Nara', 'Nara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('541', '107', 'Wakayama', 'Wakayama');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('542', '107', 'Tottori', 'Tottori');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('543', '107', 'Shimane', 'Shimane');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('544', '107', 'Okayama', 'Okayama');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('545', '107', 'Hiroshima', 'Hiroshima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('546', '107', 'Yamaguchi', 'Yamaguchi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('547', '107', 'Tokushima', 'Tokushima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('548', '107', 'Kagawa', 'Kagawa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('549', '107', 'Ehime', 'Ehime');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('550', '107', 'Kochi', 'Kochi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('551', '107', 'Fukuoka', 'Fukuoka');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('552', '107', 'Saga', 'Saga');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('553', '107', 'Nagasaki', 'Nagasaki');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('554', '107', 'Kumamoto', 'Kumamoto');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('555', '107', 'Oita', 'Oita');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('556', '107', 'Miyazaki', 'Miyazaki');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('557', '107', 'Kagoshima', 'Kagoshima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('558', '129', 'JOH', 'Johor');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('559', '129', 'KDH', 'Kedah');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('560', '129', 'KEL', 'Kelantan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('561', '129', 'KL', 'Kuala Lumpur');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('562', '129', 'MEL', 'Melaka');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('563', '129', 'NS', 'Negeri Sembilan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('564', '129', 'PAH', 'Pahang');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('565', '129', 'PRK', 'Perak');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('566', '129', 'PER', 'Perlis');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('567', '129', 'PP', 'Pulau Pinang');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('568', '129', 'SAB', 'Sabah');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('569', '129', 'SWK', 'Sarawak');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('570', '129', 'SEL', 'Selangor');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('571', '129', 'TER', 'Terengganu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('572', '129', 'LAB', 'W.P.Labuan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('573', '138', 'AGS', 'Aguascalientes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('574', '138', 'BC', 'Baja California');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('575', '138', 'BCS', 'Baja California Sur');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('576', '138', 'CAM', 'Campeche');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('577', '138', 'COA', 'Coahuila');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('578', '138', 'COL', 'Colima');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('579', '138', 'CHI', 'Chiapas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('580', '138', 'CHIH', 'Chihuahua');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('581', '138', 'DF', 'Distrito Federal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('582', '138', 'DGO', 'Durango');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('583', '138', 'MEX', 'Estado de Mexico');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('584', '138', 'GTO', 'Guanajuato');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('585', '138', 'GRO', 'Guerrero');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('586', '138', 'HGO', 'Hidalgo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('587', '138', 'JAL', 'Jalisco');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('588', '138', 'MCH', 'Michoacan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('589', '138', 'MOR', 'Morelos');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('590', '138', 'NAY', 'Nayarit');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('591', '138', 'NL', 'Nuevo Leon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('592', '138', 'OAX', 'Oaxaca');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('593', '138', 'PUE', 'Puebla');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('594', '138', 'QRO', 'Queretaro');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('595', '138', 'QR', 'Quintana Roo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('596', '138', 'SLP', 'San Luis Potosi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('597', '138', 'SIN', 'Sinaloa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('598', '138', 'SON', 'Sonora');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('599', '138', 'TAB', 'Tabasco');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('600', '138', 'TMPS', 'Tamaulipas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('601', '138', 'TLAX', 'Tlaxcala');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('602', '138', 'VER', 'Veracruz');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('603', '138', 'YUC', 'Yucatan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('604', '138', 'ZAC', 'Zacatecas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('605', '160', 'OSL', 'Oslo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('606', '160', 'AKE', 'Akershus');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('607', '160', 'AUA', 'Aust-Agder');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('608', '160', 'BUS', 'Buskerud');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('609', '160', 'FIN', 'Finnmark');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('610', '160', 'HED', 'Hedmark');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('611', '160', 'HOR', 'Hordaland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('612', '160', 'MOR', 'M�re og Romsdal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('613', '160', 'NOR', 'Nordland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('614', '160', 'NTR', 'Nord-Tr�ndelag');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('615', '160', 'OPP', 'Oppland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('616', '160', 'ROG', 'Rogaland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('617', '160', 'SOF', 'Sogn og Fjordane');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('618', '160', 'STR', 'S�r-Tr�ndelag');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('619', '160', 'TEL', 'Telemark');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('620', '160', 'TRO', 'Troms');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('621', '160', 'VEA', 'Vest-Agder');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('622', '160', 'OST', '�stfold');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('623', '160', 'SVA', 'Svalbard');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('624', '99', 'KHI', 'Karachi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('625', '99', 'LH', 'Lahore');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('626', '99', 'ISB', 'Islamabad');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('627', '99', 'QUE', 'Quetta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('628', '99', 'PSH', 'Peshawar');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('629', '99', 'GUJ', 'Gujrat');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('630', '99', 'SAH', 'Sahiwal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('631', '99', 'FSB', 'Faisalabad');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('632', '99', 'RIP', 'Rawal Pindi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('633', '175', 'AB', 'Alba');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('634', '175', 'AR', 'Arad');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('635', '175', 'AG', 'Arges');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('636', '175', 'BC', 'Bacau');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('637', '175', 'BH', 'Bihor');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('638', '175', 'BN', 'Bistrita-Nasaud');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('639', '175', 'BT', 'Botosani');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('640', '175', 'BV', 'Brasov');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('641', '175', 'BR', 'Braila');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('642', '175', 'B', 'Bucuresti');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('643', '175', 'BZ', 'Buzau');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('644', '175', 'CS', 'Caras-Severin');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('645', '175', 'CL', 'Calarasi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('646', '175', 'CJ', 'Cluj');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('647', '175', 'CT', 'Constanta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('648', '175', 'CV', 'Covasna');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('649', '175', 'DB', 'Dimbovita');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('650', '175', 'DJ', 'Dolj');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('651', '175', 'GL', 'Galati');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('652', '175', 'GR', 'Giurgiu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('653', '175', 'GJ', 'Gorj');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('654', '175', 'HR', 'Harghita');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('655', '175', 'HD', 'Hunedoara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('656', '175', 'IL', 'Ialomita');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('657', '175', 'IS', 'Iasi');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('658', '175', 'IF', 'Ilfov');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('659', '175', 'MM', 'Maramures');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('660', '175', 'MH', 'Mehedint');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('661', '175', 'MS', 'Mures');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('662', '175', 'NT', 'Neamt');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('663', '175', 'OT', 'Olt');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('664', '175', 'PH', 'Prahova');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('665', '175', 'SM', 'Satu-Mare');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('666', '175', 'SJ', 'Salaj');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('667', '175', 'SB', 'Sibiu');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('668', '175', 'SV', 'Suceava');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('669', '175', 'TR', 'Teleorman');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('670', '175', 'TM', 'Timis');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('671', '175', 'TL', 'Tulcea');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('672', '175', 'VS', 'Vaslui');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('673', '175', 'VL', 'Valcea');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('674', '175', 'VN', 'Vrancea');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('675', '193', 'WP', 'Western Cape');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('676', '193', 'GP', 'Gauteng');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('677', '193', 'KZN', 'Kwazulu-Natal');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('678', '193', 'NC', 'Northern-Cape');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('679', '193', 'EC', 'Eastern-Cape');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('680', '193', 'MP', 'Mpumalanga');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('681', '193', 'NW', 'North-West');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('682', '193', 'FS', 'Free State');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('683', '193', 'NP', 'Northern Province');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('684', '215', 'ADANA', 'ADANA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('685', '215', 'ADIYAMAN', 'ADIYAMAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('686', '215', 'AFYON', 'AFYON');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('687', '215', 'AGRI', 'AGRI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('688', '215', 'AMASYA', 'AMASYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('689', '215', 'ANKARA', 'ANKARA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('690', '215', 'ANTALYA', 'ANTALYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('691', '215', 'ARTVIN', 'ARTVIN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('692', '215', 'AYDIN', 'AYDIN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('693', '215', 'BALIKESIR', 'BALIKESIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('694', '215', 'BILECIK', 'BILECIK');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('695', '215', 'BING�L', 'BING�L');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('696', '215', 'BITLIS', 'BITLIS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('697', '215', 'BOLU', 'BOLU');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('698', '215', 'BURDUR', 'BURDUR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('699', '215', 'BURSA', 'BURSA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('700', '215', '�ANAKKALE', '�ANAKKALE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('701', '215', '�ANKIRI', '�ANKIRI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('702', '215', '�ORUM', '�ORUM');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('703', '215', 'DENIZLI', 'DENIZLI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('704', '215', 'DIYARBAKIR', 'DIYARBAKIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('705', '215', 'EDIRNE', 'EDIRNE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('706', '215', 'ELAZIG', 'ELAZIG');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('707', '215', 'ERZINCAN', 'ERZINCAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('708', '215', 'ERZURUM', 'ERZURUM');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('709', '215', 'ESKISEHIR', 'ESKISEHIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('710', '215', 'GAZIANTEP', 'GAZIANTEP');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('711', '215', 'GIRESUN', 'GIRESUN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('712', '215', 'G�M�SHANE', 'G�M�SHANE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('713', '215', 'HAKKARI', 'HAKKARI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('714', '215', 'HATAY', 'HATAY');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('715', '215', 'ISPARTA', 'ISPARTA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('716', '215', 'I�EL', 'I�EL');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('717', '215', 'ISTANBUL', 'ISTANBUL');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('718', '215', 'IZMIR', 'IZMIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('719', '215', 'KARS', 'KARS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('720', '215', 'KASTAMONU', 'KASTAMONU');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('721', '215', 'KAYSERI', 'KAYSERI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('722', '215', 'KIRKLARELI', 'KIRKLARELI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('723', '215', 'KIRSEHIR', 'KIRSEHIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('724', '215', 'KOCAELI', 'KOCAELI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('725', '215', 'KONYA', 'KONYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('726', '215', 'K�TAHYA', 'K�TAHYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('727', '215', 'MALATYA', 'MALATYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('728', '215', 'MANISA', 'MANISA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('729', '215', 'KAHRAMANMARAS', 'KAHRAMANMARAS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('730', '215', 'MARDIN', 'MARDIN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('731', '215', 'MUGLA', 'MUGLA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('732', '215', 'MUS', 'MUS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('733', '215', 'NEVSEHIR', 'NEVSEHIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('734', '215', 'NIGDE', 'NIGDE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('735', '215', 'ORDU', 'ORDU');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('736', '215', 'RIZE', 'RIZE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('737', '215', 'SAKARYA', 'SAKARYA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('738', '215', 'SAMSUN', 'SAMSUN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('739', '215', 'SIIRT', 'SIIRT');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('740', '215', 'SINOP', 'SINOP');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('741', '215', 'SIVAS', 'SIVAS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('742', '215', 'TEKIRDAG', 'TEKIRDAG');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('743', '215', 'TOKAT', 'TOKAT');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('744', '215', 'TRABZON', 'TRABZON');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('745', '215', 'TUNCELI', 'TUNCELI');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('746', '215', 'SANLIURFA', 'SANLIURFA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('747', '215', 'USAK', 'USAK');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('748', '215', 'VAN', 'VAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('749', '215', 'YOZGAT', 'YOZGAT');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('750', '215', 'ZONGULDAK', 'ZONGULDAK');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('751', '215', 'AKSARAY', 'AKSARAY');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('752', '215', 'BAYBURT', 'BAYBURT');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('753', '215', 'KARAMAN', 'KARAMAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('754', '215', 'KIRIKKALE', 'KIRIKKALE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('755', '215', 'BATMAN', 'BATMAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('756', '215', 'SIRNAK', 'SIRNAK');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('757', '215', 'BARTIN', 'BARTIN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('758', '215', 'ARDAHAN', 'ARDAHAN');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('759', '215', 'IGDIR', 'IGDIR');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('760', '215', 'YALOVA', 'YALOVA');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('761', '215', 'KARAB�K', 'KARAB�K');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('762', '215', 'KILIS', 'KILIS');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('763', '215', 'OSMANIYE', 'OSMANIYE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('764', '215', 'D�ZCE', 'D�ZCE');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('765', '229', 'AM', 'Amazonas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('766', '229', 'AN', 'Anzo�tegui');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('767', '229', 'AR', 'Aragua');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('768', '229', 'AP', 'Apure');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('769', '229', 'BA', 'Barinas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('770', '229', 'BO', 'Bol�var');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('771', '229', 'CA', 'Carabobo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('772', '229', 'CO', 'Cojedes');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('773', '229', 'DA', 'Delta Amacuro');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('774', '229', 'DC', 'Distrito Capital');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('775', '229', 'FA', 'Falc�n');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('776', '229', 'GA', 'Gu�rico');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('777', '229', 'GU', 'Guayana');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('778', '229', 'LA', 'Lara');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('779', '229', 'ME', 'M�rida');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('780', '229', 'MI', 'Miranda');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('781', '229', 'MO', 'Monagas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('782', '229', 'NE', 'Nueva Esparta');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('783', '229', 'PO', 'Portuguesa');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('784', '229', 'SU', 'Sucre');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('785', '229', 'TA', 'T�chira');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('786', '229', 'TU', 'Trujillo');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('787', '229', 'VA', 'Vargas');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('788', '229', 'YA', 'Yaracuy');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('789', '229', 'ZU', 'Zulia');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('790', '222', 'AVON', 'Avon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('791', '222', 'BEDS', 'Bedfordshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('792', '222', 'BERK', 'Berkshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('793', '222', 'BIRM', 'Birmingham');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('794', '222', 'BORD', 'Borders');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('795', '222', 'BUCK', 'Buckinghamshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('796', '222', 'CAMB', 'Cambridgeshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('797', '222', 'CENT', 'Central');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('798', '222', 'CHES', 'Cheshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('799', '222', 'CLEV', 'Cleveland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('800', '222', 'CLWY', 'Clwyd');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('801', '222', 'CORN', 'Cornwall');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('802', '222', 'CUMB', 'Cumbria');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('803', '222', 'DERB', 'Derbyshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('804', '222', 'DEVO', 'Devon');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('805', '222', 'DORS', 'Dorset');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('806', '222', 'DUMF', 'Dumfries & Galloway');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('807', '222', 'DURH', 'Durham');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('808', '222', 'DYFE', 'Dyfed');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('809', '222', 'ESUS', 'East Sussex');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('810', '222', 'ESSE', 'Essex');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('811', '222', 'FIFE', 'Fife');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('812', '222', 'GLAM', 'Glamorgan');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('813', '222', 'GLOU', 'Gloucestershire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('814', '222', 'GRAM', 'Grampian');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('815', '222', 'GWEN', 'Gwent');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('816', '222', 'GWYN', 'Gwynedd');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('817', '222', 'HAMP', 'Hampshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('818', '222', 'HERE', 'Hereford & Worcester');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('819', '222', 'HERT', 'Hertfordshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('820', '222', 'HUMB', 'Humberside');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('821', '222', 'KENT', 'Kent');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('822', '222', 'LANC', 'Lancashire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('823', '222', 'LEIC', 'Leicestershire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('824', '222', 'LINC', 'Lincolnshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('825', '222', 'LOND', 'London');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('826', '222', 'LOTH', 'Lothian');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('827', '222', 'MANC', 'Manchester');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('828', '222', 'MERS', 'Merseyside');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('829', '222', 'NORF', 'Norfolk');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('830', '222', 'NYOR', 'North Yorkshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('831', '222', 'NWHI', 'North west Highlands');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('832', '222', 'NHAM', 'Northamptonshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('833', '222', 'NUMB', 'Northumberland');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('834', '222', 'NOTT', 'Nottinghamshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('835', '222', 'OXFO', 'Oxfordshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('836', '222', 'POWY', 'Powys');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('837', '222', 'SHRO', 'Shropshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('838', '222', 'SOME', 'Somerset');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('839', '222', 'SYOR', 'South Yorkshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('840', '222', 'STAF', 'Staffordshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('841', '222', 'STRA', 'Strathclyde');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('842', '222', 'SUFF', 'Suffolk');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('843', '222', 'SURR', 'Surrey');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('844', '222', 'WSUS', 'West Sussex');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('845', '222', 'TAYS', 'Tayside');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('846', '222', 'TYWE', 'Tyne & Wear');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('847', '222', 'WARW', 'Warwickshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('848', '222', 'WISL', 'West Isles');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('849', '222', 'WYOR', 'West Yorkshire');
insert into olc_zones (zone_id, zone_country_id, zone_code, zone_name) values ('850', '222', 'WILT', 'Wiltshire');

drop table if exists olc_zones_to_geo_zones;
create table olc_zones_to_geo_zones (
  association_id int(11) not null auto_increment,
  zone_country_id int(11) default '0' not null ,
  zone_id int(11) ,
  geo_zone_id int(11) ,
  last_modified datetime ,
  date_added datetime default '0000-00-00 00:00:00' not null ,
  PRIMARY KEY (association_id)
);

insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('5', '57', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('4', '21', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('6', '72', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('7', '73', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('8', '84', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('9', '103', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('10', '105', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('11', '124', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('12', '150', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('13', '14', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('14', '171', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('15', '195', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('16', '222', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('17', '203', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('18', '81', '0', '5', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('19', '1', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('20', '2', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('21', '3', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('22', '4', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('23', '5', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('24', '6', NULL, '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('25', '7', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('26', '8', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('27', '9', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('28', '10', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('29', '11', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('30', '13', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('31', '15', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('32', '16', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('33', '17', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('34', '19', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('35', '20', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('36', '22', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('37', '23', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('38', '24', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('39', '25', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('40', '27', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('41', '26', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('42', '28', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('43', '29', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('44', '30', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('45', '31', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('46', '32', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('47', '33', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('48', '34', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('49', '35', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('50', '36', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('51', '37', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('52', '39', NULL, '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('53', '38', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('54', '40', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('55', '41', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('56', '42', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('57', '43', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('58', '44', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('59', '45', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('60', '47', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('61', '48', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('62', '49', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('63', '50', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('64', '51', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('65', '52', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('66', '53', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('67', '54', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('68', '55', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('69', '56', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('70', '58', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('71', '59', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('72', '60', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('73', '61', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('74', '62', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('75', '63', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('76', '64', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('77', '65', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('78', '66', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('79', '67', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('80', '68', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('81', '69', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('82', '70', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('83', '71', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('84', '74', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('85', '75', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('86', '76', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('87', '77', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('88', '78', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('89', '79', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('90', '82', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('91', '83', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('92', '86', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('93', '87', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('94', '88', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('95', '89', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('96', '90', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('97', '91', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('98', '92', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('99', '93', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('100', '94', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('101', '95', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('102', '96', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('103', '97', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('104', '99', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('105', '100', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('106', '101', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('107', '102', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('108', '104', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('109', '106', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('110', '107', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('111', '109', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('112', '110', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('113', '111', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('114', '112', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('115', '113', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('116', '114', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('117', '115', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('118', '116', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('119', '117', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('120', '118', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('121', '119', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('122', '120', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('123', '121', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('124', '122', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('125', '125', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('126', '126', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('127', '127', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('128', '128', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('129', '129', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('130', '130', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('131', '131', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('132', '132', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('133', '133', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('134', '134', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('135', '135', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('136', '136', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('137', '137', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('138', '138', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('139', '139', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('140', '140', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('141', '141', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('142', '142', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('143', '143', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('144', '144', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('145', '145', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('146', '146', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('147', '147', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('148', '148', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('149', '149', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('150', '151', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('151', '152', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('152', '153', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('153', '154', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('154', '155', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('155', '156', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('156', '157', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('157', '158', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('158', '159', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('159', '160', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('160', '161', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('161', '162', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('162', '164', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('163', '165', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('164', '166', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('165', '167', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('166', '168', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('167', '169', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('168', '170', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('169', '172', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('170', '173', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('171', '174', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('172', '176', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('173', '177', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('174', '178', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('175', '179', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('176', '180', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('177', '181', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('178', '182', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('179', '183', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('180', '184', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('181', '185', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('182', '186', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('183', '187', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('184', '188', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('185', '189', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('186', '190', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('187', '191', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('188', '193', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('189', '194', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('190', '192', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('191', '196', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('192', '197', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('193', '198', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('194', '199', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('195', '200', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('196', '201', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('197', '202', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('198', '204', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('199', '205', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('200', '206', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('201', '207', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('202', '208', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('203', '209', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('204', '210', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('205', '211', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('206', '212', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('207', '213', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('208', '214', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('209', '215', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('210', '216', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('211', '217', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('212', '218', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('213', '219', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('214', '221', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('215', '223', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('216', '224', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('217', '225', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('218', '226', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('219', '227', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('220', '228', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('221', '229', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('222', '230', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('223', '231', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('224', '232', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('225', '233', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('226', '234', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('227', '235', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('228', '236', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('229', '237', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('230', '238', '0', '6', NULL, '2007-07-26 17:38:47');
insert into olc_zones_to_geo_zones (association_id, zone_country_id, zone_id, geo_zone_id, last_modified, date_added) values ('231', '239', '0', '6', NULL, '2007-07-26 17:38:47');

